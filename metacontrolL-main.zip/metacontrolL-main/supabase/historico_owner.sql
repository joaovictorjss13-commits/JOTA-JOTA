-- ══ Tabela de histórico de alterações Owner ══
-- Execute no Supabase → SQL Editor

CREATE TABLE IF NOT EXISTS public.historico_owner (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id uuid REFERENCES public.admins(id) ON DELETE CASCADE,
  acao text NOT NULL,
  detalhes jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Índice para busca rápida por admin
CREATE INDEX IF NOT EXISTS idx_historico_owner_admin 
ON public.historico_owner(admin_id, created_at DESC);

-- RLS: apenas service_role pode ler/escrever (via API)
ALTER TABLE public.historico_owner ENABLE ROW LEVEL SECURITY;

-- Policy: service_role tem acesso total
CREATE POLICY "service_role_full_access" ON public.historico_owner
  FOR ALL USING (true) WITH CHECK (true);
