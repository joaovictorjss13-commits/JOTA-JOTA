-- ============================================================
-- MetaControll — Schema Completo v8
-- Consolida TODAS as migrations 000 → 011
-- Execute INTEIRO no Supabase SQL Editor (idempotente)
-- ============================================================


-- ────────────────────────────────────────────────────────────
-- EXTENSÕES
-- ────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;


-- ════════════════════════════════════════════════════════════
-- ENUMS
-- ════════════════════════════════════════════════════════════
DO $$ BEGIN CREATE TYPE plano_tipo        AS ENUM ('solo', 'pro');                                   EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE assinatura_status AS ENUM ('trial', 'ativa', 'cancelada', 'inadimplente');   EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE meta_status       AS ENUM ('ativa', 'finalizada', 'fechada', 'lixeira');     EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE meta_modelo       AS ENUM ('salario_bau', 'apenas_bau');                     EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE remessa_tipo      AS ENUM ('remessa', 'sync', 'ajuste');                     EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE custo_tipo        AS ENUM ('proxy', 'sms', 'assinaturas', 'bot', 'vps', 'outros'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE operador_status   AS ENUM ('ativo', 'inativo', 'pendente');                  EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE remessa_status    AS ENUM ('normal', 'pendente', 'bloqueado', 'analise');    EXCEPTION WHEN duplicate_object THEN null; END $$;


-- ════════════════════════════════════════════════════════════
-- TABELAS
-- ════════════════════════════════════════════════════════════

-- ADMINS
CREATE TABLE IF NOT EXISTS admins (
  id           uuid        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nome         text        NOT NULL,
  email        text        NOT NULL UNIQUE,
  plano        plano_tipo  NOT NULL DEFAULT 'pro',
  meta_global  numeric(12,2) DEFAULT 0,
  notificacoes boolean     DEFAULT true,
  created_at   timestamptz DEFAULT now(),
  updated_at   timestamptz DEFAULT now()
);

-- ASSINATURAS
CREATE TABLE IF NOT EXISTS assinaturas (
  id                 uuid              PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id           uuid              NOT NULL REFERENCES admins(id) ON DELETE CASCADE UNIQUE,
  plano              plano_tipo        NOT NULL DEFAULT 'pro',
  qtd_operadores     int               NOT NULL DEFAULT 0,
  valor_base         numeric(10,2)     NOT NULL DEFAULT 39.90,
  valor_por_operador numeric(10,2)     NOT NULL DEFAULT 11.90,
  valor_mensal       numeric(10,2)     GENERATED ALWAYS AS (valor_base + (qtd_operadores * valor_por_operador)) STORED,
  status             assinatura_status NOT NULL DEFAULT 'trial',
  trial_ends_at      timestamptz       DEFAULT (now() + interval '3 days'),
  vencimento         date,
  gateway_sub_id     text,
  created_at         timestamptz       DEFAULT now(),
  updated_at         timestamptz       DEFAULT now()
);

-- OPERADORES
CREATE TABLE IF NOT EXISTS operadores (
  id            uuid            PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       uuid            REFERENCES auth.users(id) ON DELETE SET NULL,
  admin_id      uuid            NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  nome          text            NOT NULL,
  email         text,
  status        operador_status NOT NULL DEFAULT 'pendente',
  convite_token text            UNIQUE DEFAULT encode(gen_random_bytes(16), 'hex'),
  convite_usado boolean         DEFAULT false,
  created_at    timestamptz     DEFAULT now(),
  updated_at    timestamptz     DEFAULT now()
);

-- REDES
CREATE TABLE IF NOT EXISTS redes (
  id         uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id   uuid        NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  nome       text        NOT NULL,
  sigla      text        NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- SLOTS
CREATE TABLE IF NOT EXISTS slots (
  id          uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome        text        NOT NULL,
  provider    text        NOT NULL,
  rtp         numeric(5,2),
  categoria   text,
  imagem_url  text,
  destaque    boolean     DEFAULT false,
  apenas_pro  boolean     DEFAULT true,
  created_at  timestamptz DEFAULT now()
);

-- METAS
CREATE TABLE IF NOT EXISTS metas (
  id                  uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id            uuid        NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  operador_id         uuid        REFERENCES operadores(id) ON DELETE SET NULL,
  rede_id             uuid        REFERENCES redes(id) ON DELETE SET NULL,
  rede_sigla          text        DEFAULT '',
  titulo              text        NOT NULL,
  plataforma          text        NOT NULL,
  contas_total        int         NOT NULL DEFAULT 10,
  contas_atingidas    int         NOT NULL DEFAULT 0,
  modelo              meta_modelo NOT NULL DEFAULT 'salario_bau',
  status              meta_status NOT NULL DEFAULT 'ativa',
  -- Agregados (recalculados pelo trigger recalcular_meta)
  deposito_total      numeric(12,2) NOT NULL DEFAULT 0,
  saque_total         numeric(12,2) NOT NULL DEFAULT 0,
  lucro_bruto         numeric(12,2) GENERATED ALWAYS AS (saque_total - deposito_total) STORED,
  prejuizo_acum       numeric(12,2) NOT NULL DEFAULT 0,
  resultado_liquido   numeric(12,2) NOT NULL DEFAULT 0,
  taxa_acerto         numeric(5,2)  NOT NULL DEFAULT 0,
  score               int           NOT NULL DEFAULT 0 CHECK (score BETWEEN 0 AND 100),
  -- Fechamento
  salario             numeric(10,2) DEFAULT 0,
  bau                 numeric(10,2) DEFAULT 0,
  gastos_operacionais numeric(10,2) DEFAULT 0,
  custo_fixo          numeric(10,2) DEFAULT 0,
  taxa_agente         numeric(10,2) DEFAULT 0,
  lucro_final         numeric(12,2) DEFAULT 0,
  finalizada_at       timestamptz,
  fechada_at          timestamptz,
  created_at          timestamptz DEFAULT now(),
  updated_at          timestamptz DEFAULT now()
);

-- REMESSAS
CREATE TABLE IF NOT EXISTS remessas (
  id          uuid           PRIMARY KEY DEFAULT uuid_generate_v4(),
  meta_id     uuid           NOT NULL REFERENCES metas(id) ON DELETE CASCADE,
  operador_id uuid           REFERENCES operadores(id) ON DELETE SET NULL,
  slot_id     uuid           REFERENCES slots(id) ON DELETE SET NULL,
  titulo      text,
  tipo        remessa_tipo   NOT NULL DEFAULT 'remessa',
  saldo_ini   numeric(12,2)  DEFAULT 0,
  contas      int            NOT NULL DEFAULT 1,
  deposito    numeric(12,2)  NOT NULL DEFAULT 0,
  saque       numeric(12,2)  NOT NULL DEFAULT 0,
  resultado   numeric(12,2)  GENERATED ALWAYS AS (saque - deposito) STORED,
  status      remessa_status NOT NULL DEFAULT 'normal',
  notas       text,
  created_at  timestamptz    DEFAULT now()
);

-- CUSTOS
CREATE TABLE IF NOT EXISTS custos (
  id         uuid       PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id   uuid       NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  tipo       custo_tipo NOT NULL,
  valor      numeric(10,2) NOT NULL CHECK (valor > 0),
  data       date       NOT NULL DEFAULT current_date,
  nota       text,
  created_at timestamptz DEFAULT now()
);

-- CHAVES PIX
CREATE TABLE IF NOT EXISTS chaves_pix (
  id         uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id   uuid        NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  tipo       text        NOT NULL,
  chave      text        NOT NULL,
  apelido    text,
  created_at timestamptz DEFAULT now()
);

-- PUSH TOKENS
CREATE TABLE IF NOT EXISTS push_tokens (
  id         uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  token      text        NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- ONBOARDING
CREATE TABLE IF NOT EXISTS onboarding (
  id                   uuid        PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id             uuid        NOT NULL REFERENCES admins(id) ON DELETE CASCADE UNIQUE,
  criou_meta           boolean     DEFAULT false,
  registrou_remessa    boolean     DEFAULT false,
  finalizou_meta       boolean     DEFAULT false,
  acompanhou_dashboard boolean     DEFAULT false,
  convidou_operador    boolean     DEFAULT false,
  fechou_com_custos    boolean     DEFAULT false,
  updated_at           timestamptz DEFAULT now()
);


-- ════════════════════════════════════════════════════════════
-- FUNÇÕES E TRIGGERS
-- ════════════════════════════════════════════════════════════

-- updated_at automático
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS trg_updated_admins      ON admins;
DROP TRIGGER IF EXISTS trg_updated_metas       ON metas;
DROP TRIGGER IF EXISTS trg_updated_operadores  ON operadores;
DROP TRIGGER IF EXISTS trg_updated_assinaturas ON assinaturas;

CREATE TRIGGER trg_updated_admins      BEFORE UPDATE ON admins      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_updated_metas       BEFORE UPDATE ON metas       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_updated_operadores  BEFORE UPDATE ON operadores  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_updated_assinaturas BEFORE UPDATE ON assinaturas FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- Recalcular agregados da meta após INSERT/UPDATE/DELETE em remessas
CREATE OR REPLACE FUNCTION recalcular_meta()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_dep       numeric(12,2);
  v_saque     numeric(12,2);
  v_prejuizo  numeric(12,2);
  v_total     int;
  v_positivas int;
  v_contas    int;
  v_meta_id   uuid;
BEGIN
  v_meta_id := COALESCE(NEW.meta_id, OLD.meta_id);

  SELECT
    COALESCE(SUM(deposito), 0),
    COALESCE(SUM(saque), 0),
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0),
    COUNT(*),
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END),
    COALESCE(SUM(contas), 0)
  INTO v_dep, v_saque, v_prejuizo, v_total, v_positivas, v_contas
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'normal';

  UPDATE metas SET
    deposito_total    = v_dep,
    saque_total       = v_saque,
    prejuizo_acum     = v_prejuizo,
    resultado_liquido = v_saque - v_dep,
    taxa_acerto       = CASE WHEN v_total = 0 THEN 0 ELSE ROUND((v_positivas::numeric / v_total) * 100, 2) END,
    score             = CASE WHEN v_total = 0 THEN 0 ELSE LEAST(100, ROUND((v_positivas::numeric / v_total) * 100)) END,
    contas_atingidas  = v_contas,
    updated_at        = now()
  WHERE id = v_meta_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_recalcular_meta ON remessas;
CREATE TRIGGER trg_recalcular_meta
AFTER INSERT OR UPDATE OR DELETE ON remessas
FOR EACH ROW EXECUTE FUNCTION recalcular_meta();


-- Calcular lucro_final e timestamps ao mudar status da meta
-- Fórmula: resultado_liquido + salario + bau - gastos_operacionais
CREATE OR REPLACE FUNCTION calcular_fechamento()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'fechada' AND OLD.status != 'fechada' THEN
    NEW.lucro_final := NEW.resultado_liquido
                       + COALESCE(NEW.salario, 0)
                       + COALESCE(NEW.bau, 0)
                       - COALESCE(NEW.gastos_operacionais, 0);
    NEW.fechada_at := now();
    UPDATE onboarding SET fechou_com_custos = true, updated_at = now() WHERE admin_id = NEW.admin_id;
  END IF;

  IF NEW.status = 'finalizada' AND OLD.status = 'ativa' THEN
    NEW.finalizada_at := now();
    UPDATE onboarding SET finalizou_meta = true, updated_at = now() WHERE admin_id = NEW.admin_id;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_calcular_fechamento ON metas;
CREATE TRIGGER trg_calcular_fechamento
BEFORE UPDATE ON metas
FOR EACH ROW EXECUTE FUNCTION calcular_fechamento();


-- Onboarding: primeira meta criada
CREATE OR REPLACE FUNCTION on_meta_created()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE onboarding SET criou_meta = true, updated_at = now()
  WHERE admin_id = NEW.admin_id AND criou_meta = false;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_meta_created ON metas;
CREATE TRIGGER trg_meta_created
AFTER INSERT ON metas
FOR EACH ROW EXECUTE FUNCTION on_meta_created();


-- Onboarding: primeira remessa registrada
CREATE OR REPLACE FUNCTION on_remessa_created()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_admin_id uuid;
BEGIN
  SELECT admin_id INTO v_admin_id FROM metas WHERE id = NEW.meta_id;
  UPDATE onboarding SET registrou_remessa = true, updated_at = now()
  WHERE admin_id = v_admin_id AND registrou_remessa = false;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_remessa_created ON remessas;
CREATE TRIGGER trg_remessa_created
AFTER INSERT ON remessas
FOR EACH ROW EXECUTE FUNCTION on_remessa_created();


-- Novo usuário via auth.users → cria linha em admins
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.admins (id, nome, email, plano)
  VALUES (
    NEW.id,
    COALESCE(
      NEW.raw_user_meta_data->>'nome',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    NEW.email,
    'pro'
  )
  ON CONFLICT DO NOTHING;
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'handle_new_user error (email: %): %', NEW.email, SQLERRM;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();


-- Novo admin → assinatura trial PRO 3 dias + onboarding
CREATE OR REPLACE FUNCTION handle_new_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO assinaturas (admin_id, plano, status, trial_ends_at)
  VALUES (NEW.id, 'pro', 'trial', now() + interval '3 days')
  ON CONFLICT (admin_id) DO NOTHING;

  INSERT INTO onboarding (admin_id)
  VALUES (NEW.id)
  ON CONFLICT (admin_id) DO NOTHING;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'handle_new_admin error (admin: %): %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_admin_created  ON admins;
DROP TRIGGER IF EXISTS trg_admin_created ON admins;
CREATE TRIGGER trg_admin_created
AFTER INSERT ON admins
FOR EACH ROW EXECUTE FUNCTION handle_new_admin();


-- Expirar trials vencidos em lote (usado pelo pg_cron)
CREATE OR REPLACE FUNCTION expire_trials()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE admins SET plano = 'solo', updated_at = now()
  WHERE plano = 'pro'
    AND id IN (SELECT admin_id FROM assinaturas WHERE status = 'trial' AND trial_ends_at <= now());

  UPDATE assinaturas SET status = 'cancelada', updated_at = now()
  WHERE status = 'trial' AND trial_ends_at <= now();
END;
$$;


-- RPC chamada pelo cliente quando detecta trial expirado localmente
CREATE OR REPLACE FUNCTION expire_my_trial()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE assinaturas
  SET status = 'cancelada', updated_at = now()
  WHERE admin_id = auth.uid()
    AND status = 'trial'
    AND trial_ends_at <= now();

  UPDATE admins
  SET plano = 'solo', updated_at = now()
  WHERE id = auth.uid()
    AND plano = 'pro'
    AND id IN (
      SELECT admin_id FROM assinaturas
      WHERE admin_id = auth.uid() AND status = 'cancelada'
    );
END;
$$;

GRANT EXECUTE ON FUNCTION expire_my_trial() TO authenticated;


-- ════════════════════════════════════════════════════════════
-- VIEWS
-- ════════════════════════════════════════════════════════════

CREATE OR REPLACE VIEW vw_faturamento AS
SELECT
  a.id                                                                    AS admin_id,
  a.nome                                                                  AS admin_nome,
  COUNT(m.id)                                                             AS total_metas,
  COUNT(m.id) FILTER (WHERE m.status = 'ativa')                          AS metas_ativas,
  COUNT(m.id) FILTER (WHERE m.status = 'fechada')                        AS metas_fechadas,
  COALESCE(SUM(m.deposito_total), 0)                                      AS deposito_total,
  COALESCE(SUM(m.saque_total), 0)                                         AS saque_total,
  COALESCE(SUM(m.lucro_bruto), 0)                                         AS lucro_bruto,
  COALESCE(SUM(m.prejuizo_acum), 0)                                       AS prejuizo_total,
  COALESCE(SUM(m.resultado_liquido), 0)                                   AS resultado_liquido,
  COALESCE(SUM(m.lucro_final), 0)                                         AS lucro_final,
  COALESCE(AVG(m.taxa_acerto) FILTER (WHERE m.status = 'fechada'), 0)     AS taxa_acerto_media
FROM admins a
LEFT JOIN metas m ON m.admin_id = a.id AND m.status != 'lixeira'
GROUP BY a.id, a.nome;

CREATE OR REPLACE VIEW vw_custos_resumo AS
SELECT
  admin_id,
  COALESCE(SUM(valor) FILTER (WHERE data = current_date), 0)                                                                                     AS custo_hoje,
  COALESCE(SUM(valor) FILTER (WHERE date_trunc('month', data::timestamptz) = date_trunc('month', current_date::timestamptz)), 0)                  AS custo_mes,
  COALESCE(SUM(valor), 0)                                                                                                                         AS custo_total
FROM custos
GROUP BY admin_id;

CREATE OR REPLACE VIEW vw_previsao AS
SELECT
  admin_id,
  COUNT(*)                                                         AS metas_fechadas,
  COALESCE(AVG(resultado_liquido), 0)                              AS lucro_medio_meta,
  COALESCE(AVG(resultado_liquido / NULLIF(contas_total, 0)), 0)   AS lucro_medio_conta
FROM metas
WHERE status = 'fechada'
GROUP BY admin_id;


-- ════════════════════════════════════════════════════════════
-- RPCs
-- ════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION evolucao_mensal(p_admin_id uuid)
RETURNS TABLE(mes text, lucro numeric, metas_fechadas bigint)
LANGUAGE sql SECURITY DEFINER AS $$
  SELECT
    to_char(date_trunc('month', fechada_at), 'MM/YY') AS mes,
    SUM(resultado_liquido)                             AS lucro,
    COUNT(*)                                           AS metas_fechadas
  FROM metas
  WHERE admin_id   = p_admin_id
    AND status     = 'fechada'
    AND fechada_at >= now() - interval '12 months'
  GROUP BY date_trunc('month', fechada_at)
  ORDER BY date_trunc('month', fechada_at);
$$;


-- ════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ════════════════════════════════════════════════════════════

ALTER TABLE admins       ENABLE ROW LEVEL SECURITY;
ALTER TABLE assinaturas  ENABLE ROW LEVEL SECURITY;
ALTER TABLE operadores   ENABLE ROW LEVEL SECURITY;
ALTER TABLE redes        ENABLE ROW LEVEL SECURITY;
ALTER TABLE metas        ENABLE ROW LEVEL SECURITY;
ALTER TABLE remessas     ENABLE ROW LEVEL SECURITY;
ALTER TABLE custos       ENABLE ROW LEVEL SECURITY;
ALTER TABLE chaves_pix   ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_tokens  ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding   ENABLE ROW LEVEL SECURITY;
ALTER TABLE slots        ENABLE ROW LEVEL SECURITY;

-- ADMINS
DROP POLICY IF EXISTS admin_select_own ON admins;
DROP POLICY IF EXISTS admin_update_own ON admins;
DROP POLICY IF EXISTS admin_insert_own ON admins;
CREATE POLICY admin_select_own ON admins FOR SELECT USING (auth.uid() = id);
CREATE POLICY admin_update_own ON admins FOR UPDATE USING (auth.uid() = id);
CREATE POLICY admin_insert_own ON admins FOR INSERT WITH CHECK (auth.uid() = id);

-- ASSINATURAS
DROP POLICY IF EXISTS assinatura_own ON assinaturas;
CREATE POLICY assinatura_own ON assinaturas FOR ALL USING (admin_id = auth.uid());

-- OPERADORES
DROP POLICY IF EXISTS operador_admin_select ON operadores;
DROP POLICY IF EXISTS operador_admin_insert ON operadores;
DROP POLICY IF EXISTS operador_admin_update ON operadores;
DROP POLICY IF EXISTS operador_admin_delete ON operadores;
CREATE POLICY operador_admin_select ON operadores FOR SELECT USING (admin_id = auth.uid() OR user_id = auth.uid());
CREATE POLICY operador_admin_insert ON operadores FOR INSERT WITH CHECK (admin_id = auth.uid());
CREATE POLICY operador_admin_update ON operadores FOR UPDATE USING (admin_id = auth.uid() OR user_id = auth.uid());
CREATE POLICY operador_admin_delete ON operadores FOR DELETE USING (admin_id = auth.uid());

-- REDES
DROP POLICY IF EXISTS redes_own ON redes;
CREATE POLICY redes_own ON redes FOR ALL USING (admin_id = auth.uid());

-- METAS
DROP POLICY IF EXISTS metas_admin_all       ON metas;
DROP POLICY IF EXISTS metas_operador_select ON metas;
CREATE POLICY metas_admin_all       ON metas FOR ALL    USING (admin_id = auth.uid());
CREATE POLICY metas_operador_select ON metas FOR SELECT USING (
  EXISTS (SELECT 1 FROM operadores WHERE operadores.id = metas.operador_id AND operadores.user_id = auth.uid())
);

-- REMESSAS
DROP POLICY IF EXISTS remessas_admin_all ON remessas;
DROP POLICY IF EXISTS remessas_operador  ON remessas;
CREATE POLICY remessas_admin_all ON remessas FOR ALL USING (
  EXISTS (SELECT 1 FROM metas WHERE metas.id = remessas.meta_id AND metas.admin_id = auth.uid())
);
CREATE POLICY remessas_operador ON remessas FOR ALL USING (
  EXISTS (SELECT 1 FROM operadores WHERE operadores.id = remessas.operador_id AND operadores.user_id = auth.uid())
);

-- CUSTOS
DROP POLICY IF EXISTS custos_own ON custos;
CREATE POLICY custos_own ON custos FOR ALL USING (admin_id = auth.uid());

-- CHAVES PIX
DROP POLICY IF EXISTS pix_own ON chaves_pix;
CREATE POLICY pix_own ON chaves_pix FOR ALL USING (admin_id = auth.uid());

-- PUSH TOKENS
DROP POLICY IF EXISTS push_own ON push_tokens;
CREATE POLICY push_own ON push_tokens FOR ALL USING (user_id = auth.uid());

-- ONBOARDING
DROP POLICY IF EXISTS onboarding_own ON onboarding;
CREATE POLICY onboarding_own ON onboarding FOR ALL USING (admin_id = auth.uid());

-- SLOTS (leitura autenticada; PRO vê tudo, solo vê apenas gratuitos)
DROP POLICY IF EXISTS slots_read ON slots;
CREATE POLICY slots_read ON slots FOR SELECT USING (
  auth.uid() IS NOT NULL
  AND (
    apenas_pro = false
    OR EXISTS (
      SELECT 1 FROM assinaturas
      WHERE assinaturas.admin_id = auth.uid()
        AND assinaturas.plano    = 'pro'
        AND assinaturas.status  IN ('ativa', 'trial')
    )
  )
);


-- ════════════════════════════════════════════════════════════
-- REALTIME
-- ════════════════════════════════════════════════════════════

DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE metas;    EXCEPTION WHEN OTHERS THEN null; END $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE remessas; EXCEPTION WHEN OTHERS THEN null; END $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE custos;   EXCEPTION WHEN OTHERS THEN null; END $$;


-- ════════════════════════════════════════════════════════════
-- ÍNDICES
-- ════════════════════════════════════════════════════════════

CREATE INDEX IF NOT EXISTS idx_metas_admin_id      ON metas(admin_id);
CREATE INDEX IF NOT EXISTS idx_metas_status        ON metas(status);
CREATE INDEX IF NOT EXISTS idx_metas_operador_id   ON metas(operador_id);
CREATE INDEX IF NOT EXISTS idx_remessas_meta_id    ON remessas(meta_id);
CREATE INDEX IF NOT EXISTS idx_remessas_created_at ON remessas(created_at);
CREATE INDEX IF NOT EXISTS idx_custos_admin_id     ON custos(admin_id);
CREATE INDEX IF NOT EXISTS idx_custos_data         ON custos(data);
CREATE INDEX IF NOT EXISTS idx_operadores_admin_id ON operadores(admin_id);
CREATE INDEX IF NOT EXISTS idx_operadores_token    ON operadores(convite_token);


-- ════════════════════════════════════════════════════════════
-- pg_cron: expirar trials diariamente às 03:00 UTC
-- (requer extensão pg_cron habilitada no Supabase)
-- ════════════════════════════════════════════════════════════

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    PERFORM cron.unschedule('expire-trials');
    PERFORM cron.schedule('expire-trials', '0 3 * * *', 'SELECT expire_trials()');
  END IF;
EXCEPTION WHEN OTHERS THEN null;
END $$;
