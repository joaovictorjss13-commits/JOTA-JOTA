-- ============================================================
-- Migration 023 — Adiciona plano 'infinit' (900 dias)
-- Mesma regra do 021: ALTER TYPE deve ser commitado sozinho.
-- ============================================================
ALTER TYPE plano_tipo ADD VALUE IF NOT EXISTS 'infinit';
