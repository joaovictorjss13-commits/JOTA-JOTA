-- Migration: adiciona rede_sigla como coluna de texto em metas
-- Isso evita a dependência de FK com a tabela redes para o fluxo solo

alter table metas add column if not exists rede_sigla text default '';
