-- ============================================================
-- MetaControll — Realtime & Função evolução mensal
-- ============================================================

-- Habilitar Realtime nas tabelas críticas
-- Execute no Supabase Dashboard > Database > Replication
-- Ou via SQL:

alter publication supabase_realtime add table metas;
alter publication supabase_realtime add table remessas;
alter publication supabase_realtime add table custos;

-- ────────────────────────────────────────────────────────────
-- Função RPC: evolução mensal do lucro (últimos 12 meses)
-- Chamada: supabase.rpc('evolucao_mensal', { p_admin_id: '...' })
-- ────────────────────────────────────────────────────────────
create or replace function evolucao_mensal(p_admin_id uuid)
returns table(mes text, lucro numeric, metas_fechadas bigint)
language sql security definer as $$
  select
    to_char(date_trunc('month', fechada_at), 'MM/YY') as mes,
    sum(resultado_liquido)                             as lucro,
    count(*)                                           as metas_fechadas
  from metas
  where admin_id   = p_admin_id
    and status     = 'fechada'
    and fechada_at >= now() - interval '12 months'
  group by date_trunc('month', fechada_at)
  order by date_trunc('month', fechada_at);
$$;

-- ────────────────────────────────────────────────────────────
-- Índices para performance
-- ────────────────────────────────────────────────────────────
create index idx_metas_admin_id      on metas(admin_id);
create index idx_metas_status        on metas(status);
create index idx_metas_operador_id   on metas(operador_id);
create index idx_remessas_meta_id    on remessas(meta_id);
create index idx_remessas_created_at on remessas(created_at);
create index idx_custos_admin_id     on custos(admin_id);
create index idx_custos_data         on custos(data);
create index idx_operadores_admin_id on operadores(admin_id);
create index idx_operadores_token    on operadores(convite_token);
