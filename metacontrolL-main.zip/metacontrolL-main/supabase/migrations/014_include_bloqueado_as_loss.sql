-- ============================================================
-- Migration 014 — Contabiliza remessas 'bloqueado' como perda
-- no resultado_liquido e prejuizo_acum da meta.
-- Depósito bloqueado = dinheiro perdido (saque nunca retornou).
-- ============================================================

CREATE OR REPLACE FUNCTION recalcular_meta()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_dep        numeric(12,2);
  v_saque      numeric(12,2);
  v_bloqueado  numeric(12,2);
  v_prejuizo   numeric(12,2);
  v_total      int;
  v_positivas  int;
  v_contas     int;
  v_meta_id    uuid;
BEGIN
  v_meta_id := COALESCE(NEW.meta_id, OLD.meta_id);

  -- Remessas normais: base do cálculo
  SELECT
    COALESCE(SUM(deposito), 0),
    COALESCE(SUM(saque), 0),
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0),
    COUNT(*),
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END),
    COALESCE(SUM(contas), 0)
  INTO v_dep, v_saque, v_prejuizo, v_total, v_positivas, v_contas
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'normal';

  -- Remessas bloqueadas: depósito é perdido (saque nunca saiu)
  SELECT COALESCE(SUM(deposito), 0)
  INTO v_bloqueado
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'bloqueado';

  UPDATE metas SET
    deposito_total    = v_dep,
    saque_total       = v_saque,
    prejuizo_acum     = v_prejuizo + v_bloqueado,
    resultado_liquido = v_saque - v_dep - v_bloqueado,
    taxa_acerto       = CASE WHEN v_total = 0 THEN 0 ELSE ROUND((v_positivas::numeric / v_total) * 100, 2) END,
    score             = CASE WHEN v_total = 0 THEN 0 ELSE LEAST(100, ROUND((v_positivas::numeric / v_total) * 100)) END,
    contas_atingidas  = v_contas,
    updated_at        = now()
  WHERE id = v_meta_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Recalcula todos os dados históricos existentes com nova lógica
WITH bloqueados AS (
  SELECT meta_id, COALESCE(SUM(deposito), 0) AS blq
  FROM remessas
  WHERE status = 'bloqueado'
  GROUP BY meta_id
),
normais AS (
  SELECT
    meta_id,
    COALESCE(SUM(deposito), 0)                                                                       AS dep,
    COALESCE(SUM(saque), 0)                                                                          AS saq,
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0)        AS prej,
    COUNT(*)                                                                                         AS total,
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END)                                              AS pos,
    COALESCE(SUM(contas), 0)                                                                         AS cont
  FROM remessas
  WHERE status = 'normal'
  GROUP BY meta_id
)
UPDATE metas m SET
  deposito_total    = COALESCE(n.dep, 0),
  saque_total       = COALESCE(n.saq, 0),
  prejuizo_acum     = COALESCE(n.prej, 0) + COALESCE(b.blq, 0),
  resultado_liquido = COALESCE(n.saq, 0) - COALESCE(n.dep, 0) - COALESCE(b.blq, 0),
  taxa_acerto       = CASE WHEN COALESCE(n.total, 0) = 0 THEN 0 ELSE ROUND((n.pos::numeric / n.total) * 100, 2) END,
  score             = CASE WHEN COALESCE(n.total, 0) = 0 THEN 0 ELSE LEAST(100, ROUND((n.pos::numeric / n.total) * 100)) END,
  contas_atingidas  = COALESCE(n.cont, 0),
  updated_at        = now()
FROM (SELECT id FROM metas WHERE status != 'lixeira') sub
LEFT JOIN normais n ON n.meta_id = sub.id
LEFT JOIN bloqueados b ON b.meta_id = sub.id
WHERE m.id = sub.id;
