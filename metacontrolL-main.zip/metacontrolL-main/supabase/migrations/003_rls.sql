-- ============================================================
-- MetaControll — Row Level Security (RLS)
-- Cada usuário vê APENAS seus próprios dados
-- ============================================================

-- Habilitar RLS em todas as tabelas
alter table admins          enable row level security;
alter table assinaturas     enable row level security;
alter table operadores      enable row level security;
alter table redes           enable row level security;
alter table metas           enable row level security;
alter table remessas        enable row level security;
alter table custos          enable row level security;
alter table chaves_pix      enable row level security;
alter table push_tokens     enable row level security;
alter table onboarding      enable row level security;
alter table slots           enable row level security;

-- ────────────────────────────────────────────────────────────
-- ADMINS — só vê/edita o próprio perfil
-- ────────────────────────────────────────────────────────────
create policy "admin_select_own" on admins
  for select using (auth.uid() = id);

create policy "admin_update_own" on admins
  for update using (auth.uid() = id);

create policy "admin_insert_own" on admins
  for insert with check (auth.uid() = id);

-- ────────────────────────────────────────────────────────────
-- ASSINATURAS
-- ────────────────────────────────────────────────────────────
create policy "assinatura_own" on assinaturas
  for all using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- OPERADORES
-- Admin vê todos os operadores seus
-- Operador vê apenas a si mesmo
-- ────────────────────────────────────────────────────────────
create policy "operador_admin_select" on operadores
  for select using (
    admin_id = auth.uid()
    or user_id = auth.uid()
  );

create policy "operador_admin_insert" on operadores
  for insert with check (admin_id = auth.uid());

create policy "operador_admin_update" on operadores
  for update using (
    admin_id = auth.uid()
    or user_id = auth.uid()
  );

create policy "operador_admin_delete" on operadores
  for delete using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- REDES
-- ────────────────────────────────────────────────────────────
create policy "redes_own" on redes
  for all using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- METAS
-- Admin vê todas as suas metas
-- Operador vê metas onde está vinculado
-- ────────────────────────────────────────────────────────────
create policy "metas_admin_all" on metas
  for all using (admin_id = auth.uid());

create policy "metas_operador_select" on metas
  for select using (
    exists (
      select 1 from operadores
      where operadores.id = metas.operador_id
        and operadores.user_id = auth.uid()
    )
  );

-- ────────────────────────────────────────────────────────────
-- REMESSAS
-- Admin vê todas as remessas de suas metas
-- Operador vê remessas de metas que lhe pertencem
-- ────────────────────────────────────────────────────────────
create policy "remessas_admin_all" on remessas
  for all using (
    exists (
      select 1 from metas
      where metas.id = remessas.meta_id
        and metas.admin_id = auth.uid()
    )
  );

create policy "remessas_operador" on remessas
  for all using (
    exists (
      select 1 from operadores
      where operadores.id = remessas.operador_id
        and operadores.user_id = auth.uid()
    )
  );

-- ────────────────────────────────────────────────────────────
-- CUSTOS
-- ────────────────────────────────────────────────────────────
create policy "custos_own" on custos
  for all using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- CHAVES PIX
-- ────────────────────────────────────────────────────────────
create policy "pix_own" on chaves_pix
  for all using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- PUSH TOKENS
-- ────────────────────────────────────────────────────────────
create policy "push_own" on push_tokens
  for all using (user_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- ONBOARDING
-- ────────────────────────────────────────────────────────────
create policy "onboarding_own" on onboarding
  for all using (admin_id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- SLOTS — leitura pública para todos autenticados
-- PRO: todos os slots | SOLO: apenas os não PRO
-- ────────────────────────────────────────────────────────────
create policy "slots_free" on slots
  for select using (
    auth.uid() is not null
    and (
      apenas_pro = false
      or exists (
        select 1 from assinaturas
        where assinaturas.admin_id = auth.uid()
          and assinaturas.plano = 'pro'
          and assinaturas.status = 'ativa'
      )
    )
  );
