-- Muda trial de 7 dias para 3 dias
-- Execute no Supabase SQL Editor

ALTER TABLE assinaturas
  ALTER COLUMN trial_ends_at SET DEFAULT (now() + interval '3 days');

CREATE OR REPLACE FUNCTION handle_new_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO assinaturas (admin_id, plano, status, trial_ends_at)
  VALUES (NEW.id, 'pro', 'trial', now() + interval '3 days')
  ON CONFLICT (admin_id) DO NOTHING;

  INSERT INTO onboarding (admin_id)
  VALUES (NEW.id)
  ON CONFLICT (admin_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_admin_created ON admins;
CREATE TRIGGER on_admin_created
  AFTER INSERT ON admins
  FOR EACH ROW EXECUTE FUNCTION handle_new_admin();
