-- ============================================================
-- Migration 024 — Expiração de convites de operador
--
-- Adiciona convite_expira_em à tabela operadores.
-- Convites gerados agora expiram em 7 dias.
-- A rota de aceitação valida a expiração antes de criar a conta.
-- ============================================================

ALTER TABLE operadores
  ADD COLUMN IF NOT EXISTS convite_expira_em timestamptz;

-- Popula retroativamente: convites pendentes expiram em 7 dias a partir de agora
UPDATE operadores
SET convite_expira_em = now() + interval '7 days'
WHERE convite_usado = false
  AND convite_expira_em IS NULL;
