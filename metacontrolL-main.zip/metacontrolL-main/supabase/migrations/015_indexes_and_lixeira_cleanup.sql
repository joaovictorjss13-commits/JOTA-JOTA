-- ============================================================
-- Migration 015 — Indexes de performance + limpeza ao mover
-- meta para lixeira + recalculo forçado de todas as metas.
--
-- Problemas resolvidos:
--  1. Consultas de dashboard eram lentas sem índice em (admin_id, status)
--  2. Ao mover meta para lixeira, seus totais acumulados continuavam
--     na linha do banco (não causavam bug, mas poluíam dados)
--  3. recalcular_meta já inclui 'bloqueado' como perda (014), esta
--     migration apenas garante que metas na lixeira fiquem zeradas.
-- ============================================================

-- ─── 1. ÍNDICES DE PERFORMANCE ─────────────────────────────────────────────

-- Dashboard principal: filtra por admin + exclui lixeira + ordena por data
CREATE INDEX IF NOT EXISTS idx_metas_admin_status
  ON metas (admin_id, status)
  WHERE status <> 'lixeira';

-- Busca de remessas por meta (usada em recalcular_meta e no modal de detalhes)
CREATE INDEX IF NOT EXISTS idx_remessas_meta_status
  ON remessas (meta_id, status);

-- Ordenação cronológica de metas por admin
CREATE INDEX IF NOT EXISTS idx_metas_admin_created
  ON metas (admin_id, created_at DESC);

-- Ordenação cronológica de remessas por meta
CREATE INDEX IF NOT EXISTS idx_remessas_meta_created
  ON remessas (meta_id, created_at DESC);


-- ─── 2. FUNÇÃO: zerar aggregados ao mover meta para lixeira ────────────────
--
-- Quando o operador descarta uma meta (status → lixeira), zeramos seus
-- campos acumulados para que qualquer consulta por JOIN/agregação bruta
-- não some valores de metas descartadas.

CREATE OR REPLACE FUNCTION on_meta_lixeira()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF NEW.status = 'lixeira' AND OLD.status <> 'lixeira' THEN
    NEW.deposito_total    := 0;
    NEW.saque_total       := 0;
    NEW.resultado_liquido := 0;
    NEW.prejuizo_acum     := 0;
    NEW.taxa_acerto       := 0;
    NEW.score             := 0;
    NEW.contas_atingidas  := 0;
    NEW.updated_at        := now();
  END IF;
  RETURN NEW;
END;
$$;

-- Remove trigger anterior se existir e recria
DROP TRIGGER IF EXISTS trg_meta_lixeira ON metas;

CREATE TRIGGER trg_meta_lixeira
  BEFORE UPDATE OF status ON metas
  FOR EACH ROW
  EXECUTE FUNCTION on_meta_lixeira();


-- ─── 3. RETROATIVO: zera metas já na lixeira ───────────────────────────────

UPDATE metas SET
  deposito_total    = 0,
  saque_total       = 0,
  resultado_liquido = 0,
  prejuizo_acum     = 0,
  taxa_acerto       = 0,
  score             = 0,
  contas_atingidas  = 0,
  updated_at        = now()
WHERE status = 'lixeira'
  AND (deposito_total <> 0 OR saque_total <> 0 OR resultado_liquido <> 0);


-- ─── 4. RECALCULO COMPLETO (inclui bloqueado como perda — mantém 014) ──────
--
-- Reexecuta o mesmo recalculo da migration 014 para garantir consistência
-- em todos os ambientes onde esta migration é aplicada.

WITH bloqueados AS (
  SELECT meta_id, COALESCE(SUM(deposito), 0) AS blq
  FROM remessas
  WHERE status = 'bloqueado'
  GROUP BY meta_id
),
normais AS (
  SELECT
    meta_id,
    COALESCE(SUM(deposito), 0)                                                                    AS dep,
    COALESCE(SUM(saque), 0)                                                                       AS saq,
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0)     AS prej,
    COUNT(*)                                                                                      AS total,
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END)                                           AS pos,
    COALESCE(SUM(contas), 0)                                                                      AS cont
  FROM remessas
  WHERE status = 'normal'
  GROUP BY meta_id
)
UPDATE metas m SET
  deposito_total    = COALESCE(n.dep,  0),
  saque_total       = COALESCE(n.saq,  0),
  prejuizo_acum     = COALESCE(n.prej, 0) + COALESCE(b.blq, 0),
  resultado_liquido = COALESCE(n.saq,  0) - COALESCE(n.dep, 0) - COALESCE(b.blq, 0),
  taxa_acerto = CASE
    WHEN COALESCE(n.total, 0) = 0 THEN 0
    ELSE ROUND((n.pos::numeric / n.total) * 100, 2)
  END,
  score = CASE
    WHEN COALESCE(n.total, 0) = 0 THEN 0
    ELSE LEAST(100, ROUND((n.pos::numeric / n.total) * 100))
  END,
  contas_atingidas = COALESCE(n.cont, 0),
  updated_at       = now()
FROM (SELECT id FROM metas WHERE status <> 'lixeira') sub
LEFT JOIN normais    n ON n.meta_id = sub.id
LEFT JOIN bloqueados b ON b.meta_id = sub.id
WHERE m.id = sub.id;
