-- ============================================================
-- Migration 023 — Lixeira para remessas + restauração
--
-- Mudanças:
--   1. Adiciona 'lixeira' ao enum remessa_status
--   2. Adiciona deleted_at e status_anterior em remessas
--   3. Adiciona lixeira_at e status_anterior em metas
--   4. Atualiza on_meta_lixeira(): preserva dados (remove zeragem),
--      salva status_anterior e lixeira_at; ao restaurar, recalcula
--      agregados a partir das remessas
--   5. Cria limpar_lixeira(): exclui itens na lixeira há >1 dia
--      apenas para usuários no plano trial
--   6. Agenda pg_cron para limpar_lixeira() diariamente às 04:00 UTC
--   7. RPC atualizar_vencimento(date) — exclusivo plano PRO
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Adiciona 'lixeira' ao enum remessa_status
--    Técnica: convert to text → drop → recreate com novo valor
-- ────────────────────────────────────────────────────────────
ALTER TABLE remessas ALTER COLUMN status TYPE text;
DROP TYPE IF EXISTS remessa_status CASCADE;
CREATE TYPE remessa_status AS ENUM ('normal', 'pendente', 'bloqueado', 'analise', 'lixeira');
ALTER TABLE remessas
  ALTER COLUMN status TYPE remessa_status USING status::remessa_status,
  ALTER COLUMN status SET DEFAULT 'normal';

-- ────────────────────────────────────────────────────────────
-- 2. Colunas extras em remessas
--    deleted_at  : momento em que foi movida para lixeira
--    status_anterior : status original para restauração
-- ────────────────────────────────────────────────────────────
ALTER TABLE remessas
  ADD COLUMN IF NOT EXISTS deleted_at      timestamptz,
  ADD COLUMN IF NOT EXISTS status_anterior remessa_status;

-- ────────────────────────────────────────────────────────────
-- 3. Colunas extras em metas
--    lixeira_at      : momento em que foi movida para lixeira
--    status_anterior : status original para restauração
-- ────────────────────────────────────────────────────────────
ALTER TABLE metas
  ADD COLUMN IF NOT EXISTS lixeira_at      timestamptz,
  ADD COLUMN IF NOT EXISTS status_anterior meta_status;

-- ────────────────────────────────────────────────────────────
-- 4. Atualiza on_meta_lixeira()
--    Ao entrar na lixeira: preserva dados, salva status anterior.
--    Ao sair da lixeira  : recalcula agregados a partir das remessas
--                          (necessário pois migration 015 zerou metas
--                          que já estavam na lixeira).
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION on_meta_lixeira()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_dep    numeric(12,2);
  v_saque  numeric(12,2);
  v_bloq   numeric(12,2);
  v_prej   numeric(12,2);
  v_total  int;
  v_pos    int;
  v_contas int;
BEGIN
  -- Entrando na lixeira: salva status anterior e timestamp
  IF NEW.status = 'lixeira' AND OLD.status <> 'lixeira' THEN
    NEW.status_anterior := OLD.status;
    NEW.lixeira_at      := now();
    NEW.updated_at      := now();
  END IF;

  -- Saindo da lixeira (restauração): recalcula agregados
  IF OLD.status = 'lixeira' AND NEW.status <> 'lixeira' THEN
    SELECT
      COALESCE(SUM(deposito), 0),
      COALESCE(SUM(saque), 0),
      COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0),
      COUNT(*),
      COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END),
      COALESCE(SUM(contas), 0)
    INTO v_dep, v_saque, v_prej, v_total, v_pos, v_contas
    FROM remessas
    WHERE meta_id = NEW.id AND status = 'normal';

    SELECT COALESCE(SUM(deposito), 0)
    INTO v_bloq
    FROM remessas
    WHERE meta_id = NEW.id AND status = 'bloqueado';

    NEW.deposito_total    := v_dep;
    NEW.saque_total       := v_saque;
    NEW.bloqueado_total   := v_bloq;
    NEW.prejuizo_acum     := v_prej + v_bloq;
    NEW.resultado_liquido := v_saque - v_dep - v_bloq;
    NEW.taxa_acerto       := CASE WHEN v_total = 0 THEN 0
                                  ELSE ROUND((v_pos::numeric / v_total) * 100, 2) END;
    NEW.score             := CASE WHEN v_total = 0 THEN 0
                                  ELSE LEAST(100, ROUND((v_pos::numeric / v_total) * 100)) END;
    NEW.contas_atingidas  := v_contas;
    NEW.status_anterior   := NULL;
    NEW.lixeira_at        := NULL;
    NEW.updated_at        := now();
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_meta_lixeira ON metas;
CREATE TRIGGER trg_meta_lixeira
  BEFORE UPDATE OF status ON metas
  FOR EACH ROW
  EXECUTE FUNCTION on_meta_lixeira();

-- Popula lixeira_at retroativamente para metas já na lixeira
UPDATE metas
SET lixeira_at = updated_at
WHERE status = 'lixeira' AND lixeira_at IS NULL;

-- ────────────────────────────────────────────────────────────
-- 5. limpar_lixeira()
--    Exclui permanentemente remessas e metas na lixeira há mais
--    de 1 dia — somente para admins no plano trial.
--    PRO: itens permanecem na lixeira até exclusão manual.
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION limpar_lixeira()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  -- Remessas na lixeira há >1 dia (admins trial)
  DELETE FROM remessas
  WHERE status = 'lixeira'
    AND deleted_at <= now() - interval '1 day'
    AND meta_id IN (
      SELECT m.id FROM metas m
      JOIN admins a ON a.id = m.admin_id
      WHERE a.plano = 'trial'
    );

  -- Metas na lixeira há >1 dia (admins trial)
  DELETE FROM metas
  WHERE status = 'lixeira'
    AND lixeira_at <= now() - interval '1 day'
    AND admin_id IN (
      SELECT id FROM admins WHERE plano = 'trial'
    );
END;
$$;

-- ────────────────────────────────────────────────────────────
-- 6. Agenda limpeza diária às 04:00 UTC
-- ────────────────────────────────────────────────────────────
SELECT cron.schedule(
  'limpar-lixeira-trial',
  '0 4 * * *',
  'SELECT limpar_lixeira()'
);

-- ────────────────────────────────────────────────────────────
-- 7. RPC atualizar_vencimento(date) — somente plano PRO
--    Permite que o admin PRO altere a data de vencimento
--    da assinatura via painel.
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION atualizar_vencimento(p_vencimento date)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM assinaturas
    WHERE admin_id = auth.uid()
      AND plano = 'pro'
      AND status = 'ativa'
  ) THEN
    RAISE EXCEPTION 'Apenas o plano PRO pode alterar a data de vencimento';
  END IF;

  UPDATE assinaturas
  SET vencimento = p_vencimento, updated_at = now()
  WHERE admin_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION atualizar_vencimento(date) TO authenticated;
