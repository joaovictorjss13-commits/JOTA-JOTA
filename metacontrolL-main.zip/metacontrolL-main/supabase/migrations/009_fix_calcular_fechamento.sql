-- Fix: trigger calcular_fechamento usava colunas erradas (custo_fixo/taxa_agente)
-- e subtraía salario/bau em vez de somar.
-- Fórmula correta: resultado_liquido + salario + bau - gastos_operacionais

CREATE OR REPLACE FUNCTION calcular_fechamento()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'fechada' AND OLD.status != 'fechada' THEN
    NEW.lucro_final := NEW.resultado_liquido
                       + COALESCE(NEW.salario, 0)
                       + COALESCE(NEW.bau, 0)
                       - COALESCE(NEW.gastos_operacionais, 0);
    NEW.fechada_at := now();
    UPDATE onboarding SET fechou_com_custos = true, updated_at = now() WHERE admin_id = NEW.admin_id;
  END IF;

  IF NEW.status = 'finalizada' AND OLD.status = 'ativa' THEN
    NEW.finalizada_at := now();
    UPDATE onboarding SET finalizou_meta = true, updated_at = now() WHERE admin_id = NEW.admin_id;
  END IF;

  RETURN NEW;
END;
$$;
