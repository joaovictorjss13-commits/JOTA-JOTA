-- ============================================================
-- MetaControll — Trial PRO 7 dias
-- Execute no Supabase SQL Editor
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Ajustar padrões: novo admin começa como 'pro' + trial 7 dias
-- ────────────────────────────────────────────────────────────
ALTER TABLE admins
  ALTER COLUMN plano SET DEFAULT 'pro';

ALTER TABLE assinaturas
  ALTER COLUMN trial_ends_at SET DEFAULT (now() + interval '7 days'),
  ALTER COLUMN plano SET DEFAULT 'pro';

-- ────────────────────────────────────────────────────────────
-- 2. Trigger: ao criar admin → assinatura trial PRO + onboarding
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION handle_new_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO assinaturas (admin_id, plano, status, trial_ends_at)
  VALUES (NEW.id, 'pro', 'trial', now() + interval '7 days')
  ON CONFLICT (admin_id) DO NOTHING;

  INSERT INTO onboarding (admin_id)
  VALUES (NEW.id)
  ON CONFLICT (admin_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_admin_created ON admins;
CREATE TRIGGER on_admin_created
  AFTER INSERT ON admins
  FOR EACH ROW EXECUTE FUNCTION handle_new_admin();

-- ────────────────────────────────────────────────────────────
-- 3. Função: expira trials vencidos → downgrade para solo
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION expire_trials()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Downgrade admin.plano para 'solo'
  UPDATE admins
  SET plano = 'solo', updated_at = now()
  WHERE plano = 'pro'
    AND id IN (
      SELECT admin_id FROM assinaturas
      WHERE status = 'trial'
        AND trial_ends_at <= now()
    );

  -- Marca assinatura como cancelada
  UPDATE assinaturas
  SET status = 'cancelada', updated_at = now()
  WHERE status = 'trial'
    AND trial_ends_at <= now();
END;
$$;

-- ────────────────────────────────────────────────────────────
-- 4. pg_cron: roda expire_trials() todo dia às 03:00 UTC
-- ────────────────────────────────────────────────────────────
SELECT cron.unschedule('expire-trials') WHERE EXISTS (
  SELECT 1 FROM cron.job WHERE jobname = 'expire-trials'
);

SELECT cron.schedule(
  'expire-trials',
  '0 3 * * *',
  'SELECT expire_trials()'
);

-- ────────────────────────────────────────────────────────────
-- 5. RLS: admin pode ler sua própria assinatura
-- ────────────────────────────────────────────────────────────
ALTER TABLE assinaturas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin lê sua assinatura" ON assinaturas;
CREATE POLICY "admin lê sua assinatura"
  ON assinaturas FOR SELECT
  USING (admin_id = auth.uid());

DROP POLICY IF EXISTS "admin lê seu perfil" ON admins;
CREATE POLICY "admin lê seu perfil"
  ON admins FOR SELECT
  USING (id = auth.uid());
