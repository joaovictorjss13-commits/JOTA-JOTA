-- ============================================================
-- MetaControll — Schema completo
-- Execute no Supabase SQL Editor
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- EXTENSÕES
-- ────────────────────────────────────────────────────────────
create extension if not exists "uuid-ossp";
create extension if not exists "pg_cron";

-- ────────────────────────────────────────────────────────────
-- ENUMS
-- ────────────────────────────────────────────────────────────
create type plano_tipo       as enum ('solo', 'pro');
create type assinatura_status as enum ('trial', 'ativa', 'cancelada', 'inadimplente');
create type meta_status      as enum ('ativa', 'finalizada', 'fechada', 'lixeira');
create type meta_modelo      as enum ('salario_bau', 'apenas_bau');
create type remessa_status   as enum ('normal', 'perdeu', 'bloqueio', 'noite');
create type remessa_tipo     as enum ('remessa', 'sync', 'ajuste');
create type custo_tipo       as enum ('proxy', 'sms', 'instagram', 'bot', 'vps', 'outros');
create type operador_status  as enum ('ativo', 'inativo', 'pendente');

-- ────────────────────────────────────────────────────────────
-- ADMINS
-- Estende auth.users do Supabase
-- ────────────────────────────────────────────────────────────
create table admins (
  id              uuid primary key references auth.users(id) on delete cascade,
  nome            text not null,
  email           text not null unique,
  plano           plano_tipo not null default 'solo',
  meta_global     numeric(12,2) default 0,
  notificacoes    boolean default true,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- ASSINATURAS
-- ────────────────────────────────────────────────────────────
create table assinaturas (
  id                  uuid primary key default uuid_generate_v4(),
  admin_id            uuid not null references admins(id) on delete cascade,
  plano               plano_tipo not null default 'solo',
  qtd_operadores      int not null default 0,
  valor_base          numeric(10,2) not null default 39.90,
  valor_por_operador  numeric(10,2) not null default 11.90,
  valor_mensal        numeric(10,2) generated always as (
                        valor_base + (qtd_operadores * valor_por_operador)
                      ) stored,
  status              assinatura_status not null default 'trial',
  trial_ends_at       timestamptz default (now() + interval '3 days'),
  vencimento          date,
  gateway_sub_id      text,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now(),
  unique(admin_id)
);

-- ────────────────────────────────────────────────────────────
-- OPERADORES
-- ────────────────────────────────────────────────────────────
create table operadores (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid references auth.users(id) on delete set null,
  admin_id        uuid not null references admins(id) on delete cascade,
  nome            text not null,
  email           text,
  status          operador_status not null default 'pendente',
  convite_token   text unique default encode(gen_random_bytes(16), 'hex'),
  convite_usado   boolean default false,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- REDES (redes afiliadas)
-- ────────────────────────────────────────────────────────────
create table redes (
  id         uuid primary key default uuid_generate_v4(),
  admin_id   uuid not null references admins(id) on delete cascade,
  nome       text not null,
  sigla      text not null,
  created_at timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- SLOTS (catálogo premium)
-- ────────────────────────────────────────────────────────────
create table slots (
  id           uuid primary key default uuid_generate_v4(),
  nome         text not null,
  provider     text not null,
  rtp          numeric(5,2),
  categoria    text,
  imagem_url   text,
  destaque     boolean default false,
  apenas_pro   boolean default true,
  created_at   timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- METAS
-- ────────────────────────────────────────────────────────────
create table metas (
  id                  uuid primary key default uuid_generate_v4(),
  admin_id            uuid not null references admins(id) on delete cascade,
  operador_id         uuid references operadores(id) on delete set null,
  rede_id             uuid references redes(id) on delete set null,
  titulo              text not null,
  plataforma          text not null,
  contas_total        int not null default 10,
  contas_atingidas    int not null default 0,
  modelo              meta_modelo not null default 'salario_bau',
  status              meta_status not null default 'ativa',

  -- Agregados (atualizados via trigger)
  deposito_total      numeric(12,2) not null default 0,
  saque_total         numeric(12,2) not null default 0,
  lucro_bruto         numeric(12,2) generated always as (saque_total - deposito_total) stored,
  prejuizo_acum       numeric(12,2) not null default 0,
  resultado_liquido   numeric(12,2) not null default 0,
  taxa_acerto         numeric(5,2) not null default 0,
  score               int not null default 0 check (score between 0 and 100),

  -- Fechamento com custos
  salario             numeric(10,2) default 0,
  custo_fixo          numeric(10,2) default 0,
  taxa_agente         numeric(10,2) default 0,
  lucro_final         numeric(12,2) default 0,

  finalizada_at       timestamptz,
  fechada_at          timestamptz,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- REMESSAS
-- ────────────────────────────────────────────────────────────
create table remessas (
  id           uuid primary key default uuid_generate_v4(),
  meta_id      uuid not null references metas(id) on delete cascade,
  operador_id  uuid references operadores(id) on delete set null,
  slot_id      uuid references slots(id) on delete set null,
  titulo       text,
  tipo         remessa_tipo not null default 'remessa',
  saldo_ini    numeric(12,2) default 0,
  contas       int not null default 1,
  deposito     numeric(12,2) not null default 0,
  saque        numeric(12,2) not null default 0,
  resultado    numeric(12,2) generated always as (saque - deposito) stored,
  status       remessa_status not null default 'normal',
  notas        text,
  created_at   timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- CUSTOS
-- ────────────────────────────────────────────────────────────
create table custos (
  id         uuid primary key default uuid_generate_v4(),
  admin_id   uuid not null references admins(id) on delete cascade,
  tipo       custo_tipo not null,
  valor      numeric(10,2) not null check (valor > 0),
  data       date not null default current_date,
  nota       text,
  created_at timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- CHAVES PIX
-- ────────────────────────────────────────────────────────────
create table chaves_pix (
  id         uuid primary key default uuid_generate_v4(),
  admin_id   uuid not null references admins(id) on delete cascade,
  tipo       text not null,  -- cpf, cnpj, email, telefone, aleatoria
  chave      text not null,
  apelido    text,
  created_at timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- NOTIFICAÇÕES (push tokens)
-- ────────────────────────────────────────────────────────────
create table push_tokens (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  token      text not null unique,
  created_at timestamptz default now()
);

-- ────────────────────────────────────────────────────────────
-- CHECKLIST ONBOARDING
-- ────────────────────────────────────────────────────────────
create table onboarding (
  id                   uuid primary key default uuid_generate_v4(),
  admin_id             uuid not null references admins(id) on delete cascade unique,
  criou_meta           boolean default false,
  registrou_remessa    boolean default false,
  finalizou_meta       boolean default false,
  acompanhou_dashboard boolean default false,
  convidou_operador    boolean default false,
  fechou_com_custos    boolean default false,
  updated_at           timestamptz default now()
);
