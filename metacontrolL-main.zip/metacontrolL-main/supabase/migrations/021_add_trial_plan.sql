-- ============================================================
-- Migration 021 — Adiciona 'trial' ao enum plano_tipo
-- NOTA: ALTER TYPE ADD VALUE deve ser commitado sozinho antes
--       de ser usado em qualquer DML na mesma sessão.
--       O restante das mudanças está na migration 022.
-- ============================================================
ALTER TYPE plano_tipo ADD VALUE IF NOT EXISTS 'trial';
