-- ============================================================
-- Migration 020 — Corrige cálculos do dashboard
--
-- Problemas corrigidos:
--   1. Adiciona coluna bloqueado_total em metas para que o
--      filtro 'Tudo' seja consistente com filtros por data
--      (ambos agora mostram depósitos = normal + bloqueado)
--   2. Atualiza recalcular_meta() para preencher bloqueado_total
--   3. Recalcula histórico com a nova coluna
--   4. Adiciona RPC analise_probabilistica() para o painel de IA
--   5. Atualiza vw_faturamento com bloqueado_total
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Nova coluna: bloqueado_total
-- ────────────────────────────────────────────────────────────
ALTER TABLE metas
  ADD COLUMN IF NOT EXISTS bloqueado_total numeric(12,2) NOT NULL DEFAULT 0;

-- ────────────────────────────────────────────────────────────
-- 2. Atualiza trigger recalcular_meta()
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION recalcular_meta()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_dep        numeric(12,2);
  v_saque      numeric(12,2);
  v_bloqueado  numeric(12,2);
  v_prejuizo   numeric(12,2);
  v_total      int;
  v_positivas  int;
  v_contas     int;
  v_meta_id    uuid;
BEGIN
  v_meta_id := COALESCE(NEW.meta_id, OLD.meta_id);

  -- Remessas normais: saque, depósito e métricas de acerto
  SELECT
    COALESCE(SUM(deposito), 0),
    COALESCE(SUM(saque), 0),
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0),
    COUNT(*),
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END),
    COALESCE(SUM(contas), 0)
  INTO v_dep, v_saque, v_prejuizo, v_total, v_positivas, v_contas
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'normal';

  -- Remessas bloqueadas: depósito perdido (saque nunca retornou)
  SELECT COALESCE(SUM(deposito), 0)
  INTO v_bloqueado
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'bloqueado';

  UPDATE metas SET
    deposito_total    = v_dep,
    saque_total       = v_saque,
    bloqueado_total   = v_bloqueado,
    prejuizo_acum     = v_prejuizo + v_bloqueado,
    resultado_liquido = v_saque - v_dep - v_bloqueado,
    taxa_acerto       = CASE WHEN v_total = 0 THEN 0
                             ELSE ROUND((v_positivas::numeric / v_total) * 100, 2) END,
    score             = CASE WHEN v_total = 0 THEN 0
                             ELSE LEAST(100, ROUND((v_positivas::numeric / v_total) * 100)) END,
    contas_atingidas  = v_contas,
    updated_at        = now()
  WHERE id = v_meta_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- ────────────────────────────────────────────────────────────
-- 3. Recalcula histórico completo com bloqueado_total
-- ────────────────────────────────────────────────────────────
WITH bloqueados AS (
  SELECT meta_id, COALESCE(SUM(deposito), 0) AS blq
  FROM remessas
  WHERE status = 'bloqueado'
  GROUP BY meta_id
),
normais AS (
  SELECT
    meta_id,
    COALESCE(SUM(deposito), 0)                                                                  AS dep,
    COALESCE(SUM(saque), 0)                                                                     AS saq,
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0)   AS prej,
    COUNT(*)                                                                                    AS total,
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END)                                         AS pos,
    COALESCE(SUM(contas), 0)                                                                    AS cont
  FROM remessas
  WHERE status = 'normal'
  GROUP BY meta_id
)
UPDATE metas m SET
  deposito_total    = COALESCE(n.dep, 0),
  saque_total       = COALESCE(n.saq, 0),
  bloqueado_total   = COALESCE(b.blq, 0),
  prejuizo_acum     = COALESCE(n.prej, 0) + COALESCE(b.blq, 0),
  resultado_liquido = COALESCE(n.saq, 0) - COALESCE(n.dep, 0) - COALESCE(b.blq, 0),
  taxa_acerto       = CASE WHEN COALESCE(n.total, 0) = 0 THEN 0
                           ELSE ROUND((n.pos::numeric / n.total) * 100, 2) END,
  score             = CASE WHEN COALESCE(n.total, 0) = 0 THEN 0
                           ELSE LEAST(100, ROUND((n.pos::numeric / n.total) * 100)) END,
  contas_atingidas  = COALESCE(n.cont, 0),
  updated_at        = now()
FROM (SELECT id FROM metas WHERE status != 'lixeira') sub
LEFT JOIN normais    n ON n.meta_id = sub.id
LEFT JOIN bloqueados b ON b.meta_id = sub.id
WHERE m.id = sub.id;

-- ────────────────────────────────────────────────────────────
-- 4. RPC analise_probabilistica(p_admin_id)
--    Retorna análise estatística para o painel de IA
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION analise_probabilistica(p_admin_id uuid)
RETURNS TABLE (
  taxa_acerto_geral     numeric,   -- % remessas normais lucrativas (histórico)
  taxa_acerto_tendencia text,      -- 'subindo' | 'caindo' | 'estavel'
  lucro_medio_meta      numeric,   -- AVG resultado_liquido em metas fechadas
  lucro_medio_remessa   numeric,   -- AVG (saque-deposito) por remessa normal
  desvio_padrao         numeric,   -- STDDEV dos resultados por remessa
  melhor_casa           text,      -- plataforma com maior resultado acumulado
  pior_casa             text,      -- plataforma com menor resultado acumulado
  projecao_proxima_meta numeric,   -- estimativa de resultado da próxima meta
  total_remessas        bigint,
  remessas_lucrativas   bigint
) LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_total_rem   bigint;
  v_rem_lucro   bigint;
  v_taxa_geral  numeric;
  v_lucro_med   numeric;
  v_lucro_rem   numeric;
  v_desvio      numeric;
  v_melhor      text;
  v_pior        text;
  v_projecao    numeric;
  v_tendencia   text;
  v_taxa_rec    numeric;
  v_taxa_ant    numeric;
BEGIN
  -- Totais de remessas normais do admin
  SELECT
    COUNT(*),
    COUNT(*) FILTER (WHERE (r.saque - r.deposito) > 0),
    COALESCE(AVG(r.saque - r.deposito), 0),
    COALESCE(STDDEV(r.saque - r.deposito), 0)
  INTO v_total_rem, v_rem_lucro, v_lucro_rem, v_desvio
  FROM remessas r
  JOIN metas m ON m.id = r.meta_id
  WHERE m.admin_id = p_admin_id AND r.status = 'normal';

  v_taxa_geral := CASE
    WHEN v_total_rem = 0 THEN 0
    ELSE ROUND((v_rem_lucro::numeric / v_total_rem) * 100, 2)
  END;

  -- Lucro médio por meta fechada
  SELECT COALESCE(AVG(resultado_liquido), 0)
  INTO v_lucro_med
  FROM metas
  WHERE admin_id = p_admin_id AND status = 'fechada';

  -- Projeção = média histórica (estimativa conservadora)
  v_projecao := ROUND(v_lucro_med, 2);

  -- Melhor plataforma (maior resultado acumulado)
  SELECT plataforma INTO v_melhor
  FROM metas
  WHERE admin_id = p_admin_id AND status != 'lixeira'
  GROUP BY plataforma
  ORDER BY SUM(resultado_liquido) DESC NULLS LAST
  LIMIT 1;

  -- Pior plataforma (menor resultado acumulado)
  SELECT plataforma INTO v_pior
  FROM metas
  WHERE admin_id = p_admin_id AND status != 'lixeira'
    AND plataforma != COALESCE(v_melhor, '')
  GROUP BY plataforma
  ORDER BY SUM(resultado_liquido) ASC NULLS LAST
  LIMIT 1;

  -- Tendência: taxa das últimas 3 metas vs 3 anteriores
  SELECT COALESCE(AVG(taxa_acerto), 0) INTO v_taxa_rec
  FROM (
    SELECT taxa_acerto FROM metas
    WHERE admin_id = p_admin_id AND status != 'lixeira'
    ORDER BY created_at DESC LIMIT 3
  ) sub;

  SELECT COALESCE(AVG(taxa_acerto), 0) INTO v_taxa_ant
  FROM (
    SELECT taxa_acerto FROM metas
    WHERE admin_id = p_admin_id AND status != 'lixeira'
    ORDER BY created_at DESC LIMIT 6 OFFSET 3
  ) sub;

  v_tendencia := CASE
    WHEN v_taxa_rec > v_taxa_ant + 5 THEN 'subindo'
    WHEN v_taxa_rec < v_taxa_ant - 5 THEN 'caindo'
    ELSE 'estavel'
  END;

  RETURN QUERY SELECT
    v_taxa_geral,
    v_tendencia,
    ROUND(v_lucro_med, 2),
    ROUND(v_lucro_rem, 2),
    ROUND(v_desvio, 2),
    v_melhor,
    v_pior,
    v_projecao,
    v_total_rem,
    v_rem_lucro;
END;
$$;

GRANT EXECUTE ON FUNCTION analise_probabilistica(uuid) TO authenticated;

-- ────────────────────────────────────────────────────────────
-- 5. Atualiza vw_faturamento com bloqueado_total
--    DROP + CREATE porque adicionamos colunas — não podemos
--    reordenar/inserir colunas com CREATE OR REPLACE VIEW
-- ────────────────────────────────────────────────────────────
DROP VIEW IF EXISTS vw_faturamento;
CREATE VIEW vw_faturamento AS
SELECT
  a.id                                                            AS admin_id,
  a.nome                                                          AS admin_nome,
  COUNT(m.id)                                                     AS total_metas,
  COUNT(m.id) FILTER (WHERE m.status = 'ativa')                   AS metas_ativas,
  COUNT(m.id) FILTER (WHERE m.status = 'fechada')                 AS metas_fechadas,
  COALESCE(SUM(m.deposito_total), 0)                              AS deposito_total,
  COALESCE(SUM(m.bloqueado_total), 0)                             AS bloqueado_total,
  COALESCE(SUM(m.deposito_total + m.bloqueado_total), 0)          AS deposito_display,
  COALESCE(SUM(m.saque_total), 0)                                 AS saque_total,
  COALESCE(SUM(m.lucro_bruto), 0)                                 AS lucro_bruto,
  COALESCE(SUM(m.prejuizo_acum), 0)                               AS prejuizo_total,
  COALESCE(SUM(m.resultado_liquido), 0)                           AS resultado_liquido,
  COALESCE(SUM(m.lucro_final), 0)                                 AS lucro_final,
  COALESCE(AVG(m.taxa_acerto) FILTER (WHERE m.status = 'fechada'), 0) AS taxa_acerto_media
FROM admins a
LEFT JOIN metas m ON m.admin_id = a.id AND m.status != 'lixeira'
GROUP BY a.id, a.nome;
