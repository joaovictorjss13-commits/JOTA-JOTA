-- RPC chamada pelo cliente quando o trial expira localmente
-- SECURITY DEFINER: roda com permissão de service role
CREATE OR REPLACE FUNCTION expire_my_trial()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Só age se o trial realmente expirou
  UPDATE assinaturas
  SET status = 'cancelada', updated_at = now()
  WHERE admin_id = auth.uid()
    AND status = 'trial'
    AND trial_ends_at <= now();

  UPDATE admins
  SET plano = 'solo', updated_at = now()
  WHERE id = auth.uid()
    AND plano = 'pro'
    AND id IN (
      SELECT admin_id FROM assinaturas
      WHERE admin_id = auth.uid() AND status = 'cancelada'
    );
END;
$$;

GRANT EXECUTE ON FUNCTION expire_my_trial() TO authenticated;
