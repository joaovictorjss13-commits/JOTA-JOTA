-- ============================================================
-- Fix: "Database error saving new user"
-- Cole e execute no Supabase → SQL Editor
-- ============================================================

-- 1. Trigger auth.users → admins (robusto, trata todos os conflitos)
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.admins (id, nome, email, plano)
  VALUES (
    NEW.id,
    COALESCE(
      NEW.raw_user_meta_data->>'nome',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    NEW.email,
    'pro'
  )
  ON CONFLICT DO NOTHING;  -- cobre conflito de id E de email

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Loga o erro mas não bloqueia a criação do usuário
  RAISE LOG 'handle_new_user error (email: %): %', NEW.email, SQLERRM;
  RETURN NEW;
END;
$$;

-- 2. Trigger admins → assinaturas + onboarding (robusto)
CREATE OR REPLACE FUNCTION handle_new_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO assinaturas (admin_id, plano, status, trial_ends_at)
  VALUES (NEW.id, 'pro', 'trial', now() + interval '7 days')
  ON CONFLICT (admin_id) DO NOTHING;

  INSERT INTO onboarding (admin_id)
  VALUES (NEW.id)
  ON CONFLICT (admin_id) DO NOTHING;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'handle_new_admin error (admin: %): %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$;

-- Garante que o nome da função antiga também está atualizado
-- (caso o banco tenha o trigger apontando para on_admin_created)
CREATE OR REPLACE FUNCTION on_admin_created()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO assinaturas (admin_id, plano, status, trial_ends_at)
  VALUES (NEW.id, 'pro', 'trial', now() + interval '7 days')
  ON CONFLICT (admin_id) DO NOTHING;

  INSERT INTO onboarding (admin_id)
  VALUES (NEW.id)
  ON CONFLICT (admin_id) DO NOTHING;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'on_admin_created error (admin: %): %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$;

-- 3. Recria os triggers garantindo a versão correta
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

DROP TRIGGER IF EXISTS on_admin_created  ON admins;
DROP TRIGGER IF EXISTS trg_admin_created ON admins;
CREATE TRIGGER trg_admin_created
  AFTER INSERT ON admins
  FOR EACH ROW EXECUTE FUNCTION handle_new_admin();
