-- ============================================================
-- MetaControll — Triggers & Lógica de negócio
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- TRIGGER: Recalcular agregados da meta após remessa
-- Executa toda vez que uma remessa é inserida, atualizada ou deletada
-- ────────────────────────────────────────────────────────────
create or replace function recalcular_meta()
returns trigger language plpgsql security definer as $$
declare
  v_dep          numeric(12,2);
  v_saque        numeric(12,2);
  v_prejuizo     numeric(12,2);
  v_total_rem    int;
  v_positivas    int;
  v_contas       int;
  v_score        int;
  v_meta_id      uuid;
begin
  -- Determina o meta_id da remessa afetada
  v_meta_id := coalesce(NEW.meta_id, OLD.meta_id);

  -- Recalcula totais
  select
    coalesce(sum(deposito), 0),
    coalesce(sum(saque), 0),
    coalesce(sum(case when resultado < 0 then abs(resultado) else 0 end), 0),
    count(*),
    count(case when resultado > 0 then 1 end),
    coalesce(sum(contas), 0)
  into v_dep, v_saque, v_prejuizo, v_total_rem, v_positivas, v_contas
  from remessas
  where meta_id = v_meta_id;

  -- Taxa de acerto
  v_score := case
    when v_total_rem = 0 then 0
    else round((v_positivas::numeric / v_total_rem) * 100)
  end;

  -- Atualiza a meta
  update metas set
    deposito_total    = v_dep,
    saque_total       = v_saque,
    prejuizo_acum     = v_prejuizo,
    resultado_liquido = v_saque - v_dep,
    taxa_acerto       = case when v_total_rem = 0 then 0
                          else round((v_positivas::numeric / v_total_rem) * 100, 2) end,
    score             = v_score,
    contas_atingidas  = v_contas,
    updated_at        = now()
  where id = v_meta_id;

  return coalesce(NEW, OLD);
end;
$$;

create trigger trg_recalcular_meta
after insert or update or delete on remessas
for each row execute function recalcular_meta();

-- ────────────────────────────────────────────────────────────
-- TRIGGER: Fechar meta com custos — calcula lucro_final
-- ────────────────────────────────────────────────────────────
create or replace function calcular_fechamento()
returns trigger language plpgsql as $$
begin
  if NEW.status = 'fechada' and OLD.status != 'fechada' then
    NEW.lucro_final := NEW.resultado_liquido
                       - coalesce(NEW.salario, 0)
                       - coalesce(NEW.custo_fixo, 0)
                       - coalesce(NEW.taxa_agente, 0);
    NEW.fechada_at := now();

    -- Marcar onboarding
    update onboarding
    set fechou_com_custos = true, updated_at = now()
    where admin_id = NEW.admin_id;
  end if;

  if NEW.status = 'finalizada' and OLD.status = 'ativa' then
    NEW.finalizada_at := now();

    update onboarding
    set finalizou_meta = true, updated_at = now()
    where admin_id = NEW.admin_id;
  end if;

  return NEW;
end;
$$;

create trigger trg_calcular_fechamento
before update on metas
for each row execute function calcular_fechamento();

-- ────────────────────────────────────────────────────────────
-- TRIGGER: Criar admin → criar assinatura trial e onboarding
-- ────────────────────────────────────────────────────────────
create or replace function on_admin_created()
returns trigger language plpgsql security definer as $$
begin
  insert into assinaturas (admin_id, plano, status)
  values (NEW.id, 'solo', 'trial');

  insert into onboarding (admin_id)
  values (NEW.id);

  return NEW;
end;
$$;

create trigger trg_admin_created
after insert on admins
for each row execute function on_admin_created();

-- ────────────────────────────────────────────────────────────
-- TRIGGER: Primeira remessa → marca onboarding
-- ────────────────────────────────────────────────────────────
create or replace function on_remessa_created()
returns trigger language plpgsql security definer as $$
declare
  v_admin_id uuid;
begin
  select admin_id into v_admin_id from metas where id = NEW.meta_id;

  update onboarding
  set registrou_remessa = true, updated_at = now()
  where admin_id = v_admin_id
    and registrou_remessa = false;

  return NEW;
end;
$$;

create trigger trg_remessa_created
after insert on remessas
for each row execute function on_remessa_created();

-- ────────────────────────────────────────────────────────────
-- TRIGGER: Primeira meta criada → marca onboarding
-- ────────────────────────────────────────────────────────────
create or replace function on_meta_created()
returns trigger language plpgsql security definer as $$
begin
  update onboarding
  set criou_meta = true, updated_at = now()
  where admin_id = NEW.admin_id
    and criou_meta = false;

  return NEW;
end;
$$;

create trigger trg_meta_created
after insert on metas
for each row execute function on_meta_created();

-- ────────────────────────────────────────────────────────────
-- TRIGGER: updated_at automático
-- ────────────────────────────────────────────────────────────
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  NEW.updated_at := now();
  return NEW;
end;
$$;

create trigger trg_updated_admins
before update on admins
for each row execute function set_updated_at();

create trigger trg_updated_metas
before update on metas
for each row execute function set_updated_at();

create trigger trg_updated_operadores
before update on operadores
for each row execute function set_updated_at();

create trigger trg_updated_assinaturas
before update on assinaturas
for each row execute function set_updated_at();

-- ────────────────────────────────────────────────────────────
-- VIEWS úteis
-- ────────────────────────────────────────────────────────────

-- Visão geral do faturamento por admin
create or replace view vw_faturamento as
select
  a.id                                                  as admin_id,
  a.nome                                                as admin_nome,
  count(m.id)                                          as total_metas,
  count(m.id) filter (where m.status = 'ativa')        as metas_ativas,
  count(m.id) filter (where m.status = 'fechada')      as metas_fechadas,
  coalesce(sum(m.deposito_total), 0)                   as deposito_total,
  coalesce(sum(m.saque_total), 0)                      as saque_total,
  coalesce(sum(m.lucro_bruto), 0)                      as lucro_bruto,
  coalesce(sum(m.prejuizo_acum), 0)                    as prejuizo_total,
  coalesce(sum(m.resultado_liquido), 0)                as resultado_liquido,
  coalesce(sum(m.lucro_final), 0)                      as lucro_final,
  coalesce(avg(m.taxa_acerto) filter (where m.status = 'fechada'), 0) as taxa_acerto_media
from admins a
left join metas m on m.admin_id = a.id and m.status != 'lixeira'
group by a.id, a.nome;

-- Custos por período
create or replace view vw_custos_resumo as
select
  admin_id,
  sum(valor) filter (where data = current_date)             as custo_hoje,
  sum(valor) filter (where date_trunc('month', data) = date_trunc('month', current_date)) as custo_mes,
  sum(valor)                                                 as custo_total
from custos
group by admin_id;

-- Previsão baseada em metas fechadas
create or replace view vw_previsao as
select
  admin_id,
  count(*)                          as metas_fechadas,
  avg(resultado_liquido)            as lucro_medio_meta,
  avg(resultado_liquido / nullif(contas_total, 0)) as lucro_medio_conta
from metas
where status = 'fechada'
group by admin_id;
