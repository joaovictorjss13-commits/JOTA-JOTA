-- =====================================================================
-- Migration 006: Atualiza enum remessa_status para valores da UI
-- Execute no Supabase → SQL Editor
-- =====================================================================

-- 1. Converte a coluna para TEXT temporariamente para poder trocar o enum
ALTER TABLE remessas ALTER COLUMN status TYPE text;

-- 2. Normaliza valores legados para os novos padrões
UPDATE remessas SET status = 'normal'    WHERE status IN ('normal',  'perdeu', 'noite');
UPDATE remessas SET status = 'bloqueado' WHERE status = 'bloqueio';
-- pendente e analise já seriam novos, mas garantimos consistência
UPDATE remessas SET status = 'pendente'  WHERE status = 'pendente';
UPDATE remessas SET status = 'analise'   WHERE status IN ('analise', 'análise', 'Análise');

-- 3. Remove enum antigo
DROP TYPE IF EXISTS remessa_status CASCADE;

-- 4. Cria novo enum com valores que correspondem à UI
CREATE TYPE remessa_status AS ENUM ('normal', 'pendente', 'bloqueado', 'analise');

-- 5. Restaura a coluna com o novo enum
ALTER TABLE remessas
  ALTER COLUMN status TYPE remessa_status
  USING status::remessa_status;

-- 6. Garante o default correto
ALTER TABLE remessas ALTER COLUMN status SET DEFAULT 'normal';

-- Verificação (opcional — rode para confirmar)
-- SELECT DISTINCT status FROM remessas;
