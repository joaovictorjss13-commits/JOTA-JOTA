-- ============================================================
-- Migration 022 — Aplica o plano 'trial' ao fluxo de admins
-- Depende de 021 (enum 'trial' já commitado)
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Backfill: usuarios existentes em trial ativo → 'trial'
-- ────────────────────────────────────────────────────────────
UPDATE admins a
SET plano = 'trial', updated_at = now()
FROM assinaturas s
WHERE s.admin_id = a.id
  AND s.status = 'trial'
  AND s.trial_ends_at > now()
  AND a.plano = 'pro';

-- ────────────────────────────────────────────────────────────
-- 2. Novos admins entram com plano = 'trial'
-- ────────────────────────────────────────────────────────────
ALTER TABLE admins ALTER COLUMN plano SET DEFAULT 'trial';

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.admins (id, nome, email, plano)
  VALUES (
    NEW.id,
    COALESCE(
      NEW.raw_user_meta_data->>'nome',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    NEW.email,
    'trial'
  )
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

-- ────────────────────────────────────────────────────────────
-- 3. expire_trials() — batch (pg_cron): 'trial' → 'solo'
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION expire_trials()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE admins SET plano = 'solo', updated_at = now()
  WHERE plano = 'trial'
    AND id IN (SELECT admin_id FROM assinaturas WHERE status = 'trial' AND trial_ends_at <= now());

  UPDATE assinaturas SET status = 'cancelada', updated_at = now()
  WHERE status = 'trial' AND trial_ends_at <= now();
END;
$$;

-- ────────────────────────────────────────────────────────────
-- 4. expire_my_trial() — chamado pelo cliente: 'trial' → 'solo'
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION expire_my_trial()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE assinaturas
  SET status = 'cancelada', updated_at = now()
  WHERE admin_id = auth.uid()
    AND status = 'trial'
    AND trial_ends_at <= now();

  UPDATE admins
  SET plano = 'solo', updated_at = now()
  WHERE id = auth.uid()
    AND plano = 'trial'
    AND id IN (
      SELECT admin_id FROM assinaturas
      WHERE admin_id = auth.uid() AND status = 'cancelada'
    );
END;
$$;

GRANT EXECUTE ON FUNCTION expire_trials()   TO authenticated;
GRANT EXECUTE ON FUNCTION expire_my_trial() TO authenticated;
