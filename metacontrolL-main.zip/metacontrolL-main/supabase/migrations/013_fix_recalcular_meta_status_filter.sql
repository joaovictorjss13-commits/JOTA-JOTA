-- ============================================================
-- Migration 013 — Corrige recalcular_meta para ignorar
-- remessas com status != 'normal' (pendente/bloqueado/analise)
-- e recalcula todos os dados históricos existentes.
-- ============================================================

-- 1. Corrige a função trigger
CREATE OR REPLACE FUNCTION recalcular_meta()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_dep       numeric(12,2);
  v_saque     numeric(12,2);
  v_prejuizo  numeric(12,2);
  v_total     int;
  v_positivas int;
  v_contas    int;
  v_meta_id   uuid;
BEGIN
  v_meta_id := COALESCE(NEW.meta_id, OLD.meta_id);

  SELECT
    COALESCE(SUM(deposito), 0),
    COALESCE(SUM(saque), 0),
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0),
    COUNT(*),
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END),
    COALESCE(SUM(contas), 0)
  INTO v_dep, v_saque, v_prejuizo, v_total, v_positivas, v_contas
  FROM remessas
  WHERE meta_id = v_meta_id AND status = 'normal';

  UPDATE metas SET
    deposito_total    = v_dep,
    saque_total       = v_saque,
    prejuizo_acum     = v_prejuizo,
    resultado_liquido = v_saque - v_dep,
    taxa_acerto       = CASE WHEN v_total = 0 THEN 0 ELSE ROUND((v_positivas::numeric / v_total) * 100, 2) END,
    score             = CASE WHEN v_total = 0 THEN 0 ELSE LEAST(100, ROUND((v_positivas::numeric / v_total) * 100)) END,
    contas_atingidas  = v_contas,
    updated_at        = now()
  WHERE id = v_meta_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- 2. Recalcula todos os agregados nas metas com base somente em remessas 'normal'
WITH recalc AS (
  SELECT
    meta_id,
    COALESCE(SUM(deposito), 0)                                                                          AS dep,
    COALESCE(SUM(saque), 0)                                                                             AS saq,
    COALESCE(SUM(CASE WHEN (saque - deposito) < 0 THEN ABS(saque - deposito) ELSE 0 END), 0)           AS prej,
    COUNT(*)                                                                                            AS total,
    COUNT(CASE WHEN (saque - deposito) > 0 THEN 1 END)                                                 AS pos,
    COALESCE(SUM(contas), 0)                                                                            AS cont
  FROM remessas
  WHERE status = 'normal'
  GROUP BY meta_id
)
UPDATE metas m SET
  deposito_total    = r.dep,
  saque_total       = r.saq,
  prejuizo_acum     = r.prej,
  resultado_liquido = r.saq - r.dep,
  taxa_acerto       = CASE WHEN r.total = 0 THEN 0 ELSE ROUND((r.pos::numeric / r.total) * 100, 2) END,
  score             = CASE WHEN r.total = 0 THEN 0 ELSE LEAST(100, ROUND((r.pos::numeric / r.total) * 100)) END,
  contas_atingidas  = r.cont,
  updated_at        = now()
FROM recalc r
WHERE m.id = r.meta_id;

-- 3. Zera metas que não têm nenhuma remessa 'normal'
UPDATE metas SET
  deposito_total    = 0,
  saque_total       = 0,
  prejuizo_acum     = 0,
  resultado_liquido = 0,
  taxa_acerto       = 0,
  score             = 0,
  contas_atingidas  = 0,
  updated_at        = now()
WHERE NOT EXISTS (
  SELECT 1 FROM remessas WHERE meta_id = metas.id AND status = 'normal'
);

