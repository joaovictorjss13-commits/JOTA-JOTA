// src/types/database.ts
// Tipos TypeScript do banco — gerado automaticamente pelo Supabase CLI:
// npx supabase gen types typescript --project-id SEU_PROJECT_ID > src/types/database.ts
// Abaixo os tipos manuais essenciais para desenvolvimento inicial

export type PlanType        = 'solo' | 'pro'
export type AssinaturaStatus = 'trial' | 'ativa' | 'cancelada' | 'inadimplente'
export type MetaStatus      = 'ativa' | 'finalizada' | 'fechada' | 'lixeira'
export type MetaModelo      = 'salario_bau' | 'apenas_bau'
export type RemessaStatus   = 'normal' | 'perdeu' | 'bloqueio' | 'noite'
export type RemessaTipo     = 'remessa' | 'sync' | 'ajuste'
export type CustoTipo       = 'proxy' | 'sms' | 'assinaturas' | 'bot' | 'vps' | 'outros'

export interface Admin {
  id:            string
  nome:          string
  email:         string
  plano:         PlanType
  meta_global:   number
  notificacoes:  boolean
  created_at:    string
  updated_at:    string
}

export interface Assinatura {
  id:                 string
  admin_id:           string
  plano:              PlanType
  qtd_operadores:     number
  valor_base:         number
  valor_por_operador: number
  valor_mensal:       number
  status:             AssinaturaStatus
  trial_ends_at:      string | null
  vencimento:         string | null
  gateway_sub_id:     string | null
}

export interface Operador {
  id:             string
  user_id:        string | null
  admin_id:       string
  nome:           string
  email:          string | null
  status:         'ativo' | 'inativo' | 'pendente'
  convite_token:  string
  convite_usado:  boolean
  created_at:     string
}

export interface Rede {
  id:       string
  admin_id: string
  nome:     string
  sigla:    string
}

export interface Meta {
  id:                string
  admin_id:          string
  operador_id:       string | null
  rede_id:           string | null
  titulo:            string
  plataforma:        string
  contas_total:      number
  contas_atingidas:  number
  modelo:            MetaModelo
  status:            MetaStatus
  deposito_total:    number
  saque_total:       number
  lucro_bruto:       number
  prejuizo_acum:     number
  resultado_liquido: number
  taxa_acerto:       number
  score:             number
  salario:           number
  custo_fixo:        number
  taxa_agente:       number
  lucro_final:       number
  finalizada_at:     string | null
  fechada_at:        string | null
  created_at:        string
  updated_at:        string
  // joins opcionais
  operador?:         Operador
  rede?:             Rede
  remessas?:         Remessa[]
}

export interface Remessa {
  id:          string
  meta_id:     string
  operador_id: string | null
  slot_id:     string | null
  titulo:      string | null
  tipo:        RemessaTipo
  saldo_ini:   number
  contas:      number
  deposito:    number
  saque:       number
  resultado:   number
  status:      RemessaStatus
  notas:       string | null
  created_at:  string
  // joins opcionais
  slot?:       Slot
}

export interface Custo {
  id:         string
  admin_id:   string
  tipo:       CustoTipo
  valor:      number
  data:       string
  nota:       string | null
  created_at: string
}

export interface Slot {
  id:          string
  nome:        string
  provider:    string
  rtp:         number | null
  categoria:   string | null
  imagem_url:  string | null
  destaque:    boolean
  apenas_pro:  boolean
}

export interface Dashboard {
  lucro_acumulado:    number
  deposito_total:     number
  saque_total:        number
  total_metas:        number
  metas_fechadas:     number
  total_depositantes: number
  status:             'positivo' | 'negativo' | 'neutro'
  remessas_recentes:  RemessaRecente[]
  previsao:           Previsao
}

export interface RemessaRecente {
  operador_nome: string
  resultado:     number
  created_at:    string
}

export interface Previsao {
  lucro_medio_meta:  number
  lucro_medio_conta: number
  metas_fechadas:    number
}

// Tipos para as requests das rotas de API
export interface CriarMetaInput {
  titulo:       string
  plataforma:   string
  rede_id?:     string
  contas_total: number
  modelo:       MetaModelo
  operador_id?: string
}

export interface RegistrarRemessaInput {
  meta_id:     string
  titulo?:     string
  tipo?:       RemessaTipo
  saldo_ini?:  number
  contas:      number
  deposito:    number
  saque:       number
  status?:     RemessaStatus
  notas?:      string
  slot_id?:    string
}

export interface FecharMetaInput {
  salario?:    number
  custo_fixo?: number
  taxa_agente?: number
}

export interface AdicionarCustoInput {
  tipo:   CustoTipo
  valor:  number
  data?:  string
  nota?:  string
}

// Tipagem genérica para respostas da API
export type ApiResponse<T> =
  | { data: T; error: null }
  | { data: null; error: string }

// Placeholder para o tipo gerado pelo Supabase CLI
export interface Database {
  public: {
    Tables: Record<string, any>
    Views:  Record<string, any>
    Functions: Record<string, any>
    Enums: Record<string, any>
  }
}
