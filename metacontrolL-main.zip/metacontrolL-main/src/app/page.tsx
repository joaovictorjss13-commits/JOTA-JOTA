'use client'

import { useState, useEffect, useRef, ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import {
  ArrowRight, ChevronDown, TrendingUp, DollarSign,
  X, CheckCircle2, BarChart3, Target, ShieldCheck,
  Clock, Smartphone, Zap,
} from 'lucide-react'
import { getCurrentUser } from '@/lib/supabase-service'

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); observer.disconnect() } },
      { threshold }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [threshold])
  return { ref, inView }
}

function Reveal({
  children, delay = 0, className = '',
}: { children: ReactNode; delay?: number; className?: string }) {
  const { ref, inView } = useInView()
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? 'none' : 'translateY(28px)',
        transition: `opacity 0.65s ease ${delay}ms, transform 0.65s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  )
}

function AnimatedCounter({ target, suffix = '' }: { target: string; suffix?: string }) {
  const [count, setCount] = useState(0)
  const { ref, inView } = useInView(0.3)
  const numericTarget = parseInt(target.replace(/\D/g, ''))
  useEffect(() => {
    if (!inView) return
    const duration = 2000
    const steps = 60
    const increment = numericTarget / steps
    let current = 0
    const timer = setInterval(() => {
      current += increment
      if (current >= numericTarget) { setCount(numericTarget); clearInterval(timer) }
      else setCount(Math.floor(current))
    }, duration / steps)
    return () => clearInterval(timer)
  }, [inView, numericTarget])
  return (
    <div ref={ref} className="mono-value font-bold text-4xl md:text-5xl">
      {count.toLocaleString('pt-BR')}{suffix}
    </div>
  )
}

function PulsingDot({ color = 'bg-cta' }: { color?: string }) {
  return (
    <span className="relative flex h-2.5 w-2.5 shrink-0">
      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${color} opacity-75`} />
      <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${color}`} />
    </span>
  )
}

export default function LandingPage() {
  const router = useRouter()

  useEffect(() => {
    getCurrentUser().then(user => {
      if (user) router.replace('/admin')
    }).catch(() => null)
  }, [router])

  return (
    <div className="min-h-screen bg-bg-primary overflow-hidden">

      {/* ══ AMBIENT BACKGROUND ══ */}
      <div className="fixed inset-0 pointer-events-none select-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage: 'radial-gradient(rgba(255,255,255,0.8) 1px, transparent 1px)',
            backgroundSize: '28px 28px',
          }}
        />
        <div
          className="absolute top-[8%] left-[10%] w-[700px] h-[700px] rounded-full bg-cta/10 blur-[140px]"
          style={{ animation: 'orb-drift-1 30s ease-in-out infinite' }}
        />
        <div
          className="absolute top-[45%] right-[5%] w-[500px] h-[500px] rounded-full bg-accent-blue/5 blur-[120px]"
          style={{ animation: 'orb-drift-2 38s ease-in-out infinite' }}
        />
        <div
          className="absolute bottom-[10%] left-[20%] w-[450px] h-[450px] rounded-full bg-cta/8 blur-[110px]"
          style={{ animation: 'orb-drift-3 24s ease-in-out infinite' }}
        />
        <div
          className="absolute top-[65%] right-[25%] w-[380px] h-[380px] rounded-full bg-accent-green/4 blur-[100px]"
          style={{ animation: 'orb-drift-4 32s ease-in-out infinite' }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_0%,transparent_50%,rgba(7,7,15,0.6)_100%)]" />
      </div>

      <div className="relative z-10">

        {/* ══ NAVBAR ══ */}
        <nav className="sticky top-0 z-50 glass border-b border-border">
          <div className="flex items-center justify-between px-6 py-4 max-w-6xl mx-auto">
            <div className="flex items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo.png" alt="MetaControll" className="w-8 h-8 rounded-lg object-contain" />
              <span className="font-black text-base tracking-tight">
                <span className="text-cta">Meta</span>
                <span className="text-text-primary">Controll</span>
              </span>
            </div>
            <Link href="/login">
              <button className="text-sm px-4 py-2 rounded-lg border border-border hover:border-cta/50 hover:text-cta text-text-secondary transition-all duration-200">
                Entrar
              </button>
            </Link>
          </div>
        </nav>

        {/* ══ HERO ══ */}
        <section className="flex flex-col items-center justify-center min-h-[95vh] px-4 text-center pt-10">

          {/* Badge */}
          <div
            className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-cta/30 bg-cta/10 mb-8 relative overflow-hidden"
            style={{ animation: 'fade-in 0.5s ease-out both' }}
          >
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: 'linear-gradient(90deg,transparent 0%,rgba(124,58,237,0.18) 50%,transparent 100%)',
                backgroundSize: '200% 100%',
                animation: 'shimmer 2.5s linear infinite',
              }}
            />
            <PulsingDot />
            <span className="relative text-xs font-semibold text-cta tracking-widest uppercase">
              3 dias grátis • Sem compromisso
            </span>
          </div>

          {/* Headline */}
          <div style={{ animation: 'slide-up 0.65s ease-out 0.1s both' }}>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black leading-[1.05] max-w-5xl tracking-tight">
              Pare de operar no escuro.
            </h1>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black leading-[1.05] max-w-5xl tracking-tight">
              <span className="text-gradient">Opere com consistência.</span>
            </h1>
          </div>

          <p
            className="mt-8 text-base md:text-lg text-text-secondary max-w-md leading-relaxed"
            style={{ animation: 'slide-up 0.65s ease-out 0.3s both' }}
          >
            Chega de calcular tudo manualmente.<br />
            Aqui você opera e calcula tudo automaticamente.
          </p>

          {/* CTAs */}
          <div
            className="flex flex-col sm:flex-row items-center gap-3 mt-10"
            style={{ animation: 'slide-up 0.65s ease-out 0.4s both' }}
          >
            <Link href="/register">
              <Button size="lg" className="min-w-[230px] text-base font-bold animate-glow-pulse">
                Começar grátis por 3 dias
                <ArrowRight size={16} />
              </Button>
            </Link>
            <Link href="/login">
              <Button variant="secondary" size="lg" className="min-w-[180px]">
                Já tenho conta
              </Button>
            </Link>
          </div>

          <p
            className="mt-4 text-xs text-text-muted"
            style={{ animation: 'fade-in 0.65s ease-out 0.5s both' }}
          >
            Sem cartão de crédito • Cancele quando quiser
          </p>

          {/* Feature pills */}
          <div
            className="flex flex-wrap justify-center gap-3 mt-10"
            style={{ animation: 'fade-in 0.65s ease-out 0.6s both' }}
          >
            {[
              { icon: Zap, label: '3 dias grátis' },
              { icon: Smartphone, label: 'iPhone e Android' },
              { icon: TrendingUp, label: 'Lucro em tempo real' },
            ].map(({ icon: Icon, label }, i) => (
              <div
                key={label}
                className="flex items-center gap-2 px-4 py-2 rounded-full glass border border-border text-xs text-text-secondary animate-float"
                style={{ animationDelay: `${i * -1.2}s` }}
              >
                <Icon size={12} className="text-cta" />
                {label}
              </div>
            ))}
          </div>

          {/* Scroll hint */}
          <div
            className="mt-16"
            style={{ animation: 'fade-in 1s ease-out 1s both' }}
          >
            <ChevronDown size={22} className="mx-auto text-text-muted animate-pulse-glow" />
          </div>
        </section>

        {/* ══ DASHBOARD PREVIEW ══ */}
        <section className="py-28 px-4">
          <div className="max-w-3xl mx-auto">
            <Reveal className="text-center mb-14">
              <p className="text-xs uppercase tracking-[0.25em] text-cta mb-3">Veja como funciona</p>
              <h2 className="text-2xl md:text-4xl font-black leading-tight">
                Veja sua operação<br className="sm:hidden" /> em tempo real.
              </h2>
            </Reveal>

            <Reveal delay={150}>
              <div className="conic-border animate-float">
                <div className="conic-border-inner p-6 md:p-8 shadow-2xl shadow-black/60">

                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src="/logo.png" alt="MetaControll" className="w-7 h-7 rounded-lg object-contain" />
                      <div>
                        <span className="text-sm font-bold block leading-none">MetaControll</span>
                        <span className="text-[10px] text-text-muted">Central de resultados</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-accent-green/10 border border-accent-green/20">
                      <PulsingDot color="bg-accent-green" />
                      <span className="text-[10px] text-accent-green font-medium">Ao vivo</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="md:col-span-2 bg-bg-surface rounded-xl p-5 border border-accent-green/20 card-glow-green relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-36 h-36 bg-accent-green/5 rounded-full blur-2xl pointer-events-none" />
                      <p className="text-xs text-text-muted mb-1 uppercase tracking-wide">Lucro acumulado</p>
                      <p className="text-3xl md:text-4xl font-black text-accent-green mono-value">+R$ 6.622,47</p>
                      <p className="text-xs text-accent-green/70 mt-2 flex items-center gap-1">
                        <TrendingUp size={10} /> Atualizado automaticamente
                      </p>
                    </div>
                    <div className="space-y-3">
                      <div className="bg-bg-surface rounded-xl p-4 border border-border flex items-center justify-between">
                        <div>
                          <p className="text-[10px] text-text-muted uppercase">Depositado</p>
                          <p className="text-base font-bold mono-value">R$ 57.365</p>
                        </div>
                        <div className="w-8 h-8 rounded-lg bg-accent-blue/10 flex items-center justify-center">
                          <DollarSign size={14} className="text-accent-blue" />
                        </div>
                      </div>
                      <div className="bg-bg-surface rounded-xl p-4 border border-border flex items-center justify-between">
                        <div>
                          <p className="text-[10px] text-text-muted uppercase">Sacado</p>
                          <p className="text-base font-bold mono-value">R$ 51.138</p>
                        </div>
                        <div className="w-8 h-8 rounded-lg bg-accent-green/10 flex items-center justify-center">
                          <TrendingUp size={14} className="text-accent-green" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-bg-surface rounded-xl p-4 border border-border">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-xs font-semibold text-text-secondary uppercase tracking-wide">Últimos lançamentos</p>
                      <span className="text-[10px] text-text-muted">Tempo real</span>
                    </div>
                    {[
                      { label: 'Remessa #14', dep: 'R$ 1.200', saq: 'R$ 1.450', lucro: '+R$ 250,00', color: 'text-accent-green' },
                      { label: 'Remessa #13', dep: 'R$ 800',   saq: 'R$ 950',   lucro: '+R$ 150,00', color: 'text-accent-green' },
                      { label: 'Remessa #12', dep: 'R$ 500',   saq: 'R$ 452',   lucro: '-R$ 48,00',  color: 'text-accent-red' },
                    ].map(({ label, dep, saq, lucro, color }, i) => (
                      <div key={i} className="flex items-center justify-between py-2.5 border-b border-border/50 last:border-0 text-sm">
                        <span className="text-text-secondary">{label}</span>
                        <div className="flex items-center gap-4 text-xs">
                          <span className="text-text-muted hidden md:block">↓ {dep}</span>
                          <span className="text-text-muted hidden md:block">↑ {saq}</span>
                          <span className={`font-bold mono-value ${color}`}>{lucro}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                </div>
              </div>
            </Reveal>
          </div>
        </section>

        {/* ══ SOCIAL PROOF ══ */}
        <section className="py-16 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-bg-surface/25 border-y border-border/40" />
          <div className="relative max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
            {[
              { value: '1200',   suffix: '+', label: 'Usuários ativos',             color: 'text-cta' },
              { value: '1000000', suffix: '+', label: 'Em operações monitoradas',   color: 'text-accent-green' },
              { value: '3019',   suffix: '+', label: 'Operações analisadas',        color: 'text-accent-blue' },
            ].map(({ value, suffix, label, color }, i) => (
              <Reveal key={label} delay={i * 100} className="flex flex-col items-center gap-2">
                <div className={color}>
                  <AnimatedCounter target={value} suffix={suffix} />
                </div>
                <p className="text-sm text-text-muted">{label}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* ══ HOW IT WORKS ══ */}
        <section className="py-28 px-4">
          <div className="max-w-4xl mx-auto">

            <Reveal className="text-center mb-16">
              <p className="text-xs uppercase tracking-[0.25em] text-cta mb-3">Como funciona</p>
              <h2 className="text-2xl md:text-4xl font-black">Passo a passo.</h2>
            </Reveal>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
              {/* Connector */}
              <div className="hidden md:block absolute top-9 left-[calc(33.33%+12px)] right-[calc(33.33%+12px)] h-px bg-gradient-to-r from-cta/15 via-cta/50 to-cta/15" />

              {[
                {
                  step: '01', icon: Target,
                  title: 'Crie uma operação.',
                  desc: 'Crie sua operação — seja métodos, delay, CPA, entre outros. A plataforma organiza tudo automaticamente.',
                },
                {
                  step: '02', icon: DollarSign,
                  title: 'Registre o depósito, saque e custos.',
                  desc: 'Informe o valor depositado, valor sacado e os custos que teve.',
                },
                {
                  step: '03', icon: TrendingUp,
                  title: 'Lucro aparece automático.',
                  desc: 'O sistema calcula o resultado na hora.',
                },
              ].map(({ step, icon: Icon, title, desc }, i) => (
                <Reveal key={step} delay={i * 120}>
                  <div className="bg-bg-surface rounded-2xl border border-border p-6 hover:border-cta/40 hover:-translate-y-2 transition-all duration-300 group card-breathe relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-cta/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    {/* Step circle */}
                    <div className="w-[2.25rem] h-[2.25rem] rounded-full border-2 border-cta/30 bg-cta/10 flex items-center justify-center mb-5 group-hover:border-cta/70 group-hover:bg-cta/20 transition-all duration-300">
                      <span className="text-xs font-black text-cta mono-value">{step}</span>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-bg-surface-light border border-border flex items-center justify-center mb-4 group-hover:border-cta/30 group-hover:bg-cta/10 group-hover:shadow-[0_0_18px_rgba(124,58,237,0.25)] transition-all duration-300">
                      <Icon size={18} className="text-cta" />
                    </div>
                    <h3 className="font-bold text-base mb-2 leading-snug">{title}</h3>
                    <p className="text-sm text-text-secondary leading-relaxed">{desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* ══ BENEFITS ══ */}
        <section className="py-20 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-bg-surface/20 border-y border-border/40" />
          <div className="relative max-w-4xl mx-auto">

            <Reveal className="text-center mb-14">
              <h2 className="text-2xl md:text-4xl font-black">
                Tudo o que você precisa está aqui.
              </h2>
            </Reveal>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { icon: BarChart3,  title: 'Faturamento por período',   desc: 'Veja a evolução dos seus ganhos mês a mês, sem fazer cálculo manual.' },
                { icon: Smartphone, title: 'Aplicativo celular',        desc: 'Acesse sua operação de qualquer lugar. Disponível para iPhone e Android.' },
                { icon: Clock,      title: 'Histórico completo',        desc: 'Todo lançamento fica salvo. Consulte qualquer remessa passada a qualquer hora.' },
                { icon: ShieldCheck, title: 'Dados seguros',            desc: 'Infraestrutura com criptografia de ponta. Seus dados ficam só com você.' },
              ].map(({ icon: Icon, title, desc }, i) => (
                <Reveal key={title} delay={i * 80}>
                  <div className="flex items-start gap-4 p-5 bg-bg-surface rounded-2xl border border-border hover:border-cta/35 hover:-translate-y-1 transition-all duration-300 group card-breathe card-sweep">
                    <div className="w-10 h-10 rounded-xl bg-cta/10 border border-cta/20 flex items-center justify-center shrink-0 group-hover:bg-cta/20 group-hover:border-cta/50 group-hover:shadow-[0_0_20px_rgba(124,58,237,0.3)] transition-all duration-300">
                      <Icon size={18} className="text-cta" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm mb-1">{title}</h3>
                      <p className="text-xs text-text-secondary leading-relaxed">{desc}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* ══ BEFORE / AFTER ══ */}
        <section className="py-28 px-4">
          <div className="max-w-3xl mx-auto">

            <Reveal className="text-center mb-14">
              <h2 className="text-2xl md:text-4xl font-black leading-tight">
                Se você ainda usa planilha,<br />
                <span className="text-gradient">já está perdendo:</span>
              </h2>
            </Reveal>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

              <Reveal delay={0}>
                <div className="rounded-2xl border border-accent-red/20 bg-accent-red/5 p-6 h-full">
                  <div className="flex items-center gap-2 mb-5">
                    <div className="w-6 h-6 rounded-full bg-accent-red/20 flex items-center justify-center">
                      <X size={12} className="text-accent-red" />
                    </div>
                    <span className="text-xs font-bold text-accent-red uppercase tracking-widest">Sem o MetaControll</span>
                  </div>
                  <div className="space-y-2">
                    {[
                      'Horas calculando manualmente',
                      'Erros que só aparecem no fim do mês',
                      'Sem visão do resultado em tempo real',
                      'Operação no feeling, não nos dados',
                      'Histórico impossível de encontrar',
                    ].map((pain) => (
                      <div key={pain} className="flex items-center gap-3 py-2.5 px-3 rounded-xl bg-bg-surface border border-accent-red/10">
                        <X size={12} className="text-accent-red shrink-0" />
                        <span className="text-sm text-text-secondary">{pain}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>

              <Reveal delay={130}>
                <div className="rounded-2xl border border-cta/25 glass-violet p-6 h-full">
                  <div className="flex items-center gap-2 mb-5">
                    <div className="w-6 h-6 rounded-full bg-cta/20 flex items-center justify-center">
                      <CheckCircle2 size={12} className="text-cta" />
                    </div>
                    <span className="text-xs font-bold text-cta uppercase tracking-widest">Com o MetaControll</span>
                  </div>
                  <div className="space-y-2">
                    {[
                      'Lucro calculado automaticamente',
                      'Resultado visível na hora do lançamento',
                      'Histórico organizado por operação',
                      'Faturamento mensal sem esforço',
                      'Tudo em tempo real no celular',
                    ].map((win) => (
                      <div key={win} className="flex items-center gap-3 py-2.5 px-3 rounded-xl bg-bg-surface border border-cta/15">
                        <CheckCircle2 size={12} className="text-cta shrink-0" />
                        <span className="text-sm font-medium">{win}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>

            </div>
          </div>
        </section>

        {/* ══ FINAL CTA ══ */}
        <section className="py-32 px-4 text-center relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-cta/8 rounded-full blur-[130px]" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[450px] h-[300px] bg-cta/12 rounded-full blur-[90px]" />
          </div>

          <div className="relative max-w-xl mx-auto">
            <Reveal>
              <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-cta/30 bg-cta/10 mb-8">
                <PulsingDot />
                <span className="text-xs font-semibold text-cta">3 dias grátis • Sem compromisso</span>
              </div>
            </Reveal>

            <Reveal delay={80}>
              <h2 className="text-3xl md:text-5xl font-black mb-5 leading-tight">
                Crie sua conta e veja sua<br />
                <span className="text-gradient">operação em tempo real.</span>
              </h2>
            </Reveal>

            <Reveal delay={160}>
              <p className="text-text-secondary mb-10 text-base">
                Crie sua conta agora e veja o lucro aparecer automático — ainda hoje.
              </p>
            </Reveal>

            <Reveal delay={240}>
              <Link href="/register">
                <Button size="lg" className="min-w-[240px] text-base font-bold shadow-2xl shadow-cta/30 animate-glow-pulse">
                  Criar conta grátis
                  <ArrowRight size={18} />
                </Button>
              </Link>
              <p className="text-xs text-text-muted mt-5">
                Sem compromisso. Cancele quando quiser.
              </p>
            </Reveal>
          </div>

          {/* Footer */}
          <Reveal delay={300} className="mt-24 pt-8 border-t border-border/50 flex flex-col items-center gap-2">
            <div className="flex items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo.png" alt="MetaControll" className="w-7 h-7 rounded-lg object-contain" />
              <span className="text-sm font-black">
                <span className="text-cta">Meta</span>
                <span className="text-text-primary">Controll</span>
              </span>
            </div>
            <p className="text-xs text-text-muted">Plataforma inteligente de resultados.</p>
          </Reveal>
        </section>

      </div>
    </div>
  )
}
