'use client'

import { useState, useEffect, useCallback, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Tabs } from '@/components/ui/Tabs'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Badge, StatusBadge } from '@/components/ui/Badge'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { PillTabs } from '@/components/ui/Tabs'
import { NewGoalModal } from '@/components/modals/NewGoalModal'
import { ConfirmModal } from '@/components/modals/ConfirmModal'
import { useToast } from '@/components/ui/Toast'
import { cn, formatBRL } from '@/lib/utils'
import { getMetas, getDashboardData, updateMetaStatus, permanentDeleteMeta } from '@/lib/supabase-service'
import { GoalDetailModal } from '@/components/modals/GoalDetailModal'
import { supabase } from '@/lib/supabase'
import {
  RefreshCw, Plus, Clock, ChevronRight,
  Trash2, RotateCcw, AlertTriangle, Loader2, TrendingUp, Activity,
  TrendingDown, Minus, Award, Brain, ArrowUp, ArrowDown, Target,
  Zap, BarChart2, ShieldCheck
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts'
import { useUserProfile } from '@/hooks/useUserProfile'
import { ProGate } from '@/components/ui/ProGate'

// ── Sparkline SVG crescente — fundo decorativo do card de lucro ──
function SparklineBackground({ positive }: { positive: boolean }) {
  const color = positive ? '#10b981' : '#ef4444'
  const pts = positive
    ? [90,72,80,60,65,45,50,30,35,15,20,5]
    : [5,20,15,35,30,50,45,65,60,75,70,85]
  const w = 400; const h = 80
  const xs = pts.map((_, i) => (i / (pts.length - 1)) * w)
  const ys = pts.map(p => (p / 100) * h)
  const line = xs.map((x, i) => `${i === 0 ? 'M' : 'L'}${x},${ys[i]}`).join(' ')
  const area = `${line} L${w},${h} L0,${h} Z`
  const pathLen = 900 // approximate stroke length for dashoffset animation
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      style={{ position: 'absolute', bottom: 0, left: 0, right: 0, width: '100%', height: '60px', opacity: 0.22, pointerEvents: 'none' }}
    >
      <defs>
        <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.45" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <linearGradient id="sparkLineGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={color} stopOpacity="0" />
          <stop offset="40%" stopColor={color} stopOpacity="1" />
          <stop offset="100%" stopColor={color} stopOpacity="1" />
        </linearGradient>
      </defs>
      {/* Area fill — breathes */}
      <path d={area} fill="url(#sparkGrad)" style={{ animation: 'spark-breathe 4s ease-in-out infinite' }} />
      {/* Line — draw-in on mount, then glide */}
      <path
        d={line}
        fill="none"
        stroke={`url(#sparkLineGrad)`}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={pathLen}
        strokeDashoffset={pathLen}
        style={{ animation: `spark-draw 1.6s cubic-bezier(0.4,0,0.2,1) forwards, spark-glide 6s ease-in-out 1.6s infinite` }}
      />
      {/* Glowing dot at end of line */}
      <circle
        cx={xs[xs.length - 1]}
        cy={ys[ys.length - 1]}
        r="3"
        fill={color}
        style={{ opacity: 0, animation: 'spark-dot 1s ease-out 1.5s forwards, spark-dot-pulse 2s ease-in-out 2.5s infinite' }}
      />
    </svg>
  )
}

// ═══════════════════ INITIAL (ZERO) DATA ═══════════════════
const zeroDashboard = {
  lucro_acumulado: 0,
  deposito_total: 0,
  deposito_normal: 0,
  bloqueado_total: 0,
  saque_total: 0,
  lucro_bruto: 0,
  taxa_acerto: 0,
  total_metas: 0,
  metas_fechadas: 0,
  metas_ativas: 0,
  casas_ativas: 0,
  breakdown: { normal: 0, bloqueado: 0, pendente: 0 },
  analise: null as any,
  remessas_recentes: [] as any[],
  metas: [] as any[],
  metas_filtradas: [] as any[],
}

// ═══════════════════ MAIN PAGE ═══════════════════
export default function AdminPage() {
  return (
    <Suspense>
      <AdminPageContent />
    </Suspense>
  )
}

function AdminPageContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { addToast } = useToast()
  const { profile } = useUserProfile()
  const isFree = profile !== null && !profile.isPro
  const [activeTab, setActiveTab] = useState(() => searchParams.get('tab') || 'visao_geral')

  useEffect(() => {
    const tab = searchParams.get('tab') || 'visao_geral'
    setActiveTab(tab)
  }, [searchParams])

  function handleTabChange(tab: string) {
    setActiveTab(tab)
    router.replace(`/admin?tab=${tab}`, { scroll: false })
  }
  const [showNewGoal, setShowNewGoal] = useState(false)
  const [filtroTempo, setFiltroTempo] = useState('Tudo')
  const [dashboardData, setDashboardData] = useState(zeroDashboard)
  const [loading, setLoading] = useState(true)
  const [authChecked, setAuthChecked] = useState(false)

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) {
        router.replace('/login')
      } else {
        setAuthChecked(true)
      }
    })
  }, [router])

  const loadDashboard = useCallback(async (filtro: string = filtroTempo) => {
    setLoading(true)
    try {
      const data = await getDashboardData(filtro)
      const metas: any[] = data.metas || []
      const metas_ativas = metas.filter((m: any) => m.status === 'ativa').length

      setDashboardData({
        lucro_acumulado:  data.lucro_acumulado,
        deposito_total:   data.deposito_total,
        deposito_normal:  data.deposito_normal,
        bloqueado_total:  data.bloqueado_total,
        saque_total:      data.saque_total,
        lucro_bruto:      data.lucro_bruto,
        taxa_acerto:      data.taxa_acerto,
        total_metas:      data.total_metas,
        metas_fechadas:   data.metas_fechadas,
        metas_ativas,
        casas_ativas:     data.casas_ativas,
        breakdown:        data.breakdown,
        analise:          data.analise,
        remessas_recentes: data.remessas_recentes,
        metas,
        metas_filtradas:  data.metas_filtradas || metas,
      })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao carregar', message: err.message })
    } finally {
      setLoading(false)
    }
  }, [filtroTempo])

  // Initial load
  useEffect(() => { loadDashboard(filtroTempo) }, [])

  // Re-fetch when filter changes
  useEffect(() => { loadDashboard(filtroTempo) }, [filtroTempo])

  const tabs = [
    { key: 'visao_geral', label: 'Visão geral' },
    { key: 'minha_operacao', label: 'Minha operação' },
    { key: 'metas_fechamento', label: 'Operações' },
    { key: 'lixeira', label: 'Lixeira' },
  ]

  const handleSelectMeta = (meta: any) => {
    router.push(`/admin/meta/${meta.id}?titulo=${encodeURIComponent(meta.titulo)}&plataforma=${encodeURIComponent(meta.plataforma)}&rede=${meta.rede_sigla}&contas=${meta.contas_total}`)
  }

  if (!authChecked) return null

  return (
    <DashboardLayout>
      {/* Header sempre ao topo */}
      <div className="flex items-start justify-between mb-4 mt-8 md:mt-0">
        <div>
          <h1 className="text-2xl md:text-3xl font-black">Central de operações</h1>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse-glow shrink-0" />
            <span className="text-sm text-text-muted">Dados em tempo real</span>
          </div>
        </div>
        <Button variant="secondary" size="sm" onClick={() => loadDashboard(filtroTempo)} disabled={loading}>
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          Atualizar
        </Button>
      </div>

      {/* Tabs */}
      <div className="mb-4">
        <Tabs tabs={tabs} active={activeTab} onChange={handleTabChange} />
      </div>

      {/* Tab content — key forces re-mount → re-triggers animation on tab switch */}
      <div
        key={activeTab}
        style={{ animation: 'tab-enter 0.22s ease-out both' }}
      >
        {activeTab === 'visao_geral' && (
          <OverviewTab data={dashboardData} filtro={filtroTempo} setFiltro={setFiltroTempo} loading={loading} />
        )}
        {activeTab === 'minha_operacao' && (
          isFree ? (
            <ProGate>
              <OperationTab onNewGoal={() => {}} onSelectMeta={() => {}} />
            </ProGate>
          ) : (
            <OperationTab
              onNewGoal={() => setShowNewGoal(true)}
              onSelectMeta={handleSelectMeta}
            />
          )
        )}
        {activeTab === 'metas_fechamento' && (
          isFree ? <ProGate><GoalsTab /></ProGate> : <GoalsTab />
        )}
        {activeTab === 'lixeira' && (
          isFree ? <ProGate><TrashTab /></ProGate> : <TrashTab />
        )}
      </div>

      {/* Modals */}
      <NewGoalModal isOpen={showNewGoal} onClose={() => setShowNewGoal(false)} />
    </DashboardLayout>
  )
}

// ═══════════════════ ROTATING TICKER ═══════════════════
function RotatingTicker({ messages, color = '#60a5fa' }: { messages: string[]; color?: string }) {
  const [idx, setIdx] = useState(0)
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    if (messages.length <= 1) return
    const timer = setInterval(() => {
      setVisible(false)
      setTimeout(() => {
        setIdx(prev => (prev + 1) % messages.length)
        setVisible(true)
      }, 300)
    }, 3500)
    return () => clearInterval(timer)
  }, [messages.length])

  if (messages.length === 0) return null
  return (
    <p
      className="text-[10px] font-medium flex items-center gap-1 mt-0.5 transition-opacity duration-300"
      style={{ color, opacity: visible ? 0.75 : 0 }}
    >
      <span className="w-1 h-1 rounded-full shrink-0 inline-block" style={{ background: color }} />
      {messages[idx]}
    </p>
  )
}

// ═══════════════════ TAB 1: VISÃO GERAL ═══════════════════
function OverviewTab({ data, filtro, setFiltro, loading }: {
  data: typeof zeroDashboard; filtro: string; setFiltro: (f: string) => void; loading: boolean
}) {
  const hasData = data.total_metas > 0
  const statusText = data.lucro_acumulado > 0 ? 'Saudável' : data.lucro_acumulado < 0 ? 'Atenção' : 'Estável'
  const statusDesc = data.lucro_acumulado > 0
    ? 'Operação com resultado positivo'
    : hasData ? 'Operação estável — acompanhe as operações' : 'Nenhuma operação criada ainda'
  const statusColor = data.lucro_acumulado > 0 ? 'bg-accent-green' : data.lucro_acumulado < 0 ? 'bg-accent-red' : 'bg-accent-yellow'
  const statusTextColor = data.lucro_acumulado > 0 ? 'text-accent-green' : data.lucro_acumulado < 0 ? 'text-accent-red' : 'text-accent-yellow'

  const tickerMessages = [
    data.lucro_acumulado > 0
      ? 'Resultado positivo — operação saudável'
      : data.lucro_acumulado < 0
        ? 'Revise suas operações'
        : 'Nenhum dado registrado ainda',
    `${data.metas_ativas} operaç${data.metas_ativas === 1 ? 'ão ativa' : 'ões ativas'}`,
    `Taxa de acerto: ${data.taxa_acerto}%`,
    ...(data.metas_fechadas > 0
      ? [`${data.metas_fechadas} operaç${data.metas_fechadas === 1 ? 'ão' : 'ões'} fechadas`]
      : []),
    `${data.casas_ativas} casa${data.casas_ativas === 1 ? '' : 's'} ativa${data.casas_ativas === 1 ? '' : 's'}`,
  ]

  if (loading) {
    return (
      <div className="py-20 text-center">
        <Loader2 size={32} className="animate-spin text-accent-green mx-auto mb-3" />
        <p className="text-sm text-text-muted">Carregando dados...</p>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* Status + Meta count — side by side */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Status card */}
        <div
          className="flex items-center justify-between px-4 py-3.5 rounded-xl"
          style={data.lucro_acumulado > 0 ? {
            background: 'rgba(16,185,129,0.08)',
            border: '1px solid rgba(16,185,129,0.45)',
            boxShadow: '0 0 20px rgba(16,185,129,0.08), inset 0 1px 0 rgba(16,185,129,0.12)',
          } : data.lucro_acumulado < 0 ? {
            background: 'rgba(239,68,68,0.08)',
            border: '1px solid rgba(239,68,68,0.45)',
            boxShadow: '0 0 20px rgba(239,68,68,0.08), inset 0 1px 0 rgba(239,68,68,0.12)',
          } : {
            background: 'rgba(245,158,11,0.08)',
            border: '1px solid rgba(245,158,11,0.45)',
            boxShadow: '0 0 20px rgba(245,158,11,0.08), inset 0 1px 0 rgba(245,158,11,0.12)',
          }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
              style={data.lucro_acumulado > 0 ? {
                background: 'rgba(16,185,129,0.15)',
              } : data.lucro_acumulado < 0 ? {
                background: 'rgba(239,68,68,0.15)',
              } : {
                background: 'rgba(245,158,11,0.15)',
              }}
            >
              <Activity size={14} style={{ color: data.lucro_acumulado > 0 ? '#10b981' : data.lucro_acumulado < 0 ? '#ef4444' : '#f59e0b' }} />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Status operacional</p>
              <p className="text-[10px] text-text-muted mt-0.5">{statusDesc}</p>
            </div>
          </div>
          <span
            className="text-sm font-bold"
            style={{ color: data.lucro_acumulado > 0 ? '#10b981' : data.lucro_acumulado < 0 ? '#ef4444' : '#f59e0b' }}
          >
            {statusText}
          </span>
        </div>

        {/* Lucro total card */}
        <div
          className="flex items-center justify-between px-4 py-3.5 rounded-xl"
          style={{
            background: 'rgba(96,165,250,0.08)',
            border: '1px solid rgba(96,165,250,0.45)',
            boxShadow: '0 0 20px rgba(96,165,250,0.08), inset 0 1px 0 rgba(96,165,250,0.12)',
          }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
              style={{ background: 'rgba(96,165,250,0.15)' }}
            >
              <TrendingUp size={14} style={{ color: '#60a5fa' }} />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Lucro total acumulado</p>
              <RotatingTicker messages={tickerMessages} />
            </div>
          </div>
          <p
            className="text-sm font-black mono-value"
            style={{ color: '#60a5fa', fontFamily: 'var(--font-mono)' }}
          >
            {data.lucro_acumulado >= 0 ? '+' : ''}{formatBRL(data.lucro_acumulado)}
          </p>
        </div>
      </div>

      {/* Main grid — lucro card + compact stats strip */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 lg:gap-6">
        <Card
          className="lg:col-span-3 overflow-hidden"
          hover
          glow={data.lucro_acumulado > 0 ? 'green' : data.lucro_acumulado < 0 ? 'red' : 'violet'}
        >
          {data.lucro_acumulado !== 0 && (
            <SparklineBackground positive={data.lucro_acumulado > 0} />
          )}
          <div className="mb-4">
            <p className="text-sm text-text-secondary mb-3">Lucro final acumulado</p>
            <PillTabs
              options={['Tudo', 'Hoje', 'Ontem', '7d', '30d']}
              active={filtro}
              onChange={setFiltro}
            />
          </div>
          <div className="mt-3">
            <MoneyDisplay value={data.lucro_acumulado} size="xl" />
          </div>
          <p className={cn('text-xs mt-2 font-medium', data.lucro_acumulado > 0 ? 'text-accent-green' : 'text-text-muted')}>
            {data.lucro_acumulado > 0 ? 'Resultado positivo' : data.lucro_acumulado < 0 ? 'Resultado negativo' : 'Nenhum dado ainda'}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-4 border-t border-border">
            <div>
              <p className="text-[10px] text-text-muted uppercase tracking-wider">Operações ativas</p>
              <p className="text-lg font-bold mono-value text-accent-green">{data.metas_ativas}</p>
            </div>
            <div>
              <p className="text-[10px] text-text-muted uppercase tracking-wider">Operações fechadas</p>
              <p className="text-lg font-bold mono-value">{data.metas_fechadas}</p>
            </div>
            <div>
              <p className="text-[10px] text-text-muted uppercase tracking-wider">Total operações</p>
              <p className="text-lg font-bold mono-value">{data.total_metas}</p>
            </div>
            <div>
              <p className="text-[10px] text-text-muted uppercase tracking-wider">Casas ativas</p>
              <p className="text-lg font-bold mono-value text-accent-blue">{data.casas_ativas}</p>
            </div>
          </div>
        </Card>

        {/* Compact stats strip — row on mobile, column on lg */}
        <div
          className="flex flex-row lg:flex-col overflow-x-auto lg:overflow-hidden rounded-xl"
          style={{
            background: 'rgba(255,255,255,0.02)',
            border: '1px solid rgba(255,255,255,0.07)',
            backdropFilter: 'blur(12px)',
          }}
        >
          {([
            { label: 'Depositado',      value: formatBRL(data.deposito_total), color: '#ef4444', rgb: '239,68,68',   dot: 'bg-accent-red',    bg: 'rgba(239,68,68,0.06)',   hint: data.bloqueado_total > 0 ? `Bloq: ${formatBRL(data.bloqueado_total)}` : undefined },
            { label: 'Sacado',          value: formatBRL(data.saque_total),    color: '#10b981', rgb: '16,185,129',  dot: 'bg-accent-green',  bg: 'rgba(16,185,129,0.06)', hint: undefined },
            { label: 'Lucro bruto',     value: formatBRL(data.lucro_bruto),    color: data.lucro_bruto >= 0 ? '#10b981' : '#ef4444', rgb: data.lucro_bruto >= 0 ? '16,185,129' : '239,68,68',  dot: data.lucro_bruto >= 0 ? 'bg-accent-green' : 'bg-accent-red',  bg: data.lucro_bruto >= 0 ? 'rgba(16,185,129,0.04)' : 'rgba(239,68,68,0.04)', hint: undefined },
            { label: 'Taxa acerto',     value: `${data.taxa_acerto}%`,         color: '#f59e0b', rgb: '245,158,11',  dot: 'bg-accent-yellow', bg: 'rgba(245,158,11,0.06)', hint: undefined },
            { label: 'Total operações', value: String(data.total_metas),       color: '#60a5fa', rgb: '96,165,250',  dot: 'bg-accent-blue',   bg: 'rgba(96,165,250,0.06)', hint: undefined },
          ]).map((item, i, arr) => (
            <div
              key={i}
              className={cn(
                'flex shrink-0 lg:shrink lg:flex-none flex-col lg:flex-row items-center lg:justify-between',
                'gap-1 px-3 py-3 lg:px-4 lg:py-4 transition-all duration-200 cursor-default min-w-[110px] lg:min-w-0',
                i < arr.length - 1 && 'border-r lg:border-r-0 lg:border-b border-white/5'
              )}
              style={{ background: `linear-gradient(135deg, ${item.bg} 0%, transparent 100%)` }}
              onMouseEnter={e => { e.currentTarget.style.background = `linear-gradient(135deg, rgba(${item.rgb},0.09) 0%, transparent 100%)`; e.currentTarget.style.boxShadow = `inset 0 0 0 1px rgba(${item.rgb},0.14)` }}
              onMouseLeave={e => { e.currentTarget.style.background = `linear-gradient(135deg, ${item.bg} 0%, transparent 100%)`; e.currentTarget.style.boxShadow = '' }}
            >
              <div className="flex items-center gap-1.5">
                <div className={cn('w-1.5 h-1.5 rounded-full shrink-0', item.dot)} />
                <span className="text-[10px] text-text-muted uppercase tracking-wider whitespace-nowrap">{item.label}</span>
              </div>
              <div className="flex flex-col items-center lg:items-end">
                <span className="text-sm font-bold mono-value" style={{ color: item.color, fontFamily: 'var(--font-mono)' }}>
                  {item.value}
                </span>
                {item.hint && (
                  <span className="text-[9px] text-text-muted opacity-70">{item.hint}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom grid — operações recentes + performance por plataforma */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        {/* Operações recentes */}
        <Card hover>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold">Operações Recentes</h3>
            <span className="text-xs text-text-muted">{data.remessas_recentes.length} total</span>
          </div>
          {data.remessas_recentes.length === 0 ? (
            <div className="flex items-center justify-center h-24 text-sm text-text-muted">
              Nenhuma remessa registrada
            </div>
          ) : (
            <div className="space-y-3">
              {data.remessas_recentes.map((r: any, i: number) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold',
                      'bg-bg-surface-light border border-border'
                    )}>
                      O
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{r.operador_nome}</span>
                        <Badge variant={r.resultado >= 0 ? 'lucro' : 'perda'}>
                          {r.resultado >= 0 ? 'Lucro' : 'Perda'}
                        </Badge>
                      </div>
                      <p className="text-[10px] text-text-muted flex items-center gap-1">
                        <Clock size={8} />
                        {r.rede_sigla || 'N/A'} · {new Date(r.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                  <MoneyDisplay value={r.resultado} size="sm" />
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Performance por Plataforma — usa metas_filtradas para respeitar filtro de data */}
        {(() => {
          const casasMap: Record<string, number> = {}
          data.metas_filtradas.forEach((m: any) => {
            const k = m.plataforma || '—'
            casasMap[k] = (casasMap[k] || 0) + Number(m.resultado_liquido || 0)
          })
          const casasData = Object.entries(casasMap)
            .map(([name, value]) => ({ name, value: Math.round(value) }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 8)
          return (
            <Card hover>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold">Performance por Casa</h3>
                <span className="text-xs text-text-muted">{casasData.length} casas</span>
              </div>
              {casasData.length === 0 ? (
                <div className="flex items-center justify-center h-32 text-sm text-text-muted">
                  Nenhuma casa registrada
                </div>
              ) : (
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={casasData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#555' }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#555' }} tickLine={false} axisLine={false} tickFormatter={v => `R$${(Math.abs(v) / 1000).toFixed(0)}k`} />
                      <Tooltip
                        contentStyle={{ background: '#0f0f1a', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8, fontSize: 11, color: '#fff' }}
                        labelStyle={{ color: '#e2e8f0', fontWeight: 700, marginBottom: 2 }}
                        itemStyle={{ color: '#fff' }}
                        formatter={(val: any) => [formatBRL(val), 'Resultado']}
                      />
                      <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={32}>
                        {casasData.map((entry, i) => (
                          <Cell key={i} fill={entry.value >= 0 ? 'rgba(34,197,94,0.75)' : 'rgba(239,68,68,0.70)'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
          )
        })()}
      </div>

      {/* Análise de IA — estatísticas probabilísticas */}
      <AIAnalysisSection analise={data.analise} />
    </div>
  )
}

// ═══════════════════ ANÁLISE DE IA ═══════════════════
function AIAnalysisSection({ analise }: { analise: any }) {
  if (!analise) return null

  const tendIcon = analise.taxa_acerto_tendencia === 'subindo'
    ? <ArrowUp size={12} className="text-accent-green" />
    : analise.taxa_acerto_tendencia === 'caindo'
      ? <ArrowDown size={12} className="text-accent-red" />
      : <Minus size={12} className="text-accent-yellow" />

  const tendColor = analise.taxa_acerto_tendencia === 'subindo' ? '#10b981'
    : analise.taxa_acerto_tendencia === 'caindo' ? '#ef4444' : '#f59e0b'

  const tendLabel = analise.taxa_acerto_tendencia === 'subindo' ? 'Subindo'
    : analise.taxa_acerto_tendencia === 'caindo' ? 'Caindo' : 'Estável'

  const cards = [
    {
      Icon: ShieldCheck,
      label: 'Taxa de Acerto',
      value: `${Number(analise.taxa_acerto_geral ?? 0).toFixed(1)}%`,
      sub: (
        <span className="flex items-center gap-1" style={{ color: tendColor }}>
          {tendIcon} {tendLabel}
        </span>
      ),
      rgb: '96,165,250',
    },
    {
      Icon: Target,
      label: 'Lucro Médio / Meta',
      value: formatBRL(Number(analise.lucro_medio_meta ?? 0)),
      sub: <span className="text-text-muted">Metas fechadas</span>,
      rgb: analise.lucro_medio_meta >= 0 ? '16,185,129' : '239,68,68',
    },
    {
      Icon: Zap,
      label: 'Projeção Próx. Meta',
      value: formatBRL(Number(analise.projecao_proxima_meta ?? 0)),
      sub: <span className="text-text-muted">±{formatBRL(Number(analise.desvio_padrao ?? 0))} desvio</span>,
      rgb: '245,158,11',
    },
    {
      Icon: BarChart2,
      label: 'Remessas Lucrativas',
      value: `${analise.remessas_lucrativas ?? 0} / ${analise.total_remessas ?? 0}`,
      sub: <span className="text-text-muted">Média por remessa: {formatBRL(Number(analise.lucro_medio_remessa ?? 0))}</span>,
      rgb: '167,139,250',
    },
  ]

  return (
    <div
      className="rounded-xl p-4"
      style={{
        background: 'rgba(96,165,250,0.03)',
        border: '1px solid rgba(96,165,250,0.15)',
      }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: 'rgba(96,165,250,0.15)' }}>
          <Brain size={13} style={{ color: '#60a5fa' }} />
        </div>
        <span className="text-sm font-bold text-text-primary">Análise de IA</span>
        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ background: 'rgba(96,165,250,0.15)', color: '#60a5fa' }}>
          PROBABILÍSTICO
        </span>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 items-stretch">
        {cards.map(({ Icon, label, value, sub, rgb }) => (
          <div
            key={label}
            className="rounded-lg p-3 flex flex-col items-center justify-center text-center gap-1.5 min-h-[90px] h-full"
            style={{
              background: `rgba(${rgb},0.05)`,
              border: `1px solid rgba(${rgb},0.20)`,
            }}
          >
            <div className="flex items-center gap-1.5">
              <Icon size={11} style={{ color: `rgba(${rgb},1)` }} />
              <span className="text-[10px] text-text-muted uppercase tracking-wider">{label}</span>
            </div>
            <p className="text-base font-black mono-value" style={{ color: `rgba(${rgb},1)`, fontFamily: 'var(--font-mono)' }}>
              {value}
            </p>
            <div className="text-[10px]">{sub}</div>
          </div>
        ))}
      </div>

      {/* Melhor / pior casa */}
      {(analise.melhor_casa || analise.pior_casa) && (
        <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t border-white/5">
          {analise.melhor_casa && (
            <div className="flex items-center gap-1.5">
              <TrendingUp size={11} className="text-accent-green" />
              <span className="text-[10px] text-text-muted">Melhor casa:</span>
              <span className="text-[10px] font-bold text-accent-green">{analise.melhor_casa}</span>
            </div>
          )}
          {analise.pior_casa && analise.pior_casa !== analise.melhor_casa && (
            <div className="flex items-center gap-1.5">
              <TrendingDown size={11} className="text-accent-red" />
              <span className="text-[10px] text-text-muted">Pior casa:</span>
              <span className="text-[10px] font-bold text-accent-red">{analise.pior_casa}</span>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ═══════════════════ GOALS META CARD (grid style) ═══════════════════
function GoalsMetaCard({ meta, onClick }: { meta: any; onClick: () => void }) {
  const resultado = Number(meta.resultado_liquido || 0)
  const isPositive = resultado > 0
  const isNegative = resultado < 0
  const isConcluida = meta.status === 'fechada' || meta.status === 'finalizada'
  const isAtiva = meta.status === 'ativa'
  const progressPct = Math.min(100, Math.round(((meta.contas_atingidas || 0) / (meta.contas_total || 1)) * 100))
  const dateStr = meta.created_at ? new Date(meta.created_at).toLocaleDateString('pt-BR') : '—'

  const borderColor = isConcluida
    ? 'rgba(156,163,175,0.40)'
    : isPositive ? 'rgba(34,197,94,0.40)'
    : isNegative ? 'rgba(239,68,68,0.40)'
    : 'rgba(245,158,11,0.40)'

  const barColor = isPositive ? 'bg-accent-green' : isNegative ? 'bg-accent-red' : 'bg-accent-yellow'

  const initials = (meta.rede_sigla || meta.plataforma || meta.titulo || 'Op').substring(0, 2).toUpperCase()

  return (
    <button
      onClick={onClick}
      className="text-left w-full rounded-xl border overflow-hidden transition-all duration-200 hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]"
      style={{
        background: 'rgba(255,255,255,0.025)',
        borderColor,
        borderTopWidth: '3px',
      }}
    >
      {/* Status bar */}
      <div className="flex items-center justify-between px-3 pt-2.5 pb-1">
        <span
          className="text-[9px] font-black uppercase px-2 py-0.5 rounded"
          style={isConcluida
            ? { background: 'rgba(156,163,175,0.15)', color: '#9ca3af', border: '1px solid rgba(156,163,175,0.25)' }
            : isNegative
              ? { background: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.25)' }
              : { background: 'rgba(245,158,11,0.15)', color: '#fbbf24', border: '1px solid rgba(245,158,11,0.25)' }
          }
        >
          {isConcluida ? 'CONCLUIDA' : isNegative ? 'EM PREJUIZO' : 'EM RISCO'}
        </span>
        {isAtiva && (
          <span className="flex items-center gap-1 text-[9px] text-accent-green font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse-glow" />
            LIVE
          </span>
        )}
      </div>

      {/* Name */}
      <div className="px-3 pb-1">
        <div className="flex items-center gap-1.5">
          <span
            className="w-2 h-2 rounded-full shrink-0"
            style={{ background: borderColor }}
          />
          <p className="text-sm font-black truncate">{meta.titulo}</p>
        </div>
        <p className="text-[10px] text-text-muted mt-0.5">{dateStr} · {meta.remessas_count || 0} remessas</p>
      </div>

      {/* Progress */}
      <div className="px-3 pb-2">
        <div className="flex items-center justify-between text-[9px] text-text-muted mb-1">
          <span className="uppercase font-semibold">Progresso</span>
          <span>{meta.contas_atingidas || 0}/{meta.contas_total || 0}</span>
        </div>
        <div className="h-1.5 bg-bg-surface rounded-full overflow-hidden">
          <div className={cn('h-full rounded-full transition-all duration-700', barColor)} style={{ width: `${progressPct}%` }} />
        </div>
      </div>

      {/* Result */}
      <div className="px-3 pb-3">
        <p className="text-[9px] text-text-muted uppercase font-semibold mb-0.5">
          {isConcluida ? 'LUCRO FINAL' : 'RESULTADO'}
        </p>
        <p
          className="text-base font-black mono-value"
          style={{ color: isPositive ? '#4ade80' : isNegative ? '#f87171' : '#6b7280' }}
        >
          {isPositive ? '+' : ''}{formatBRL(isConcluida ? Number(meta.lucro_final || 0) : resultado)}
        </p>
      </div>
    </button>
  )
}

// ═══════════════════ TAB 2: MINHA OPERAÇÃO (SUPABASE) ═══════════════════
function OperationTab({ onNewGoal, onSelectMeta }: { onNewGoal: () => void; onSelectMeta: (m: any) => void }) {
  const { addToast } = useToast()
  const [metas, setMetas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadMetas = useCallback(async () => {
    setLoading(true)
    try {
      const data = await getMetas()
      setMetas(data.filter((m: any) => m.status !== 'lixeira'))
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao carregar', message: err.message })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadMetas() }, [loadMetas])

  const totalMetas    = metas.length
  const totalContas   = metas.reduce((a: number, m: any) => a + Number(m.contas_atingidas || 0), 0)
  const depositoTotal = metas.reduce((a: number, m: any) => a + Number(m.deposito_total   || 0), 0)
  const saqueTotal    = metas.reduce((a: number, m: any) => a + Number(m.saque_total      || 0), 0)
  const lucroTotal    = metas.reduce((a: number, m: any) => a + Number(m.resultado_liquido || 0), 0)

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">Minha operação</h2>
          <p className="text-sm text-text-muted">Operações e remessas do admin</p>
        </div>
        <Button onClick={onNewGoal}>
          <Plus size={16} />
          Nova operação
        </Button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {([
          { label: 'Operações',      value: <span className="text-lg font-bold mono-value" style={{ color: '#60a5fa' }}>{totalMetas}</span>,       rgb: '96,165,250'  },
          { label: 'Contas',         value: <span className="text-lg font-bold mono-value" style={{ color: '#67e8f9' }}>{totalContas}</span>,        rgb: '6,182,212'   },
          { label: 'Depósito total', value: <span className="text-lg font-bold mono-value" style={{ color: '#fca5a5' }}>{formatBRL(depositoTotal)}</span>, rgb: '239,68,68' },
          { label: 'Saque total',    value: <span className="text-lg font-bold mono-value" style={{ color: '#6ee7b7' }}>{formatBRL(saqueTotal)}</span>,    rgb: '16,185,129' },
          {
            label: 'Resultado líquido',
            value: <MoneyDisplay value={lucroTotal} size="md" className="text-lg" />,
            rgb: lucroTotal > 0 ? '16,185,129' : lucroTotal < 0 ? '239,68,68' : '245,158,11',
          },
        ] as const).map((item, i) => (
          <div
            key={i}
            className="rounded-2xl p-5 card-live transition-all duration-300 cursor-default"
            style={{
              background: `rgba(${item.rgb},0.07)`,
              border: `1px solid rgba(${item.rgb},0.40)`,
              boxShadow: `0 0 20px rgba(${item.rgb},0.07)`,
            }}
            onMouseEnter={e => { e.currentTarget.style.boxShadow = `0 0 0 1px rgba(${item.rgb},0.30), 0 6px 18px rgba(${item.rgb},0.09)`; e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.animation = 'none' }}
            onMouseLeave={e => { e.currentTarget.style.boxShadow = `0 0 20px rgba(${item.rgb},0.07)`; e.currentTarget.style.transform = ''; e.currentTarget.style.animation = '' }}
          >
            <p className="text-[10px] uppercase font-semibold tracking-wide mb-1" style={{ color: `rgba(${item.rgb},0.85)` }}>
              {item.label}
            </p>
            {item.value}
          </div>
        ))}
      </div>

      {/* Content */}
      {loading ? (
        <div className="py-16 text-center">
          <Loader2 size={32} className="animate-spin text-accent-green mx-auto mb-3" />
          <p className="text-sm text-text-muted">Carregando operações...</p>
        </div>
      ) : metas.length === 0 ? (
        <Card className="text-center py-16">
          <Plus size={40} className="mx-auto text-text-muted mb-4" />
          <p className="text-sm text-text-muted">Nenhuma operação criada</p>
          <p className="text-xs text-text-muted mt-1">Clique em "Nova operação" para iniciar</p>
          <Button onClick={onNewGoal} className="mt-4">
            <Plus size={16} />
            Criar primeira operação
          </Button>
        </Card>
      ) : (
        <div className="space-y-3">
          {metas.map((meta: any) => (
            <Card
              key={meta.id}
              hover
              onClick={() => onSelectMeta(meta)}
              glow={Number(meta.resultado_liquido) > 0 ? 'green' : Number(meta.resultado_liquido) < 0 ? 'red' : 'yellow'}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{meta.titulo}</span>
                    <StatusBadge status={meta.status} />
                  </div>
                  <p className="text-xs text-text-muted mt-1">
                    {meta.rede_sigla || ''} · {meta.plataforma} · {meta.contas_atingidas || 0} contas
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <MoneyDisplay value={Number(meta.resultado_liquido || 0)} size="md" />
                  <ChevronRight size={16} className="text-text-muted" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

// ═══════════════════ TAB 3: OPERAÇÕES & FECHAMENTO ═══════════════════
function GoalsTab() {
  const { addToast } = useToast()
  const [statusFilter, setStatusFilter] = useState('Todas')
  const [metas, setMetas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedMeta, setSelectedMeta] = useState<any>(null)

  const handleDeleteMeta = async (meta: any) => {
    try {
      await updateMetaStatus(meta.id, 'lixeira')
      setMetas(prev => prev.filter(m => m.id !== meta.id))
      setSelectedMeta(null)
      addToast({ type: 'success', title: 'Operação movida para a lixeira' })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    }
  }

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await getMetas()
      setMetas(data.filter((m: any) => m.status !== 'lixeira'))
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const statusMap: Record<string, string> = {
    'Todas': '', 'Ativas': 'ativa', 'Finalizadas': 'finalizada',
  }
  const filtered = statusFilter === 'Todas'
    ? metas
    : metas.filter(m => m.status === statusMap[statusFilter])

  const emLucro = metas.filter(m => Number(m.resultado_liquido || 0) > 0 && m.status === 'ativa').length
  const emPrejuizo = metas.filter(m => Number(m.resultado_liquido || 0) < 0 && m.status === 'ativa').length
  const neutras = metas.filter(m => Number(m.resultado_liquido || 0) === 0 && m.status === 'ativa').length
  const concluidas = metas.filter(m => m.status === 'fechada' || m.status === 'finalizada').length

  const summaryCards = [
    { count: emLucro, label: 'EM LUCRO', color: '#4ade80', bg: 'rgba(34,197,94,0.07)', border: 'rgba(34,197,94,0.25)', Icon: TrendingUp },
    { count: emPrejuizo, label: 'EM PREJUIZO', color: '#f87171', bg: 'rgba(239,68,68,0.07)', border: 'rgba(239,68,68,0.25)', Icon: TrendingDown },
    { count: neutras, label: 'NEUTRAS', color: '#fbbf24', bg: 'rgba(245,158,11,0.07)', border: 'rgba(245,158,11,0.25)', Icon: Minus },
    { count: concluidas, label: 'CONCLUIDAS', color: '#9ca3af', bg: 'rgba(156,163,175,0.07)', border: 'rgba(156,163,175,0.25)', Icon: Award },
  ]

  const leituraMsg = metas.length === 0
    ? 'Nenhuma operação registrada ainda'
    : emPrejuizo > 0
      ? `${emPrejuizo} operação${emPrejuizo > 1 ? 'ões' : ''} em prejuízo — revise as remessas bloqueadas`
      : emLucro > 0
        ? `${emLucro} operação${emLucro > 1 ? 'ões' : ''} em lucro — operação saudável`
        : 'Operação estável — acompanhe o progresso das operações'

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <PillTabs
          options={['Todas', 'Ativas', 'Finalizadas']}
          active={statusFilter}
          onChange={setStatusFilter}
        />
        <button onClick={load} className="ml-auto p-1.5 rounded-lg hover:bg-bg-surface-light text-text-muted hover:text-text-primary transition-colors">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {summaryCards.map(({ count, label, color, bg, border, Icon }) => (
          <div
            key={label}
            className="rounded-xl p-3 border"
            style={{ background: bg, borderColor: border }}
          >
            <div className="flex items-center gap-2">
              <Icon size={14} style={{ color }} />
              <span className="text-xl font-black" style={{ color }}>{count}</span>
              <span className="text-[10px] font-bold text-text-muted">{count === 1 ? 'operação' : 'operações'}</span>
            </div>
            <p className="text-[9px] font-black uppercase tracking-wider mt-1" style={{ color }}>{label}</p>
          </div>
        ))}
      </div>

      {/* Leitura da operação */}
      <div
        className="flex items-center justify-between px-4 py-3 rounded-xl border"
        style={{ background: 'rgba(16,185,129,0.05)', borderColor: 'rgba(16,185,129,0.20)' }}
      >
        <div>
          <p className="text-xs font-bold text-accent-green">Leitura da operação</p>
          <p className="text-[10px] text-text-muted">Análise automática em tempo real</p>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse-glow" />
            <span className="text-xs text-text-secondary">{leituraMsg}</span>
          </div>
        </div>
        <span
          className="text-[10px] font-black px-2.5 py-1 rounded-lg"
          style={{ background: 'rgba(16,185,129,0.15)', color: '#4ade80', border: '1px solid rgba(16,185,129,0.30)' }}
        >
          • AO VIVO
        </span>
      </div>

      {/* Cards */}
      {loading ? (
        <div className="py-16 text-center">
          <Loader2 size={32} className="animate-spin text-accent-green mx-auto mb-3" />
          <p className="text-sm text-text-muted">Carregando...</p>
        </div>
      ) : filtered.length === 0 ? (
        <Card className="text-center py-16">
          <AlertTriangle size={40} className="mx-auto text-text-muted mb-4" />
          <p className="text-sm text-text-muted">Nenhuma operação encontrada</p>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filtered.map((meta: any) => (
            <GoalsMetaCard key={meta.id} meta={meta} onClick={() => setSelectedMeta(meta)} />
          ))}
        </div>
      )}

      {/* Detail Modal */}
      <GoalDetailModal
        isOpen={!!selectedMeta}
        onClose={() => setSelectedMeta(null)}
        meta={selectedMeta}
        onDelete={handleDeleteMeta}
      />
    </div>
  )
}

// ═══════════════════ TAB 4: LIXEIRA ═══════════════════
function TrashTab() {
  const { addToast } = useToast()
  const [metas, setMetas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [restoreTarget, setRestoreTarget] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [restoring, setRestoring] = useState(false)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    async function load() {
      setLoading(true)
      try {
        const data = await getMetas('lixeira')
        setMetas(data)
      } catch (err: any) {
        addToast({ type: 'error', title: 'Erro', message: err.message })
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const handleRestore = async () => {
    if (!restoreTarget) return
    setRestoring(true)
    try {
      await updateMetaStatus(restoreTarget, 'reativar')
      setMetas(prev => prev.filter(m => m.id !== restoreTarget))
      addToast({ type: 'success', title: 'Operação restaurada!' })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    } finally {
      setRestoring(false)
      setRestoreTarget(null)
    }
  }

  const handlePermanentDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      await permanentDeleteMeta(deleteTarget)
      setMetas(prev => prev.filter(m => m.id !== deleteTarget))
      addToast({ type: 'success', title: 'Operação excluída permanentemente' })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  return (
    <>
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4 rounded-xl border mb-4"
        style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(255,255,255,0.07)' }}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl border border-border flex items-center justify-center bg-bg-surface-light">
            <Trash2 size={18} className="text-text-muted" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold">Lixeira</h3>
              <span
                className="text-[9px] font-black uppercase px-2 py-0.5 rounded"
                style={{ background: 'rgba(156,163,175,0.15)', color: '#9ca3af', border: '1px solid rgba(156,163,175,0.25)' }}
              >
                AREA SECUNDARIA
              </span>
            </div>
            <p className="text-xs text-text-muted">Operações excluídas · restaurar ou remover permanentemente</p>
          </div>
        </div>
        {metas.length > 0 && (
          <span className="text-sm font-black text-text-muted">
            {metas.length} <span className="text-[10px] uppercase font-semibold">{metas.length === 1 ? 'ITEM' : 'ITENS'}</span>
          </span>
        )}
      </div>

      {loading ? (
        <div className="py-16 text-center">
          <Loader2 size={32} className="animate-spin text-accent-yellow mx-auto mb-3" />
          <p className="text-sm text-text-muted">Carregando lixeira...</p>
        </div>
      ) : metas.length === 0 ? (
        <Card className="text-center py-16">
          <Trash2 size={40} className="mx-auto text-text-muted mb-4" />
          <p className="text-sm text-text-muted">Nenhuma operação na lixeira</p>
          <p className="text-xs text-text-muted mt-1">Operações deletadas aparecerão aqui</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {metas.map((meta: any) => {
            const initials = (meta.rede_sigla || meta.plataforma || meta.titulo || 'Op').substring(0, 2).toUpperCase()
            const resultado = Number(meta.resultado_liquido || 0)
            return (
              <div
                key={meta.id}
                className="flex items-center gap-4 px-5 py-4 rounded-xl border"
                style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(255,255,255,0.07)' }}
              >
                {/* Avatar */}
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-sm font-black text-violet-300"
                  style={{ background: 'linear-gradient(135deg, rgba(124,58,237,0.30), rgba(109,40,217,0.15))', border: '1px solid rgba(124,58,237,0.35)' }}
                >
                  {initials}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm">{meta.titulo}</span>
                    <span
                      className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded"
                      style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.25)' }}
                    >
                      EXCLUÍDA
                    </span>
                  </div>
                  <p className="text-xs text-text-muted mt-0.5">
                    {meta.operador_nome || 'Operador'} · {meta.contas_atingidas || 0} remessas ·{' '}
                    <span className={resultado >= 0 ? 'text-accent-green' : 'text-accent-red'}>
                      {resultado >= 0 ? '+' : ''}{formatBRL(resultado)}
                    </span>
                  </p>
                  {meta.updated_at && (
                    <p className="text-[10px] text-text-muted flex items-center gap-1 mt-0.5">
                      <Clock size={9} />
                      Excluída em {new Date(meta.updated_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setRestoreTarget(meta.id)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-black transition-all hover:opacity-90 active:scale-95"
                    style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
                  >
                    <RotateCcw size={13} /> Restaurar
                  </button>
                  <button
                    onClick={() => setDeleteTarget(meta.id)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:opacity-90 active:scale-95"
                    style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.30)' }}
                  >
                    <Trash2 size={13} /> Excluir
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <ConfirmModal
        isOpen={!!restoreTarget}
        onClose={() => setRestoreTarget(null)}
        onConfirm={handleRestore}
        title="Restaurar operação?"
        message="A operação será reativada e voltará a aparecer na sua lista."
        confirmLabel="Restaurar"
        loading={restoring}
      />

      <ConfirmModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handlePermanentDelete}
        title="Excluir permanentemente?"
        message="Esta ação não pode ser desfeita. A operação e todas as remessas serão removidas definitivamente."
        confirmLabel="Excluir"
        loading={deleting}
      />
    </>
  )
}
