'use client'

import { useState, useEffect, useMemo } from 'react'
import { useParams, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge, StatusBadge } from '@/components/ui/Badge'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { PillTabs } from '@/components/ui/Tabs'
import { CloseGoalModal } from '@/components/modals/CloseGoalModal'
import { EditMetaModal } from '@/components/modals/EditMetaModal'
import { ConfirmModal } from '@/components/modals/ConfirmModal'
import { useToast } from '@/components/ui/Toast'
import { cn, formatBRL } from '@/lib/utils'
import { notify } from '@/lib/notifications'
import {
  getMetaById, getRemessas, createRemessa, deleteRemessa,
  updateMetaStatus, updateRemessaStatus
} from '@/lib/supabase-service'

import {
  ArrowLeft, Edit, CheckCircle2, Plus, Sparkles,
  Clock, Trash2, RefreshCw, TrendingUp, ChevronLeft, ChevronRight, ChevronDown, Loader2, Lock, AlertTriangle
} from 'lucide-react'

// ── Stat card with color theme, float idle + hover glow ──────
type StatColor = 'violet' | 'cyan' | 'emerald' | 'red' | 'amber'

const STAT_PALETTE: Record<StatColor, { bg: string; border: string; shadow: string; title: string }> = {
  violet:  { bg: 'rgba(124,58,237,0.07)',  border: 'rgba(124,58,237,0.45)', shadow: 'rgba(124,58,237,0.30)', title: '#a78bfa' },
  cyan:    { bg: 'rgba(6,182,212,0.07)',   border: 'rgba(6,182,212,0.45)',  shadow: 'rgba(6,182,212,0.30)',  title: '#67e8f9' },
  emerald: { bg: 'rgba(16,185,129,0.07)',  border: 'rgba(16,185,129,0.45)', shadow: 'rgba(16,185,129,0.30)', title: '#6ee7b7' },
  red:     { bg: 'rgba(239,68,68,0.07)',   border: 'rgba(239,68,68,0.45)',  shadow: 'rgba(239,68,68,0.30)',  title: '#fca5a5' },
  amber:   { bg: 'rgba(245,158,11,0.07)',  border: 'rgba(245,158,11,0.45)', shadow: 'rgba(245,158,11,0.30)', title: '#fcd34d' },
}

function StatCard({
  label, children, color, delay = 0,
}: { label: string; children: React.ReactNode; color: StatColor; delay?: number }) {
  const p = STAT_PALETTE[color]
  return (
    <div
      style={{
        background: p.bg,
        border: `1px solid ${p.border}`,
        borderRadius: '0.75rem',
        padding: '1rem',
        boxShadow: `0 0 0 rgba(0,0,0,0)`,
        animation: `card-float 4s ease-in-out infinite`,
        animationDelay: `${delay}s`,
        transition: 'box-shadow 0.25s ease, transform 0.25s ease, border-color 0.25s ease',
        cursor: 'default',
      }}
      onMouseEnter={e => {
        const el = e.currentTarget
        el.style.boxShadow = `0 8px 32px ${p.shadow}, 0 0 0 1px ${p.border}`
        el.style.transform = 'translateY(-4px) scale(1.015)'
        el.style.animation = 'none'
      }}
      onMouseLeave={e => {
        const el = e.currentTarget
        el.style.boxShadow = '0 0 0 rgba(0,0,0,0)'
        el.style.transform = ''
        el.style.animation = `card-float 4s ease-in-out infinite ${delay}s`
      }}
    >
      <p className="text-[10px] uppercase font-semibold tracking-wide" style={{ color: p.title }}>{label}</p>
      <div className="mt-1">{children}</div>
    </div>
  )
}

interface Remessa {
  id: string
  titulo: string | null
  tipo: string
  saldo_ini: number
  contas: number
  deposito: number
  saque: number
  resultado: number
  status: string
  notas: string | null
  created_at: string
}

export default function MetaDetailPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const metaId = params.id as string
  const { addToast } = useToast()

  // State from URL params (fallback) or DB
  const [metaTitulo, setMetaTitulo] = useState(searchParams.get('titulo') || 'Meta')
  const [metaPlataforma, setMetaPlataforma] = useState(searchParams.get('plataforma') || '')
  const [metaRede, setMetaRede] = useState(searchParams.get('rede') || '')
  const [metaContas, setMetaContas] = useState(parseInt(searchParams.get('contas') || '10'))
  const [metaModelo, setMetaModelo] = useState(searchParams.get('modelo') || 'salario_bau')

  // State
  const [status, setStatus] = useState<'ativa' | 'finalizada' | 'fechada'>('ativa')
  const [remessas, setRemessas] = useState<Remessa[]>([])
  const [showForm, setShowForm] = useState(true)
  const [loadingPage, setLoadingPage] = useState(true)
  const [showCloseModal, setShowCloseModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [closingMeta, setClosingMeta] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [deletingRemessa, setDeletingRemessa] = useState(false)
  const [editingStatusId, setEditingStatusId] = useState<string | null>(null)

  // Form state
  const [formTitulo, setFormTitulo] = useState('')
  const [formContas, setFormContas] = useState('1')
  const [formDeposito, setFormDeposito] = useState('')
  const [formSaque, setFormSaque] = useState('')
  const [formStatus, setFormStatus] = useState('Normal')
  const [formNotas, setFormNotas] = useState('')
  const [savingRemessa, setSavingRemessa] = useState(false)
  const [historyOpen, setHistoryOpen] = useState(true)

  const quickRemessaCounts = [1, 2, 3, 5, 10, 15, 20]

  // Load meta + remessas from Supabase
  useEffect(() => {
    async function load() {
      setLoadingPage(true)
      try {
        const [meta, remessasData] = await Promise.all([
          getMetaById(metaId),
          getRemessas(metaId),
        ])

        if (meta) {
          setMetaTitulo(meta.titulo)
          setMetaPlataforma(meta.plataforma)
          setMetaRede(meta.rede_sigla || '')
          setMetaContas(meta.contas_total)
          setMetaModelo(meta.modelo)
          setStatus(meta.status as any)
        }

        setRemessas(remessasData.map((r: any) => ({
          id: r.id,
          titulo: r.titulo,
          tipo: r.tipo,
          saldo_ini: Number(r.saldo_ini),
          contas: r.contas,
          deposito: Number(r.deposito),
          saque: Number(r.saque),
          resultado: Number(r.saque) - Number(r.deposito),
          status: r.status,
          notas: r.notas,
          created_at: r.created_at,
        })))
      } catch (err: any) {
        addToast({ type: 'error', title: 'Erro ao carregar', message: err.message })
      } finally {
        setLoadingPage(false)
      }
    }
    load()
  }, [metaId])

  // Computed — 'normal' para depósito/saque; 'bloqueado' conta como perda do depósito
  const normalRemessas = remessas.filter(r => r.status.toLowerCase() === 'normal')
  const bloqueadoRemessas = remessas.filter(r => r.status.toLowerCase() === 'bloqueado')
  const depositoTotal = normalRemessas.reduce((a, r) => a + r.deposito, 0)
  const depositoTotalGeral = remessas.reduce((a, r) => a + r.deposito, 0)
  const saqueTotal = normalRemessas.reduce((a, r) => a + r.saque, 0)
  const bloqueadoPerdas = bloqueadoRemessas.reduce((a, r) => a + r.deposito, 0)
  const lucroAcumulado = saqueTotal - depositoTotal
  const prejuizoAcum = normalRemessas.reduce((a, r) => a + (r.resultado < 0 ? Math.abs(r.resultado) : 0), 0)
                      + bloqueadoPerdas
  const resultadoLiquido = lucroAcumulado - bloqueadoPerdas
  const contasAtingidas = normalRemessas.reduce((a, r) => a + r.contas, 0)
  const taxaAcerto = normalRemessas.length > 0
    ? Math.round((normalRemessas.filter(r => r.resultado > 0).length / normalRemessas.length) * 100)
    : 0
  const score = Math.min(100, Math.round(
    (contasAtingidas / metaContas) * 40 +
    (taxaAcerto) * 0.4 +
    (resultadoLiquido > 0 ? 20 : 0)
  ))
  const mediaPorConta = contasAtingidas > 0 ? resultadoLiquido / contasAtingidas : 0
  const progressPct = Math.min(100, Math.round((contasAtingidas / metaContas) * 100))
  const formResultado = (parseFloat(formSaque) || 0) - (parseFloat(formDeposito) || 0)

  // Alert counts for footer bar
  const blockedCount  = remessas.filter(r => r.status === 'bloqueado').length
  const pendenteCount = remessas.filter(r => r.status === 'pendente').length
  const analiseCount  = remessas.filter(r => r.status === 'analise').length
  const hasAlerts     = blockedCount > 0 || pendenteCount > 0 || analiseCount > 0

  // Register remessa → Supabase
  const handleRegistrar = async () => {
    const dep = parseFloat(formDeposito) || 0
    const saq = parseFloat(formSaque) || 0
    const cts = parseInt(formContas) || 1

    setSavingRemessa(true)
    try {
      const created = await createRemessa({
        meta_id: metaId,
        titulo: formTitulo || `${remessas.length + 1}ª remessa`,
        tipo: 'remessa',
        saldo_ini: 0,
        contas: cts,
        deposito: dep,
        saque: saq,
        status: formStatus,
        notas: formNotas,
      })

      const newRemessa: Remessa = {
        id: created.id,
        titulo: created.titulo,
        tipo: created.tipo,
        saldo_ini: Number(created.saldo_ini),
        contas: created.contas,
        deposito: Number(created.deposito),
        saque: Number(created.saque),
        resultado: Number(created.saque) - Number(created.deposito),
        status: created.status,
        notas: created.notas,
        created_at: created.created_at,
      }

      setRemessas(prev => [newRemessa, ...prev])

      const st = formStatus.toLowerCase()
      if (st === 'bloqueado') {
        notify('remessa_bloqueada')
      } else if (st === 'pendente') {
        notify('remessa_pendente')
      } else if (st === 'análise' || st === 'analise') {
        notify('remessa_analise')
      } else {
        notify('remessa_registrada', {
          titulo: formTitulo || `${remessas.length + 1}ª remessa`,
          resultado: saq - dep,
          contas: cts,
        })
      }

      // Reset
      setFormTitulo('')
      setFormDeposito('')
      setFormSaque('')
      setFormContas('1')
      setFormStatus('Normal')
      setFormNotas('')
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao registrar', message: err.message })
    } finally {
      setSavingRemessa(false)
    }
  }

  // Update remessa status inline
  const handleStatusChange = async (id: string, newStatus: string) => {
    const snapshot = remessas
    setRemessas(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r))
    setEditingStatusId(null)

    const ns = newStatus.toLowerCase()
    if (ns === 'bloqueado') {
      notify('remessa_bloqueada')
    } else if (ns === 'pendente') {
      notify('remessa_pendente')
    } else if (ns === 'análise' || ns === 'analise') {
      notify('remessa_analise')
    }

    try {
      await updateRemessaStatus(id, newStatus)
    } catch (err: any) {
      setRemessas(snapshot)
      addToast({ type: 'error', title: 'Erro ao atualizar status', message: err.message })
    }
  }

  // Delete remessa
  const handleDeleteRemessa = async () => {
    if (!deleteTarget) return
    setDeletingRemessa(true)
    try {
      await deleteRemessa(deleteTarget)
      const updated = await getRemessas(metaId)
      setRemessas(updated.map((r: any) => ({
        id: r.id,
        titulo: r.titulo,
        tipo: r.tipo,
        saldo_ini: Number(r.saldo_ini),
        contas: r.contas,
        deposito: Number(r.deposito),
        saque: Number(r.saque),
        resultado: Number(r.saque) - Number(r.deposito),
        status: r.status,
        notas: r.notas,
        created_at: r.created_at,
      })))
      addToast({ type: 'success', title: 'Remessa excluída' })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao excluir', message: err.message })
    } finally {
      setDeletingRemessa(false)
      setDeleteTarget(null)
    }
  }

  // Finalizar meta
  const handleFinalizar = async () => {
    try {
      await updateMetaStatus(metaId, 'finalizar')
      setStatus('finalizada')
      setShowCloseModal(true)
      notify('meta_finalizada', { titulo: metaTitulo, resultado: resultadoLiquido })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    }
  }

  // Fechar meta com custos
  const handleFechar = async (data: { salario: number; gastos_operacionais: number }) => {
    setClosingMeta(true)
    try {
      await updateMetaStatus(metaId, 'fechar', { salario: data.salario, bau: 0, gastos_operacionais: data.gastos_operacionais })
      setStatus('fechada')
      setShowCloseModal(false)
      notify('meta_fechada', {
        titulo: metaTitulo,
        lucroFinal: resultadoLiquido + data.salario - data.gastos_operacionais,
      })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao fechar', message: err.message })
    } finally {
      setClosingMeta(false)
    }
  }

  // Reabrir
  const handleReabrir = async () => {
    try {
      await updateMetaStatus(metaId, 'reativar')
      setStatus('ativa')
      notify('meta_reativada', { titulo: metaTitulo })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    }
  }

  const insightMsg = remessas.length === 0
    ? 'Nenhuma remessa registrada ainda. Comece a operar!'
    : resultadoLiquido >= 0
      ? `Operação estável — ${remessas.length} remessas registradas`
      : `Atenção: operação negativa — revise a estratégia`

  if (loadingPage) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="text-center">
            <Loader2 size={32} className="animate-spin text-accent-green mx-auto mb-3" />
            <p className="text-sm text-text-muted">Carregando meta...</p>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className={hasAlerts ? 'pb-16' : undefined}>
      {/* Back */}
      <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors mb-4 mt-8 md:mt-0">
        <ArrowLeft size={16} /> Voltar ao painel
      </Link>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="text-2xl md:text-3xl font-black">{metaTitulo}</h1>
            <StatusBadge status={status} />
          </div>
          <p className="text-sm text-text-muted">
            {metaRede && `${metaRede} · `}{metaContas} contas · {remessas.length} remessas · {taxaAcerto}% de acerto
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setShowEditModal(true)}>
            <Edit size={14} /> Editar
          </Button>
          {status === 'ativa' && (
            <Button variant="danger" size="lg" onClick={handleFinalizar}>
              <CheckCircle2 size={15} /> Finalizar operação
            </Button>
          )}
          {(status === 'finalizada' || status === 'fechada') && (
            <Button variant="secondary" size="lg" onClick={handleReabrir}>
              Reabrir operação
            </Button>
          )}
        </div>
      </div>

      {/* Operation status */}
      <Card className={cn('mb-5',
        resultadoLiquido > 0 ? 'border-accent-green/30 bg-accent-green/5' :
        resultadoLiquido < 0 ? 'border-accent-red/30 bg-accent-red/5' : ''
      )}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn('w-2.5 h-2.5 rounded-full',
              status === 'ativa' ? 'bg-accent-green animate-pulse-glow' : 'bg-accent-yellow'
            )} />
            <div>
              <p className={cn('text-sm font-bold',
                resultadoLiquido > 0 ? 'text-accent-green' : resultadoLiquido < 0 ? 'text-accent-red' : 'text-text-primary'
              )}>
                {status === 'ativa' ? 'Operação em andamento' : status === 'finalizada' ? 'Operação finalizada' : 'Operação fechada'}
              </p>
              <p className="text-xs text-text-muted">{remessas.length} remessas registradas</p>
            </div>
          </div>
          <Badge variant={status === 'ativa' ? 'success' : status === 'finalizada' ? 'info' : 'warning'}>
            {status === 'ativa' ? 'NORMAL' : status.toUpperCase()}
          </Badge>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
        <StatCard label="Depósito total" color="violet" delay={0}>
          <p className="text-lg font-black mono-value text-text-primary">{formatBRL(depositoTotalGeral)}</p>
        </StatCard>
        <StatCard label="Saque total" color="cyan" delay={0.6}>
          <p className="text-lg font-black mono-value text-text-primary">{formatBRL(saqueTotal)}</p>
        </StatCard>
        <StatCard label="Lucro acumulado" color="emerald" delay={1.2}>
          <p className="text-lg font-black mono-value text-accent-green">{formatBRL(Math.max(0, lucroAcumulado))}</p>
        </StatCard>
        <StatCard label="Prejuízo acum." color="red" delay={1.8}>
          <p className="text-lg font-black mono-value text-accent-red">{formatBRL(prejuizoAcum)}</p>
        </StatCard>
        <StatCard label="Resultado líquido" color={resultadoLiquido > 0 ? 'emerald' : resultadoLiquido < 0 ? 'red' : 'amber'} delay={2.4}>
          <MoneyDisplay value={resultadoLiquido} size="lg" />
        </StatCard>
      </div>

      {/* Score */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
        <Card className="flex items-center gap-6">
          <div>
            <p className={cn('text-4xl font-black mono-value', score >= 70 ? 'text-accent-green' : score >= 40 ? 'text-accent-yellow' : 'text-accent-red')}>{score}</p>
            <p className="text-xs text-text-muted">Score da operação</p>
          </div>
        </Card>
        <Card>
          <p className="text-[10px] text-text-muted uppercase font-semibold mb-1">Média por conta</p>
          <MoneyDisplay value={mediaPorConta} size="lg" />
          <p className="text-xs text-text-muted mt-1">{contasAtingidas} contas processadas</p>
        </Card>
      </div>

      {/* Insights */}
      <Card className={cn('mb-5', resultadoLiquido >= 0 ? 'border-accent-green/20 bg-accent-green/5' : 'border-accent-yellow/20 bg-accent-yellow/5')}>
        <div className="flex items-center gap-2 mb-2">
          <Sparkles size={16} className="text-accent-yellow" />
          <span className="text-sm font-bold">Insights da operação</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-accent-blue/15 text-accent-blue font-bold">IA</span>
        </div>
        <div className="flex items-center gap-2">
          <CheckCircle2 size={14} className={resultadoLiquido >= 0 ? 'text-accent-green' : 'text-accent-yellow'} />
          <span className={cn('text-sm font-semibold', resultadoLiquido >= 0 ? 'text-accent-green' : 'text-accent-yellow')}>{insightMsg}</span>
        </div>
      </Card>

      {/* Progress */}
      <Card className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-bold">Progresso: {contasAtingidas}/{metaContas} contas</span>
          <span className={cn('text-sm font-bold', progressPct >= 70 ? 'text-accent-green' : progressPct >= 30 ? 'text-accent-yellow' : 'text-accent-red')}>{progressPct}%</span>
        </div>
        <div className="h-3 bg-bg-surface-light rounded-full overflow-hidden">
          <div className={cn('h-full rounded-full transition-all duration-700', progressPct >= 70 ? 'bg-accent-green' : progressPct >= 30 ? 'bg-accent-yellow' : 'bg-accent-red')} style={{ width: `${progressPct}%` }} />
        </div>
      </Card>

      {/* ═══════ REGISTER REMESSA FORM ═══════ */}
      {status === 'ativa' && (
        <Card className="mb-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Plus size={16} className="text-accent-green" />
              <h3 className="text-sm font-bold">Registrar remessa</h3>
            </div>
          </div>

          {showForm && (
            <div className="space-y-4 animate-slide-down">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-text-primary uppercase font-semibold mb-1">Título</label>
                  <input type="text" value={formTitulo} onChange={(e) => setFormTitulo(e.target.value)} placeholder="1ª remessa..."
                    className="w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-green/50 transition-all" />
                </div>
                <div>
                  <label className="block text-[10px] text-accent-blue uppercase font-semibold mb-1">Contas *</label>
                  <input type="number" inputMode="numeric" pattern="[0-9]*" value={formContas}
                    onChange={(e) => setFormContas(e.target.value.replace(/[^0-9]/g, '') || '1')} min={1}
                    className="w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm text-text-primary focus:outline-none focus:border-accent-green/50 transition-all" />
                  <div className="flex gap-1 mt-1.5">
                    {quickRemessaCounts.map(n => (
                      <button key={n} onClick={() => setFormContas(String(n))}
                        className={cn('px-1.5 py-0.5 rounded text-[10px] font-bold border transition-all',
                          parseInt(formContas) === n ? 'bg-accent-green/15 border-accent-green/30 text-accent-green' : 'bg-bg-surface border-border text-text-muted hover:text-text-secondary'
                        )}>{n}</button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] text-accent-red uppercase font-semibold mb-1">Depósito *</label>
                  <input type="text" inputMode="decimal" value={formDeposito}
                    onChange={(e) => setFormDeposito(e.target.value.replace(/[^0-9.]/g, ''))}
                    placeholder="Ex: 1055"
                    className="w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-green/50 transition-all" />
                </div>
                <div>
                  <label className="block text-[10px] text-accent-green uppercase font-semibold mb-1">Saque *</label>
                  <input type="text" inputMode="decimal" value={formSaque}
                    onChange={(e) => setFormSaque(e.target.value.replace(/[^0-9.]/g, ''))}
                    placeholder="Ex: 941"
                    className="w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-green/50 transition-all" />
                </div>
                <div>
                  <label className="block text-[10px] text-accent-yellow uppercase font-semibold mb-1">Resultado</label>
                  <div className={cn('w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm font-bold mono-value',
                    formResultado > 0 ? 'text-accent-green' : formResultado < 0 ? 'text-accent-red' : 'text-text-muted'
                  )}>{formResultado !== 0 ? formatBRL(formResultado) : 'Resultado'}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-text-muted uppercase font-semibold mb-1">Status</label>
                  <PillTabs options={['Normal', 'Pendente', 'Bloqueado', 'Análise']} active={formStatus} onChange={setFormStatus} />
                </div>
                <div>
                  <label className="block text-[10px] text-text-muted uppercase font-semibold mb-1">Notas</label>
                  <input type="text" value={formNotas} onChange={(e) => setFormNotas(e.target.value)} placeholder="Opcional..."
                    className="w-full px-3 py-2.5 bg-bg-surface-light border border-border rounded-lg text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-green/50 transition-all" />
                </div>
              </div>

              <Button onClick={handleRegistrar} size="lg"
                className="w-full bg-accent-green hover:bg-accent-green/80 text-black shadow-lg shadow-accent-green/20"
                disabled={(!formDeposito && !formSaque) || savingRemessa}>
                {savingRemessa ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
                {savingRemessa ? 'Salvando...' : 'Registrar remessa'}
              </Button>
            </div>
          )}
        </Card>
      )}

      {/* ═══════ EVENTOS DA OPERAÇÃO ═══════ */}
      {(blockedCount > 0 || pendenteCount > 0 || analiseCount > 0) && (
        <Card className="mb-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold">Eventos da operação</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {pendenteCount > 0 && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.30)', color: '#f59e0b' }}
              >
                <Clock size={11} />
                {pendenteCount} saque{pendenteCount > 1 ? 's' : ''} pendente{pendenteCount > 1 ? 's' : ''}
              </span>
            )}
            {blockedCount > 0 && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.30)', color: '#ef4444' }}
              >
                <Lock size={11} />
                {blockedCount} conta{blockedCount > 1 ? 's' : ''} bloqueada{blockedCount > 1 ? 's' : ''}
              </span>
            )}
            {analiseCount > 0 && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ background: 'rgba(96,165,250,0.12)', border: '1px solid rgba(96,165,250,0.30)', color: '#60a5fa' }}
              >
                <AlertTriangle size={11} />
                {analiseCount} banco{analiseCount > 1 ? 's' : ''} em análise
              </span>
            )}
          </div>
        </Card>
      )}

      {/* ═══════ HISTÓRICO ═══════ */}
      <Card>
        <button
          onClick={() => setHistoryOpen(v => !v)}
          className="flex items-center justify-between w-full mb-0 group"
        >
          <div className={historyOpen ? 'mb-4' : ''}>
            <h3 className="text-sm font-bold text-left">Histórico</h3>
            <p className="text-xs text-text-muted">{remessas.length} remessas · mais recentes primeiro</p>
          </div>
          <ChevronDown
            size={16}
            className="text-text-muted group-hover:text-text-primary transition-all duration-200 shrink-0"
            style={{ transform: historyOpen ? 'rotate(0deg)' : 'rotate(-90deg)' }}
          />
        </button>

        {historyOpen && (remessas.length === 0 ? (
          <div className="py-12 text-center text-sm text-text-muted">
            Nenhuma remessa registrada. Use o formulário acima.
          </div>
        ) : (
          <div className="space-y-3">
            {remessas.map((r) => {
              const st = r.status.toLowerCase()
              const isPendente = st === 'pendente' || st === 'análise' || st === 'analise'
              const isBloqueado = st === 'bloqueado'
              // Valor financeiro real conforme status:
              // bloqueado → perde o depósito (saque nunca sai)
              // pendente/analise → saque não confirmado, resultado = 0
              // normal → saque - deposito
              const displayResult = isBloqueado ? -r.deposito : isPendente ? 0 : r.resultado

              return (
              <div key={r.id} className={cn('rounded-xl border overflow-hidden',
                isBloqueado ? 'border-accent-red/30'
                : isPendente ? 'border-border'
                : displayResult > 0 ? 'border-accent-green/30' : displayResult < 0 ? 'border-accent-red/30' : 'border-border'
              )}>
                <div className={cn('px-4 py-3 flex items-center justify-between',
                  isBloqueado ? 'bg-accent-red/5'
                  : isPendente ? 'bg-bg-surface-light'
                  : displayResult > 0 ? 'bg-accent-green/5' : displayResult < 0 ? 'bg-accent-red/5' : 'bg-bg-surface-light'
                )}>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold">{r.titulo || 'Remessa'}</span>
                    <Badge
                      variant={
                        isBloqueado ? 'perda'
                        : isPendente ? 'neutral'
                        : displayResult > 0 ? 'lucro' : displayResult < 0 ? 'perda' : 'neutral'
                      }
                    >
                      {isBloqueado ? '↓ Prejuízo'
                        : isPendente ? '— Neutro'
                        : displayResult > 0 ? '↑ Lucro' : displayResult < 0 ? '↓ Prejuízo' : '— Neutro'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <MoneyDisplay value={displayResult} size="md" />
                      <p className="text-[10px] text-text-muted mono-value">
                        {formatBRL(r.contas > 0 ? displayResult / r.contas : 0)} / conta
                      </p>
                    </div>
                    <button onClick={() => setDeleteTarget(r.id)}
                      className="p-1 rounded hover:bg-accent-red/10 text-text-muted hover:text-accent-red transition-colors">
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>

                <div className="px-4 py-2 text-xs text-text-muted flex items-center gap-2 flex-wrap">
                  {editingStatusId === r.id ? (
                    <div className="flex items-center gap-1">
                      {([
                        { label: 'Normal',   cls: 'bg-accent-green/15 text-accent-green border-accent-green/40 hover:bg-accent-green/25' },
                        { label: 'Pendente', cls: 'bg-accent-yellow/15 text-accent-yellow border-accent-yellow/40 hover:bg-accent-yellow/25' },
                        { label: 'Bloqueado',cls: 'bg-accent-red/15 text-accent-red border-accent-red/40 hover:bg-accent-red/25' },
                        { label: 'Análise',  cls: 'bg-accent-blue/15 text-accent-blue border-accent-blue/40 hover:bg-accent-blue/25' },
                      ] as const).map(({ label, cls }) => (
                        <button key={label} onClick={() => handleStatusChange(r.id, label)}
                          className={cn('px-3 py-1 rounded-md border text-xs font-semibold transition-colors', cls)}>
                          {label}
                        </button>
                      ))}
                      <button onClick={() => setEditingStatusId(null)} className="ml-1 text-text-muted hover:text-accent-red transition-colors">✕</button>
                    </div>
                  ) : (
                    <button onClick={() => setEditingStatusId(r.id)}
                      title="Clique para alterar o status"
                      className={cn(
                        'inline-flex items-center gap-1 px-3 py-1 rounded-md border text-xs font-semibold transition-all cursor-pointer',
                        {
                          normal:    'bg-accent-green/15 text-accent-green border-accent-green/40 hover:bg-accent-green/25',
                          pendente:  'bg-accent-yellow/15 text-accent-yellow border-accent-yellow/40 hover:bg-accent-yellow/25',
                          bloqueado: 'bg-accent-red/15 text-accent-red border-accent-red/40 hover:bg-accent-red/25',
                          análise:   'bg-accent-blue/15 text-accent-blue border-accent-blue/40 hover:bg-accent-blue/25',
                          analise:   'bg-accent-blue/15 text-accent-blue border-accent-blue/40 hover:bg-accent-blue/25',
                        }[r.status.toLowerCase()] ?? 'bg-bg-surface-light text-text-secondary border-border hover:border-accent-green/30'
                      )}>
                      {r.status}
                      <Edit size={11} className="opacity-60" />
                    </button>
                  )}
                  <span>·</span>
                  <span>{new Date(r.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                <div className={cn('grid gap-px bg-border', (isBloqueado || isPendente) ? 'grid-cols-2' : 'grid-cols-3')}>
                  <div className="bg-bg-surface-light px-3 py-2"><p className="text-[10px] text-text-muted uppercase">Depósito</p><p className="text-xs font-bold mono-value">{formatBRL(r.deposito)}</p></div>
                  {!isBloqueado && !isPendente && (
                    <div className="bg-bg-surface-light px-3 py-2"><p className="text-[10px] text-text-muted uppercase">Saque</p><p className="text-xs font-bold mono-value">{formatBRL(r.saque)}</p></div>
                  )}
                  <div className="bg-bg-surface-light px-3 py-2"><p className="text-[10px] text-text-muted uppercase">Por conta</p><p className={cn('text-xs font-bold mono-value', displayResult > 0 ? 'text-accent-green' : displayResult < 0 ? 'text-accent-red' : 'text-text-muted')}>{formatBRL(r.contas > 0 ? displayResult / r.contas : 0)}</p></div>
                </div>
              </div>
              )
            })}
          </div>
        ))}
      </Card>

      {/* Edit meta modal */}
      <EditMetaModal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        meta={{
          id: metaId,
          titulo: metaTitulo,
          plataforma: metaPlataforma,
          rede_sigla: metaRede,
          contas_total: metaContas,
        }}
        onSaved={(updated) => {
          setMetaTitulo(updated.titulo)
          setMetaPlataforma(updated.plataforma)
          setMetaRede(updated.rede_sigla)
          setMetaContas(updated.contas_total)
        }}
      />

      {/* Close goal modal */}
      <CloseGoalModal
        isOpen={showCloseModal}
        onClose={() => setShowCloseModal(false)}
        onConfirm={handleFechar}
        metaTitulo={metaTitulo}
        metaRede={metaRede}
        lucroAcumulado={lucroAcumulado}
        prejuizoAcumulado={prejuizoAcum}
        resultadoLiquido={resultadoLiquido}
        loading={closingMeta}
      />

      {/* Delete confirm */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDeleteRemessa}
        title="Excluir remessa?"
        message="Essa ação não pode ser desfeita. Os valores da meta serão recalculados."
        confirmLabel="Excluir"
        loading={deletingRemessa}
      />

      </div>

    </DashboardLayout>
  )
}
