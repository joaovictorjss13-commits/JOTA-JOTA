'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { cn } from '@/lib/utils'
import {
  GraduationCap, Play, CheckCircle2, Circle,
  Smartphone, ChevronRight, LayoutDashboard, Zap, CreditCard
} from 'lucide-react'

const onboardingSteps = [
  { key: 'criar_meta', title: 'Criar primeira meta', desc: 'Vá em "Minha operação" no painel do operador e crie sua primeira meta de operação.', done: false },
  { key: 'registrar_remessa', title: 'Registrar remessa', desc: 'Dentro da meta, registre depósito, saque e resultado da remessa.', done: false },
  { key: 'finalizar_meta', title: 'Finalizar meta', desc: 'Quando terminar, finalize a meta. O operador finaliza e o admin fecha com custos.', done: false },
  { key: 'acompanhar_dashboard', title: 'Acompanhar dashboard', desc: 'Veja lucro do dia, resultado líquido e feed ao vivo no painel executivo.', done: false },
  { key: 'convidar_operador', title: 'Convidar operador', desc: 'Na aba Equipe, gere um link de convite e envie para seu operador.', done: false },
  { key: 'fechar_com_custos', title: 'Fechar meta com custos', desc: 'Defina salário, custo fixo e taxa do agente no fechamento final.', done: false },
]

const notificationSteps = [
  'Abra o MetaControll no navegador do celular',
  'Toque no menu do navegador e selecione "Adicionar à tela inicial"',
  'Abra o app instalado na sua tela inicial',
  'Permita as notificações quando o aviso aparecer',
  'Se não aparecer, ative manualmente nas configurações do navegador',
]

export default function TutorialPage() {
  const [steps, setSteps] = useState(onboardingSteps)
  const completedCount = steps.filter(s => s.done).length
  const progress = Math.round((completedCount / steps.length) * 100)

  const toggleStep = (key: string) => {
    setSteps(prev => prev.map(s => s.key === key ? { ...s, done: !s.done } : s))
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6 mt-8 md:mt-0">
        <div className="w-10 h-10 rounded-xl bg-cta/15 flex items-center justify-center">
          <Play size={20} className="text-cta" />
        </div>
        <div>
          <h1 className="text-2xl font-black">Guia rápido do MetaControll</h1>
          <p className="text-sm text-text-muted">Aprenda a usar a plataforma em poucos minutos</p>
        </div>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-text-muted">Progresso do tutorial</span>
        <span className="text-xs font-bold text-accent-green">{completedCount}/{steps.length}</span>
      </div>
      <div className="h-1.5 bg-bg-surface-light rounded-full overflow-hidden mb-8">
        <div
          className="h-full bg-accent-green rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Video */}
      <Card className="mb-6 overflow-hidden">
        <div className="aspect-video bg-bg-surface-light rounded-xl flex items-center justify-center relative">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-cta/20 flex items-center justify-center mx-auto mb-3 hover:bg-cta/30 cursor-pointer transition-colors">
              <Play size={28} className="text-cta ml-1" />
            </div>
            <p className="text-sm font-bold">META CONTROLL COMO FUNCIONA O SISTEMA</p>
            <p className="text-xs text-text-muted">META CONTROLL</p>
          </div>
        </div>
        <div className="flex items-center justify-between mt-4">
          <div>
            <p className="text-sm font-bold">Video aula — MetaControll</p>
            <p className="text-xs text-text-muted">Como usar o painel, criar metas, registrar remessas e fechar operações.</p>
          </div>
          <span className="px-2.5 py-1 bg-cta/15 text-cta text-[10px] font-bold rounded-md uppercase">
            Exclusivo Admin
          </span>
        </div>
      </Card>

      {/* Onboarding checklist */}
      <Card className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <CheckCircle2 size={18} className="text-accent-green" />
          <h2 className="font-bold">Checklist de onboarding</h2>
        </div>
        <p className="text-xs text-text-muted mb-5">Marque cada etapa conforme você completa</p>

        <div className="space-y-1">
          {steps.map((step, i) => (
            <button
              key={step.key}
              onClick={() => toggleStep(step.key)}
              className={cn(
                'w-full flex items-start gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200',
                'hover:bg-bg-surface-hover',
                step.done && 'opacity-60'
              )}
            >
              <div className="mt-0.5">
                {step.done ? (
                  <CheckCircle2 size={18} className="text-accent-green" />
                ) : (
                  <Circle size={18} className="text-text-muted" />
                )}
              </div>
              <div className="flex-1">
                <p className={cn('text-sm font-semibold', step.done && 'line-through text-text-muted')}>
                  {step.title}
                </p>
                <p className="text-xs text-text-muted leading-relaxed mt-0.5">{step.desc}</p>
              </div>
              <span className="text-[10px] text-text-muted mt-1 shrink-0">0{i + 1}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* PWA Notifications */}
      <Card className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Smartphone size={18} className="text-accent-yellow" />
          <h2 className="font-bold">Como ativar notificações no celular</h2>
        </div>
        <p className="text-xs text-text-muted mb-5">Receba alertas em tempo real sobre sua operação</p>

        <p className="text-sm text-text-secondary mb-4 leading-relaxed">
          Para receber notificações no celular: Instale o MetaControll como app na tela inicial do seu aparelho. Depois, ao abrir o app, permita as notificações quando o sistema solicitar.
        </p>

        <div className="space-y-2">
          {notificationSteps.map((text, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-cta/10 border border-cta/20">
              <span className="w-6 h-6 rounded-md bg-cta flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                0{i + 1}
              </span>
              <span className="text-sm text-text-secondary">{text}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 px-4 py-3 rounded-xl bg-accent-green/10 border border-accent-green/20">
          <div className="flex items-center gap-2 text-sm text-accent-green">
            <CheckCircle2 size={14} />
            As notificações ajudam você a acompanhar atualizações importantes da operação em tempo real.
          </div>
        </div>
      </Card>

      {/* Quick links */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {[
          { icon: LayoutDashboard, label: 'Painel admin', color: 'bg-cta/15 text-cta', href: '/admin' },
          { icon: Zap, label: 'Minha operação', color: 'bg-accent-green/15 text-accent-green', href: '/admin' },
          { icon: CreditCard, label: 'Assinatura', color: 'bg-accent-blue/15 text-accent-blue', href: '/assinatura' },
        ].map(({ icon: Icon, label, color, href }) => (
          <a
            key={label}
            href={href}
            className="flex items-center justify-between px-4 py-3 rounded-xl bg-bg-surface border border-border hover:border-border-light transition-all duration-200"
          >
            <div className="flex items-center gap-3">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', color)}>
                <Icon size={16} />
              </div>
              <span className="text-sm font-semibold">{label}</span>
            </div>
            <ChevronRight size={16} className="text-text-muted" />
          </a>
        ))}
      </div>
    </DashboardLayout>
  )
}
