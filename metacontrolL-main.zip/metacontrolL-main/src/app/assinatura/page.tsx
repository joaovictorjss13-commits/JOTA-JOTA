'use client'

import { useState, useEffect, useRef } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Card } from '@/components/ui/Card'
import { useUserProfile } from '@/hooks/useUserProfile'
import { supabase } from '@/lib/supabase'
import {
  CheckCircle2, Star, BarChart3, Bell, TrendingUp, Sparkles,
  Crown, X, Shield, Activity, ChevronRight, Lock,
  QrCode, Copy, Check, Loader2, AlertCircle, PartyPopper,
} from 'lucide-react'

type ModalStep = 'benefits' | 'qrcode' | 'success'

interface QrCodeData {
  chargeId: string
  qrCode: { imagem: string; copiaCola: string; expiracao: string }
}

// ─── Subscription benefits modal ──────────────────────────────────────────────
function SubscribeModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const panelRef = useRef<HTMLDivElement>(null)
  const [step, setStep] = useState<ModalStep>('benefits')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [qrData, setQrData] = useState<QrCodeData | null>(null)
  const [copied, setCopied] = useState(false)
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (isOpen && panelRef.current) {
      panelRef.current.scrollIntoView({ block: 'center', behavior: 'smooth' })
    }
    if (!isOpen) {
      stopPolling()
      setStep('benefits'); setError(''); setQrData(null); setCopied(false)
    }
  }, [isOpen])

  function stopPolling() {
    if (pollingRef.current) { clearInterval(pollingRef.current); pollingRef.current = null }
  }

  function startPolling(chargeId: string, token: string) {
    stopPolling()
    pollingRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/pagamentos/pix/${chargeId}/status`, {
          headers: { 'Authorization': `Bearer ${token}` },
        })
        if (!res.ok) return
        const json = await res.json()
        if (json.status === 'pago') {
          stopPolling()
          setStep('success')
          setTimeout(() => window.location.reload(), 1500)
        }
      } catch { /* silencia erros de rede durante polling */ }
    }, 4000)
  }

  async function getToken(): Promise<string> {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session?.access_token) throw new Error('Sessão expirada. Faça login novamente.')
    return session.access_token
  }

  // Um clique só — backend busca nome/email do perfil e gera CPF automaticamente
  async function handleGerarPix() {
    setError('')
    setLoading(true)
    try {
      const token = await getToken()
      const res = await fetch('/api/pagamentos/pix', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({}),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error ?? 'Erro ao gerar PIX')
      setQrData(json.data)
      setStep('qrcode')
      startPolling(json.data.chargeId, token)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function handleCopy() {
    if (!qrData) return
    navigator.clipboard.writeText(qrData.qrCode.copiaCola)
    setCopied(true)
    setTimeout(() => setCopied(false), 2500)
  }

  if (!isOpen) return null
  return (
    <div
      className="fixed inset-0 z-50 flex items-start md:items-center justify-center overflow-y-auto p-4 pt-8 pb-28 md:py-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div
        ref={panelRef}
        className="w-full max-w-lg rounded-2xl overflow-hidden my-auto"
        style={{
          background: 'rgba(10,10,24,0.98)',
          border: '1px solid rgba(124,58,237,0.35)',
          boxShadow: '0 0 60px rgba(124,58,237,0.25), 0 24px 48px rgba(0,0,0,0.6)',
        }}
      >
        {/* Header */}
        <div
          className="relative px-6 pt-6 pb-5"
          style={{
            background: 'linear-gradient(135deg, rgba(124,58,237,0.15) 0%, rgba(109,40,217,0.06) 100%)',
            borderBottom: '1px solid rgba(124,58,237,0.15)',
          }}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-white/5 transition-all"
          >
            <X size={16} />
          </button>
          <div className="flex items-center gap-3 mb-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: 'rgba(124,58,237,0.20)', border: '1px solid rgba(167,139,250,0.35)' }}
            >
              <Crown size={20} style={{ color: '#a78bfa' }} />
            </div>
            <div>
              <span
                className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full mb-1"
                style={{ background: 'rgba(124,58,237,0.20)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.35)' }}
              >
                <Sparkles size={9} /> OFERTA EXCLUSIVA
              </span>
              <h2 className="text-xl font-black">MetaControll PRO</h2>
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black" style={{ color: '#a78bfa' }}>R$ 29,90</span>
            <span className="text-sm text-text-muted">/mês</span>
            {/* urgência: escassez percebida */}
            <span
              className="ml-auto text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse"
              style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.30)' }}
            >
              🔥 ÚLTIMAS VAGAS
            </span>
          </div>
          <p className="text-xs text-text-muted mt-0.5">Pagamento único via PIX · Ativação imediata</p>
        </div>

        {/* ── STEP: benefits ── */}
        {step === 'benefits' && (
          <>
            <div className="px-6 py-4">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-wider mb-3">
                Tudo que você desbloqueia
              </p>
              <div className="space-y-2">
                {[
                  { icon: BarChart3, title: 'Dashboard completo', desc: 'Lucro, metas e remessas sem limites' },
                  { icon: Sparkles, title: 'Inteligência IA', desc: 'Previsões automáticas e insights estratégicos' },
                  { icon: Bell, title: 'Alertas estratégicos', desc: 'Notificações instantâneas de eventos financeiros' },
                  { icon: TrendingUp, title: 'Ranking de redes', desc: 'Veja qual rede gera mais lucro para você' },
                  { icon: Activity, title: 'Dados em tempo real', desc: 'Cada remessa aparece no instante em que acontece' },
                  { icon: Shield, title: 'Relatórios avançados', desc: 'Análises completas do seu faturamento' },
                ].map(({ icon: Icon, title, desc }) => (
                  <div key={title} className="flex items-start gap-3 py-1.5">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                      style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.25)' }}
                    >
                      <Icon size={13} style={{ color: '#10b981' }} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-text-primary leading-none mb-0.5">{title}</p>
                      <p className="text-[11px] text-text-muted">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="px-6 pb-6 pt-2">
              {error && (
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs mb-3"
                  style={{ background: 'rgba(239,68,68,0.10)', color: '#f87171', border: '1px solid rgba(239,68,68,0.25)' }}
                >
                  <AlertCircle size={13} /> {error}
                </div>
              )}
              <button
                onClick={handleGerarPix}
                disabled={loading}
                className="w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
                style={{
                  background: 'linear-gradient(135deg, #059669, #10b981, #34d399)',
                  boxShadow: '0 0 32px rgba(16,185,129,0.55), 0 4px 16px rgba(16,185,129,0.30)',
                  color: '#fff',
                  letterSpacing: '0.04em',
                }}
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <QrCode size={17} />}
                {loading ? 'GERANDO SEU PIX...' : 'GERAR PIX QRCODE'}
                {!loading && <ChevronRight size={16} />}
              </button>
              <p className="text-center text-[10px] text-text-muted mt-2">
                🔒 PIX seguro · Ativação imediata · Cancele quando quiser
              </p>
            </div>
          </>
        )}

        {/* ── STEP: QR code ── */}
        {step === 'qrcode' && qrData && (
          <div className="px-6 py-6 flex flex-col items-center gap-4">
            {/* prova social / urgência */}
            <div
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs"
              style={{ background: 'rgba(16,185,129,0.10)', color: '#34d399', border: '1px solid rgba(16,185,129,0.25)' }}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              PIX gerado com sucesso! Pague agora e ative em segundos.
            </div>

            {/* QR image */}
            <div
              className="rounded-2xl p-3"
              style={{ background: '#fff', boxShadow: '0 0 40px rgba(16,185,129,0.30)' }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`data:image/png;base64,${qrData.qrCode.imagem}`}
                alt="QR Code PIX"
                className="w-48 h-48 object-contain"
              />
            </div>

            <p className="text-xs text-text-muted text-center">
              Expira em: <span className="text-text-secondary font-semibold">
                {new Date(qrData.qrCode.expiracao).toLocaleString('pt-BR')}
              </span>
            </p>

            {/* copia-e-cola */}
            <div className="w-full">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-wider mb-1.5">PIX Copia e Cola</p>
              <div className="flex gap-2">
                <input
                  readOnly
                  value={qrData.qrCode.copiaCola}
                  className="flex-1 px-3 py-2 rounded-xl text-xs font-mono bg-white/5 border border-white/10 text-text-muted truncate"
                />
                <button
                  onClick={handleCopy}
                  className="px-4 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95 shrink-0"
                  style={{
                    background: copied ? 'rgba(16,185,129,0.20)' : 'linear-gradient(135deg, #059669, #10b981)',
                    color: copied ? '#34d399' : '#fff',
                    border: copied ? '1px solid rgba(16,185,129,0.40)' : 'none',
                    boxShadow: copied ? 'none' : '0 0 16px rgba(16,185,129,0.40)',
                  }}
                >
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                  {copied ? 'Copiado!' : 'Copiar'}
                </button>
              </div>
            </div>

            <p className="text-[10px] text-text-muted text-center">
              Após o pagamento, sua conta será ativada automaticamente · suporte@metacontroll.io
            </p>

            {/* indicador de polling */}
            <div className="flex items-center justify-center gap-2 text-[11px] text-text-muted">
              <Loader2 size={12} className="animate-spin" />
              Aguardando confirmação do pagamento...
            </div>
          </div>
        )}

        {/* ── STEP: success ── */}
        {step === 'success' && (
          <div className="px-6 py-10 flex flex-col items-center gap-4 text-center">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(16,185,129,0.15)', border: '2px solid rgba(16,185,129,0.40)', boxShadow: '0 0 40px rgba(16,185,129,0.35)' }}
            >
              <PartyPopper size={36} style={{ color: '#10b981' }} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-white mb-1">Pagamento confirmado!</h3>
              <p className="text-sm text-text-muted">Sua conta PRO foi ativada. Recarregando...</p>
            </div>
            <div
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold"
              style={{ background: 'rgba(16,185,129,0.12)', color: '#34d399', border: '1px solid rgba(16,185,129,0.25)' }}
            >
              <CheckCircle2 size={16} />
              MetaControll PRO ativo por 30 dias
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function AssinaturaPage() {
  const { profile } = useUserProfile()
  const [modalOpen, setModalOpen] = useState(false)

  const isPro = profile?.isPro ?? false
  const daysRemaining = profile?.daysRemaining ?? null
  const trialEndsAtFormatted = profile?.trialEndsAtFormatted ?? null
  const isTrialActive = profile?.isTrialActive ?? false

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="text-center mb-8 mt-8 md:mt-0">
        <span
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold mb-4"
          style={isPro ? {
            background: 'rgba(124,58,237,0.15)',
            color: '#a78bfa',
            border: '1px solid rgba(124,58,237,0.30)',
          } : {
            background: 'rgba(100,116,139,0.15)',
            color: '#94a3b8',
            border: '1px solid rgba(100,116,139,0.25)',
          }}
        >
          {isPro ? <Crown size={12} /> : <Star size={12} />}
          {isPro ? 'ASSINATURA ATIVA — PRO' : 'PLANO GRATUITO'}
        </span>
        <h1 className="text-2xl md:text-3xl font-black">Seu plano MetaControll</h1>
        <p className="text-sm text-text-muted mt-2 max-w-md mx-auto">
          {isPro
            ? 'Você tem acesso completo ao painel para gerenciar sua operação.'
            : 'Faça upgrade para PRO e tenha controle total da sua operação.'}
        </p>
      </div>

      {/* Plan comparison cards */}
      <div className="max-w-2xl mx-auto mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* FREE card */}
          <div
            className="relative rounded-2xl p-5"
            style={{
              background: 'rgba(255,255,255,0.02)',
              border: '1px solid rgba(255,255,255,0.07)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Star size={16} className="text-text-muted" />
              <h3 className="font-black text-lg">FREE</h3>
            </div>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-2xl font-black">Grátis</span>
            </div>
            <p className="text-xs text-text-muted mb-4">Para começar a explorar</p>
            <ul className="space-y-1.5 mb-5">
              {['Acesso limitado ao painel', 'Dados básicos de faturamento'].map(f => (
                <li key={f} className="flex items-center gap-2 text-xs">
                  <CheckCircle2 size={12} className="text-accent-green shrink-0" />
                  <span className="text-text-secondary">{f}</span>
                </li>
              ))}
              {['Até 3 operações ativas', 'Relatórios avançados', 'Inteligência IA', 'Alertas estratégicos', 'Dados em tempo real'].map(f => (
                <li key={f} className="flex items-center gap-2 text-xs opacity-40">
                  <Lock size={12} className="shrink-0 text-text-muted" />
                  <span className="text-text-muted line-through">{f}</span>
                </li>
              ))}
            </ul>
            <div
              className="w-full py-2.5 rounded-xl text-sm font-bold text-center text-text-muted"
              style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              {!isPro ? 'Plano atual' : 'Plano básico'}
            </div>
          </div>

          {/* PRO card */}
          <div
            className="relative rounded-2xl p-5 overflow-hidden"
            style={{
              background: 'rgba(124,58,237,0.08)',
              border: '1px solid rgba(124,58,237,0.35)',
              boxShadow: '0 0 30px rgba(124,58,237,0.12)',
            }}
          >
            <div
              className="absolute top-3 right-3 text-[9px] font-black px-2 py-0.5 rounded-full"
              style={{ background: 'rgba(124,58,237,0.20)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.40)' }}
            >
              RECOMENDADO
            </div>
            <div className="flex items-center gap-2 mb-2">
              <Crown size={16} style={{ color: '#a78bfa' }} />
              <h3 className="font-black text-lg">PRO</h3>
            </div>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-2xl font-black" style={{ color: '#a78bfa' }}>R$ 29,90</span>
              <span className="text-xs text-text-muted">/mês</span>
            </div>
            <p className="text-xs text-text-muted mb-4">Controle total da operação</p>
            <ul className="space-y-1.5 mb-5">
              {[
                'Acesso completo ao painel',
                'Operações ilimitadas',
                'Gestão de metas e remessas',
                'Faturamento e relatórios',
                'Notificações em tempo real',
                'Dados em tempo real',
                'Inteligência IA',
                'Alertas estratégicos',
              ].map(f => (
                <li key={f} className="flex items-center gap-2 text-xs">
                  <CheckCircle2 size={12} style={{ color: '#a78bfa' }} className="shrink-0" />
                  <span className="text-text-secondary">{f}</span>
                </li>
              ))}
            </ul>

            {isPro ? (
              <button
                disabled
                className="w-full py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 opacity-70 cursor-not-allowed"
                style={{ background: 'rgba(124,58,237,0.20)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.30)' }}
              >
                <CheckCircle2 size={14} />
                Plano atual
              </button>
            ) : (
              <button
                onClick={() => setModalOpen(true)}
                className="w-full py-3 rounded-xl text-sm font-black flex items-center justify-center gap-2 transition-all hover:brightness-110 active:scale-[0.97]"
                style={{
                  background: 'linear-gradient(135deg, #059669, #10b981, #34d399)',
                  color: '#fff',
                  boxShadow: '0 0 28px rgba(16,185,129,0.60), 0 4px 16px rgba(16,185,129,0.30)',
                  letterSpacing: '0.04em',
                }}
              >
                <QrCode size={15} />
                GERAR PIX QRCODE
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Subscription details — real-time */}
      <Card className="max-w-2xl mx-auto mb-6">
        <h3 className="font-bold mb-4">Detalhes da assinatura</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-bg-surface-light rounded-xl p-3 text-center border border-border">
            <p className="text-[10px] text-text-muted uppercase">Status</p>
            <p className={`text-sm font-bold ${isPro ? 'text-accent-green' : 'text-text-muted'}`}>
              {isPro ? 'Ativa' : 'Inativa'}
            </p>
          </div>
          <div className="bg-bg-surface-light rounded-xl p-3 text-center border border-border">
            <p className="text-[10px] text-text-muted uppercase">Pagamento</p>
            <p className="text-sm font-bold">{isPro ? 'R$ 29,90/mês' : '—'}</p>
          </div>
          <div className="bg-bg-surface-light rounded-xl p-3 text-center border border-border">
            <p className="text-[10px] text-text-muted uppercase">Renovação</p>
            <p className="text-sm font-bold">
              {isTrialActive && trialEndsAtFormatted ? trialEndsAtFormatted : isPro ? 'Mensal' : '—'}
            </p>
          </div>
        </div>

        {isTrialActive && daysRemaining !== null && (
          <div
            className="mt-3 px-3 py-2 rounded-xl flex items-center gap-2"
            style={{
              background: daysRemaining <= 1 ? 'rgba(239,68,68,0.08)' : 'rgba(124,58,237,0.08)',
              border: `1px solid ${daysRemaining <= 1 ? 'rgba(239,68,68,0.25)' : 'rgba(124,58,237,0.25)'}`,
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full shrink-0 animate-pulse-glow"
              style={{ background: daysRemaining <= 1 ? '#ef4444' : '#a78bfa' }}
            />
            <p className="text-xs" style={{ color: daysRemaining <= 1 ? '#f87171' : '#a78bfa' }}>
              {daysRemaining <= 0
                ? 'Trial expirado'
                : `Trial expira em ${daysRemaining} dia${daysRemaining === 1 ? '' : 's'}${trialEndsAtFormatted ? ` — ${trialEndsAtFormatted}` : ''}`}
            </p>
          </div>
        )}

        <p className="text-xs text-text-muted text-center mt-3">
          Precisa de ajuda? suporte@metacontroll.io
        </p>
      </Card>

      {/* Platform result */}
      <div className="max-w-2xl mx-auto mb-6 text-center">
        <p className="text-xs text-text-muted uppercase tracking-wider mb-2">Resultado real na plataforma</p>
        <p className="text-4xl md:text-5xl font-black text-accent-green mono-value">+R$ 3.058,47</p>
        <p className="text-xs text-text-muted mt-2">Lucro real rastreado. Cada centavo, cada meta fechada com custos descontados.</p>
      </div>

      {/* PRO features grid */}
      <div className="max-w-2xl mx-auto mb-6">
        <h2 className="text-2xl font-black text-center mb-2">Tudo que o PRO libera</h2>
        <p className="text-sm text-text-muted text-center mb-6">Recursos exclusivos que transformam dados em decisões</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { icon: BarChart3, title: 'Dashboard premium', desc: 'Lucro, metas e remessas em tempo real' },
            { icon: Sparkles, title: 'Inteligência IA', desc: 'Previsões e insights automáticos' },
            { icon: Bell, title: 'Alertas estratégicos', desc: 'Saiba quando e como agir' },
            { icon: TrendingUp, title: 'Ranking de redes', desc: 'Veja a rede que ganha mais lucro' },
          ].map(({ icon: Icon, title, desc }) => (
            <Card key={title}>
              <div className="w-8 h-8 rounded-lg bg-cta/15 flex items-center justify-center mb-3">
                <Icon size={16} className="text-cta" />
              </div>
              <h4 className="text-xs font-bold mb-1">{title}</h4>
              <p className="text-[10px] text-text-muted leading-relaxed">{desc}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Social proof */}
      <div className="max-w-2xl mx-auto text-center mb-8">
        <h2 className="text-xl font-black mb-4">Seu lucro chega assim</h2>
        <p className="text-sm text-text-muted mb-6">Cada remessa vira uma notificação no seu celular. Em tempo real.</p>
        <div className="space-y-3 max-w-sm mx-auto text-left">
          {[
            { title: 'Notificação instantânea', desc: 'Saiba na hora quando o dinheiro entra ou sai' },
            { title: 'Lucro atualizado ao vivo', desc: 'Tela atualiza a cada nova remessa registrada' },
            { title: 'Instale em 2 toques', desc: 'App nativo em iPhone e Android' },
          ].map(({ title, desc }) => (
            <div key={title} className="flex items-start gap-3">
              <CheckCircle2 size={16} className="text-accent-green mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-bold">{title}</p>
                <p className="text-xs text-text-muted">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        {!isPro && (
          <button
            onClick={() => setModalOpen(true)}
            className="mt-8 px-8 py-3.5 rounded-xl font-black text-sm inline-flex items-center gap-2 transition-all hover:opacity-90 active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #7c3aed, #a78bfa)',
              color: '#fff',
              boxShadow: '0 0 32px rgba(124,58,237,0.45)',
            }}
          >
            <QrCode size={16} />
            GERAR PIX QRCODE
          </button>
        )}
      </div>

      <SubscribeModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </DashboardLayout>
  )
}
