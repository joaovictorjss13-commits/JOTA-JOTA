'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/Button'
import { Eye, EyeOff, CheckCircle2, Info, Circle, ShieldAlert } from 'lucide-react'
import { signIn } from '@/lib/supabase-service'

// Requisitos de senha
const PWD_RULES = [
  { id: 'len',     label: 'Mínimo 8 caracteres',              test: (p: string) => p.length >= 8 },
  { id: 'upper',   label: 'Uma letra maiúscula (A-Z)',         test: (p: string) => /[A-Z]/.test(p) },
  { id: 'lower',   label: 'Uma letra minúscula (a-z)',         test: (p: string) => /[a-z]/.test(p) },
  { id: 'number',  label: 'Um número (0-9)',                   test: (p: string) => /[0-9]/.test(p) },
  { id: 'special', label: 'Um caractere especial (@$!%*?&#)', test: (p: string) => /[@$!%*?&#^()_\-+=]/.test(p) },
]

export default function RegisterPage() {
  const router = useRouter()
  const [nome, setNome]               = useState('')
  const [email, setEmail]             = useState('')
  const [password, setPassword]       = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading]         = useState(false)
  const [error, setError]             = useState('')
  const [ipLimited, setIpLimited]     = useState(false)
  const [submitted, setSubmitted]     = useState(false)
  const [showRules, setShowRules]     = useState(false)

  const pwdStatus = useMemo(
    () => PWD_RULES.map(r => ({ ...r, ok: r.test(password) })),
    [password]
  )
  const allPwdOk = pwdStatus.every(r => r.ok)

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!allPwdOk) {
      setShowRules(true)
      setError('A senha não atende todos os requisitos.')
      return
    }

    setLoading(true)
    setError('')
    setIpLimited(false)

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email, password }),
      })

      const json = await res.json()

      if (!res.ok) {
        if (res.status === 429) {
          setIpLimited(true)
        } else {
          setError(json.error || 'Erro ao criar conta')
        }
        return
      }

      // Conta criada (email_confirm: true no servidor) — faz login automático
      await signIn(email, password)
      router.push('/admin')
    } catch (err: any) {
      setError(err.message || 'Erro inesperado. Tente novamente')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center px-4 py-12">
      {/* Ambient gradient */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-accent-green/3 rounded-full blur-[120px]" />
      </div>

      <div className="relative w-full max-w-sm animate-slide-up">
        {/* Logo */}
        <div className="text-center mb-8">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="MetaControll" className="w-20 h-20 rounded-2xl object-contain mx-auto mb-4" />
          <h1 className="text-xl font-bold">
            Crie sua conta <span className="text-cta">Meta</span><span>Controll</span>
          </h1>
          <p className="text-sm text-text-muted mt-1">Acesso membro comum • Sem compromisso</p>
        </div>

        {/* Benefits */}
        <div className="mb-6 space-y-2">
          {['Painel completo de operações', 'Controle de metas e remessas', 'Faturamento em tempo real'].map((item) => (
            <div key={item} className="flex items-center gap-2 text-xs text-text-secondary">
              <CheckCircle2 size={14} className="text-accent-green shrink-0" />
              {item}
            </div>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={handleRegister} className="bg-bg-surface rounded-2xl border border-border p-6 space-y-4">
          {/* Info: conta criada */}
          {submitted && (
            <div className="flex items-start gap-3 p-4 rounded-xl bg-accent-blue/10 border border-accent-blue/30 text-accent-blue">
              <Info size={16} className="shrink-0 mt-0.5" />
              <p className="text-xs leading-relaxed">
                Conta criada! Redirecionando…
              </p>
            </div>
          )}

          {/* Limite de cadastro por IP */}
          {ipLimited && (
            <div className="flex items-start gap-3 p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/40 text-yellow-400">
              <ShieldAlert size={16} className="shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <p className="text-xs font-semibold">Limite de cadastro atingido</p>
                <p className="text-xs text-yellow-400/80">
                  Máximo de 2 contas por endereço de IP em 24 horas. Tente novamente mais tarde ou use outra rede.
                </p>
              </div>
            </div>
          )}

          {/* Erro genérico */}
          {error && !submitted && (
            <div className="p-3 rounded-lg bg-accent-red/10 border border-accent-red/30 text-xs text-accent-red">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              Nome completo
            </label>
            <input
              type="text"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Seu nome"
              required
              disabled={submitted}
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary placeholder:text-text-muted
                         focus:outline-none focus:border-accent-green/50 focus:ring-1 focus:ring-accent-green/20
                         transition-all duration-200
                         disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              E-mail
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              disabled={submitted}
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary placeholder:text-text-muted
                         focus:outline-none focus:border-accent-green/50 focus:ring-1 focus:ring-accent-green/20
                         transition-all duration-200
                         disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              Senha
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => { setPassword(e.target.value); setShowRules(true) }}
                onFocus={() => setShowRules(true)}
                placeholder="Crie uma senha forte"
                required
                minLength={8}
                disabled={submitted}
                className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                           text-text-primary placeholder:text-text-muted pr-10
                           focus:outline-none focus:border-accent-green/50 focus:ring-1 focus:ring-accent-green/20
                           transition-all duration-200
                           disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                disabled={submitted}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors disabled:opacity-50"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {/* Checklist de requisitos */}
            {showRules && (
              <div className="mt-2 p-3 rounded-xl bg-bg-surface-light border border-border space-y-1.5">
                {pwdStatus.map(r => (
                  <div key={r.id} className={`flex items-center gap-2 text-xs transition-colors ${r.ok ? 'text-accent-green' : 'text-text-muted'}`}>
                    {r.ok
                      ? <CheckCircle2 size={12} className="shrink-0" />
                      : <Circle size={12} className="shrink-0" />
                    }
                    {r.label}
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={loading || submitted || ipLimited || (showRules && !allPwdOk)}
          >
            {loading ? 'Criando conta…' : submitted ? 'Redirecionando…' : 'Criar conta comum'}
          </Button>

          <p className="text-center text-xs text-text-muted">
            Já tem conta?{' '}
            <Link href="/login" className="text-accent-green hover:underline font-semibold">
              Fazer login
            </Link>
          </p>
        </form>
      </div>
    </div>
  )
}
