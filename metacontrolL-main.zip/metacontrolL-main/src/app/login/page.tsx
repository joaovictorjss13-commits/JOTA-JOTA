'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/Button'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { signIn } from '@/lib/supabase-service'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      await signIn(email, password)
      setSuccess(true)
      setTimeout(() => router.push('/admin'), 650)
    } catch (err: unknown) {
      setError((err as Error).message || 'Erro ao fazer login')
      setLoading(false)
    }
  }

  return (
    <>
      {/* Overlay de sucesso — tela escura com logo em zoom */}
      {success && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 99998,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'rgba(7,7,15,0.96)',
            animation: 'fade-in 0.3s ease-out forwards',
          }}
        >
          <div style={{ animation: 'logo-zoom 0.55s cubic-bezier(0.16, 1, 0.3, 1) both' }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/logo.png"
              alt="MetaControll"
              style={{
                display: 'block',
                width: '96px',
                height: '96px',
                borderRadius: '24px',
                objectFit: 'contain',
                boxShadow: '0 0 50px rgba(124,58,237,0.7)',
              }}
            />
          </div>
        </div>
      )}

      <div className="min-h-screen bg-bg-primary flex items-center justify-center px-4">
        {/* Gradiente ambiente */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-cta/5 rounded-full blur-[120px]" />
        </div>

        <div
          className="relative w-full max-w-sm"
          style={{ animation: 'page-enter 0.5s cubic-bezier(0.16, 1, 0.3, 1) both' }}
        >
          {/* Logo */}
          <div className="text-center mb-8">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/logo.png"
              alt="MetaControll"
              className="w-20 h-20 rounded-2xl object-contain mx-auto mb-4"
              style={{
                boxShadow: '0 0 30px rgba(124,58,237,0.35)',
                animation: 'float 3s ease-in-out infinite',
              }}
            />
            <h1 className="text-xl font-bold">
              <span className="text-cta">Meta</span>
              <span className="text-text-primary">Controll</span>
            </h1>
            <p className="text-sm text-text-muted mt-1">Acesse sua central de operações</p>
          </div>

          {/* Formulário */}
          <form
            onSubmit={handleLogin}
            className="bg-bg-surface rounded-2xl border border-border p-6 space-y-4"
            style={{
              transition: 'opacity 0.2s ease, filter 0.2s ease',
              opacity: loading ? 0.6 : 1,
              filter: loading ? 'blur(0.5px)' : 'none',
              pointerEvents: loading || success ? 'none' : 'auto',
            }}
          >
            {error && (
              <div className="p-3 rounded-lg bg-accent-red/10 border border-accent-red/30 text-xs text-accent-red">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
                E-mail
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
                className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                           text-text-primary placeholder:text-text-muted
                           focus:outline-none focus:border-cta/50 focus:ring-1 focus:ring-cta/20
                           transition-all duration-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                             text-text-primary placeholder:text-text-muted pr-10
                             focus:outline-none focus:border-cta/50 focus:ring-1 focus:ring-cta/20
                             transition-all duration-200"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full" disabled={loading || success}>
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 size={16} className="animate-spin" />
                  Entrando...
                </span>
              ) : (
                'Entrar'
              )}
            </Button>

            <p className="text-center text-xs text-text-muted">
              Não tem conta?{' '}
              <Link href="/register" className="text-accent-green hover:underline font-semibold">
                Cadastre-se grátis
              </Link>
            </p>
          </form>
        </div>
      </div>
    </>
  )
}
