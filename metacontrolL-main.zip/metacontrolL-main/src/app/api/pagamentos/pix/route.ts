// POST /api/pagamentos/pix — cria cobrança PIX e retorna QR Code
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { findOrCreateCustomer, createPixCharge, getPixQrCode, gerarCpf } from '@/lib/asaas'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  const token = req.headers.get('Authorization')?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
  if (authError || !user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  // Busca nome e email do perfil do admin logado
  const { data: admin } = await supabaseAdmin
    .from('admins')
    .select('nome, email')
    .eq('id', user.id)
    .single()

  if (!admin) return NextResponse.json({ error: 'Perfil não encontrado' }, { status: 404 })

  try {
    const vencimento = new Date()
    vencimento.setDate(vencimento.getDate() + 3)
    const vencimentoStr = vencimento.toISOString().split('T')[0]

    // Gera CPF válido automaticamente para este cliente
    const cpfGerado = gerarCpf()

    const customer = await findOrCreateCustomer({
      name:     admin.nome,
      cpfCnpj:  cpfGerado,
      email:    admin.email,
    })

    const charge = await createPixCharge({
      customer:          customer.id,
      value:             29.90,
      dueDate:           vencimentoStr,
      description:       'Assinatura MetaControll PRO — 1 mês',
      externalReference: user.id,   // admin_id como referência para o webhook
    })

    const qrCode = await getPixQrCode(charge.id)

    // Persiste no banco — webhook usará asaas_charge_id para ativar o PRO
    await supabaseAdmin.from('pagamentos_pix').insert({
      admin_id:           user.id,
      pagador_nome:       admin.nome,
      pagador_cpf_cnpj:   cpfGerado,
      pagador_email:      admin.email,
      valor:              29.90,
      descricao:          'Assinatura MetaControll PRO — 1 mês',
      vencimento:         vencimentoStr,
      referencia_interna: 'pro-subscription',
      asaas_charge_id:    charge.id,
      asaas_customer_id:  customer.id,
      link_fatura:        charge.invoiceUrl,
      qrcode_imagem:      qrCode.encodedImage,
      qrcode_copia_cola:  qrCode.payload,
      qrcode_expiracao:   qrCode.expirationDate,
      status:             'pendente',
    })

    return NextResponse.json({
      data: {
        chargeId:  charge.id,
        valor:     charge.value,
        vencimento: charge.dueDate,
        qrCode: {
          imagem:    qrCode.encodedImage,
          copiaCola: qrCode.payload,
          expiracao: qrCode.expirationDate,
        },
        linkFatura: charge.invoiceUrl,
      },
    }, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Erro ao processar cobrança PIX' }, { status: 502 })
  }
}
