// GET /api/pagamentos/pix/[chargeId]/status — polling de status do pagamento
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(
  req: NextRequest,
  { params }: { params: { chargeId: string } }
) {
  const token = req.headers.get('Authorization')?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data: { user }, error } = await supabaseAdmin.auth.getUser(token)
  if (error || !user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data } = await supabaseAdmin
    .from('pagamentos_pix')
    .select('status, pago_em')
    .eq('asaas_charge_id', params.chargeId)
    .eq('admin_id', user.id)
    .single()

  if (!data) return NextResponse.json({ error: 'Não encontrado' }, { status: 404 })

  return NextResponse.json({ status: data.status, pago_em: data.pago_em })
}
