// src/app/api/auth/register/route.ts
// POST /api/auth/register — Cadastro de novo admin

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const EMAIL_RE   = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const PWD_UPPER  = /[A-Z]/
const PWD_LOWER  = /[a-z]/
const PWD_NUMBER = /[0-9]/
const PWD_SPECIAL = /[@$!%*?&#^()_\-+=]/

// ── Limite por IP: máx. 2 contas por IP em 24 h ──────────────
const IP_WINDOW_MS = 2400 * 60 * 60 * 1000
const IP_MAX       = 2
const ipRegistry   = new Map<string, { count: number; firstAt: number }>()

function checkIpLimit(ip: string): boolean {
  const now   = Date.now()
  const entry = ipRegistry.get(ip)
  if (!entry || now - entry.firstAt > IP_WINDOW_MS) {
    ipRegistry.set(ip, { count: 1, firstAt: now })
    return true
  }
  if (entry.count >= IP_MAX) return false
  entry.count++
  return true
}

function translateAuthError(msg: string): string {
  if (msg.includes('already registered') || msg.includes('already been registered'))
    return 'E-mail já cadastrado'
  if (msg.includes('invalid email'))
    return 'E-mail inválido'
  if (msg.includes('Password should be'))
    return 'Senha não atende aos requisitos mínimos'
  if (msg.includes('rate limit'))
    return 'Muitas tentativas. Aguarde alguns minutos e tente novamente'
  return 'Erro ao criar conta. Tente novamente'
}

export async function POST(req: NextRequest) {
  // Detecta IP do cliente
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0].trim()
           || req.headers.get('x-real-ip')
           || 'unknown'

  if (!checkIpLimit(ip)) {
    return NextResponse.json(
      { error: 'Limite de cadastros atingido para este endereço. Máximo de 2 contas por IP.' },
      { status: 429 }
    )
  }

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }

  const nome     = typeof body?.nome     === 'string' ? body.nome.slice(0, 100).trim()              : ''
  const email    = typeof body?.email    === 'string' ? body.email.slice(0, 254).trim().toLowerCase() : ''
  const password = typeof body?.password === 'string' ? body.password                                : ''

  if (!nome || !email || !password) {
    return NextResponse.json({ error: 'Preencha todos os campos obrigatórios' }, { status: 400 })
  }
  if (!EMAIL_RE.test(email)) {
    return NextResponse.json({ error: 'E-mail inválido' }, { status: 400 })
  }

  // Validação de força de senha
  if (password.length < 8)       return NextResponse.json({ error: 'A senha deve ter no mínimo 8 caracteres' }, { status: 400 })
  if (!PWD_UPPER.test(password))  return NextResponse.json({ error: 'A senha deve conter ao menos uma letra maiúscula' }, { status: 400 })
  if (!PWD_LOWER.test(password))  return NextResponse.json({ error: 'A senha deve conter ao menos uma letra minúscula' }, { status: 400 })
  if (!PWD_NUMBER.test(password)) return NextResponse.json({ error: 'A senha deve conter ao menos um número' }, { status: 400 })
  if (!PWD_SPECIAL.test(password)) return NextResponse.json({ error: 'A senha deve conter ao menos um caractere especial (@$!%*?&#)' }, { status: 400 })

  // 1. Cria o usuário no Auth do Supabase
  const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  })

  if (authError) {
    return NextResponse.json({ error: translateAuthError(authError.message) }, { status: 400 })
  }

  // 2. Cria ou atualiza o perfil admin.
  // O trigger on_auth_user_created pode ter inserido a linha antes desta chamada
  // (usando o prefixo do e-mail como nome). O upsert garante o nome correto do form.
  const { error: profileError } = await supabaseAdmin
    .from('admins')
    .upsert({ id: authData.user.id, nome, email }, { onConflict: 'id' })

  if (profileError) {
    // Rollback: remove usuário do Auth se o perfil falhar
    await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
    return NextResponse.json({ error: 'Erro ao criar perfil. Tente novamente' }, { status: 500 })
  }

  return NextResponse.json({ data: { id: authData.user.id, email } }, { status: 201 })
}
