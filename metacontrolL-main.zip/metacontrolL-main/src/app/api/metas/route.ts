// src/app/api/metas/route.ts
// GET  /api/metas        — listar metas do admin
// POST /api/metas        — criar nova meta

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'
import type { CriarMetaInput } from '@/types/database'

export async function GET(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const status    = searchParams.get('status')     // ativa | finalizada | fechada | lixeira
  const operador  = searchParams.get('operador_id')
  const periodo   = searchParams.get('periodo')    // hoje | 7d | 30d

  let query = supabase
    .from('metas')
    .select(`
      *,
      operador:operadores(id, nome),
      rede:redes(id, nome, sigla),
      remessas(count)
    `)
    .eq('admin_id', user.id)
    .order('created_at', { ascending: false })

  if (status)   query = query.eq('status', status)
  if (operador) query = query.eq('operador_id', operador)

  if (periodo === 'hoje') {
    query = query.gte('created_at', new Date().toISOString().split('T')[0])
  } else if (periodo === '7d') {
    const d = new Date(); d.setDate(d.getDate() - 7)
    query = query.gte('created_at', d.toISOString())
  } else if (periodo === '30d') {
    const d = new Date(); d.setDate(d.getDate() - 30)
    query = query.gte('created_at', d.toISOString())
  }

  const { data, error } = await query
  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data })
}

export async function POST(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  // Verifica assinatura ativa
  const { data: assin } = await supabase
    .from('assinaturas')
    .select('status, trial_ends_at')
    .eq('admin_id', user.id)
    .single()

  const isTrialValid = assin?.status === 'trial' &&
    assin?.trial_ends_at && new Date(assin.trial_ends_at) > new Date()

  if (!assin || (assin.status !== 'ativa' && !isTrialValid)) {
    return NextResponse.json({ error: 'Assinatura inativa' }, { status: 403 })
  }

  let body: CriarMetaInput
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }

  const { titulo, plataforma, rede_id, contas_total, modelo, operador_id } = body

  if (!titulo || !plataforma || !contas_total || !modelo) {
    return NextResponse.json({ error: 'Campos obrigatórios faltando' }, { status: 400 })
  }

  if (typeof titulo !== 'string' || titulo.length > 200) {
    return NextResponse.json({ error: 'Título inválido' }, { status: 400 })
  }
  if (typeof plataforma !== 'string' || plataforma.length > 100) {
    return NextResponse.json({ error: 'Plataforma inválida' }, { status: 400 })
  }
  const contasNum = Number(contas_total)
  if (!Number.isInteger(contasNum) || contasNum < 1 || contasNum > 100_000) {
    return NextResponse.json({ error: 'Número de contas inválido' }, { status: 400 })
  }
  if (!['salario_bau', 'apenas_bau'].includes(modelo)) {
    return NextResponse.json({ error: 'Modelo inválido' }, { status: 400 })
  }

  const { data, error } = await supabase
    .from('metas')
    .insert({
      admin_id:     user.id,
      titulo,
      plataforma,
      rede_id:      rede_id   || null,
      operador_id:  operador_id || null,
      contas_total,
      modelo,
      status:       'ativa',
    })
    .select(`*, rede:redes(id, nome, sigla)`)
    .single()

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data }, { status: 201 })
}
