// src/app/api/metas/[id]/route.ts
// GET   /api/metas/:id  — detalhe da meta com remessas
// PATCH /api/metas/:id  — atualizar status, fechar com custos
// DELETE /api/metas/:id — mover para lixeira

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'
import type { FecharMetaInput } from '@/types/database'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data, error } = await supabase
    .from('metas')
    .select(`
      *,
      operador:operadores(id, nome, email),
      rede:redes(id, nome, sigla),
      remessas(
        *,
        slot:slots(id, nome, provider, imagem_url)
      )
    `)
    .eq('id', params.id)
    .eq('admin_id', user.id)
    .order('created_at', { referencedTable: 'remessas', ascending: false })
    .single()

  if (error) return NextResponse.json({ error: 'Meta não encontrada' }, { status: 404 })

  // Insight da operação (análise simples baseada em score e resultado)
  const insight = gerarInsight(data)

  return NextResponse.json({ data: { ...data, insight } })
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const body = await req.json()
  const { action, ...rest } = body

  // Garante que a meta pertence ao admin
  const { data: meta } = await supabase
    .from('metas')
    .select('id, status, admin_id, status_anterior')
    .eq('id', params.id)
    .eq('admin_id', user.id)
    .single()

  if (!meta) return NextResponse.json({ error: 'Meta não encontrada' }, { status: 404 })

  let update: Record<string, any> = {}

  switch (action) {
    // Operador finaliza a meta
    case 'finalizar':
      if (meta.status !== 'ativa')
        return NextResponse.json({ error: 'Apenas metas ativas podem ser finalizadas' }, { status: 400 })
      update = { status: 'finalizada' }
      break

    // Admin fecha com custos (trigger calcula lucro_final)
    case 'fechar':
      if (meta.status !== 'finalizada')
        return NextResponse.json({ error: 'Finalize a meta antes de fechar' }, { status: 400 })
      const { salario = 0, custo_fixo = 0, taxa_agente = 0 }: FecharMetaInput = rest
      update = { status: 'fechada', salario, custo_fixo, taxa_agente }
      break

    // Reativar meta fechada
    case 'reativar':
      update = { status: 'ativa', fechada_at: null, finalizada_at: null }
      break

    // Lixeira
    case 'lixeira':
      update = { status: 'lixeira' }
      break

    // Restaurar da lixeira (trigger recalcula agregados automaticamente)
    case 'restaurar':
      if (meta.status !== 'lixeira')
        return NextResponse.json({ error: 'Meta não está na lixeira' }, { status: 400 })
      update = { status: (meta as any).status_anterior ?? 'ativa' }
      break

    // Edição de campos básicos
    default:
      const { titulo, plataforma, rede_id, operador_id, contas_total, modelo } = rest
      update = { titulo, plataforma, rede_id, operador_id, contas_total, modelo }
      // Remove undefined
      Object.keys(update).forEach(k => update[k] === undefined && delete update[k])
  }

  const { data, error } = await supabase
    .from('metas')
    .update(update)
    .eq('id', params.id)
    .select('*')
    .single()

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data })
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  // Soft delete: move para lixeira (trigger salva status_anterior e lixeira_at)
  const { error } = await supabase
    .from('metas')
    .update({ status: 'lixeira' })
    .eq('id', params.id)
    .eq('admin_id', user.id)

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({
    data: {
      deleted: true,
      message: 'Meta movida para a lixeira. Será excluída permanentemente em 1 dia (plano trial).',
    },
  })
}

// ────────────────────────────────────────────────────────────
// Lógica de insight da operação
// ────────────────────────────────────────────────────────────
function gerarInsight(meta: any) {
  const { score, resultado_liquido, taxa_acerto, status } = meta

  let mensagem = ''
  let tipo: 'sucesso' | 'alerta' | 'perigo' | 'neutro' = 'neutro'

  if (resultado_liquido > 0 && score >= 60) {
    mensagem = 'Operação estável — continue no ritmo atual.'
    tipo = 'sucesso'
  } else if (resultado_liquido > 0 && score < 60) {
    mensagem = 'Lucro positivo, mas taxa de acerto baixa — revise a estratégia.'
    tipo = 'alerta'
  } else if (resultado_liquido < 0) {
    mensagem = 'Operação no prejuízo — considere pausar e revisar.'
    tipo = 'perigo'
  } else {
    mensagem = 'Operação neutra — aguardando mais remessas para análise.'
    tipo = 'neutro'
  }

  return { mensagem, tipo, score, taxa_acerto }
}
