// ============================================================
// src/app/api/faturamento/route.ts
// GET /api/faturamento — visão financeira consolidada
// ============================================================
import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'

export async function GET(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const de         = searchParams.get('de')
  const ate        = searchParams.get('ate')
  const operadorId = searchParams.get('operador_id')
  const redeId     = searchParams.get('rede_id')

  // Metas com filtros
  let q = supabase
    .from('metas')
    .select('*, operador:operadores(nome), rede:redes(sigla)')
    .eq('admin_id', user.id)
    .neq('status', 'lixeira')

  if (de)         q = q.gte('created_at', de)
  if (ate)        q = q.lte('created_at', ate)
  if (operadorId) q = q.eq('operador_id', operadorId)
  if (redeId)     q = q.eq('rede_id', redeId)

  const [{ data: metas }, { data: custoResumo }, { data: admin }] = await Promise.all([
    q.order('created_at', { ascending: false }),
    supabase.from('vw_custos_resumo').select('*').eq('admin_id', user.id).single(),
    supabase.from('admins').select('meta_global').eq('id', user.id).single(),
  ])

  const lucro_bruto  = (metas || []).reduce((a, m) => a + (m.lucro_bruto || 0), 0)
  const deposito     = (metas || []).reduce((a, m) => a + (m.deposito_total || 0), 0)
  const saque        = (metas || []).reduce((a, m) => a + (m.saque_total || 0), 0)
  const total_rem    = (metas || []).reduce((a, m) => a + (m.contas_atingidas || 0), 0)
  const fechadas     = (metas || []).filter(m => m.status === 'fechada')
  const taxa_acerto  = fechadas.length > 0
    ? fechadas.reduce((a, m) => a + (m.taxa_acerto || 0), 0) / fechadas.length
    : 0

  // Evolução mensal (últimos 12 meses)
  const { data: evolucao } = await supabase.rpc('evolucao_mensal', { p_admin_id: user.id })

  // Inteligência da operação
  const tendencia = calcularTendencia(fechadas)
  const alertas   = gerarAlertas({ lucro_bruto, custoResumo, meta_global: admin?.meta_global || 0, taxa_acerto })

  return NextResponse.json({
    data: {
      lucro_final:   lucro_bruto,
      lucro_bruto,
      deposito_total: deposito,
      saque_total:    saque,
      total_remessas: total_rem,
      taxa_acerto:    Math.round(taxa_acerto),
      metas,
      custos:         custoResumo,
      meta_global:    admin?.meta_global || 0,
      inteligencia:   { tendencia, alertas },
      evolucao:       evolucao || [],
    }
  })
}

function calcularTendencia(fechadas: any[]) {
  if (fechadas.length < 2) return 'estável'
  const ultima  = fechadas[0]?.resultado_liquido || 0
  const penult  = fechadas[1]?.resultado_liquido || 0
  if (ultima > penult * 1.1)  return 'subindo'
  if (ultima < penult * 0.9)  return 'caindo'
  return 'estável'
}

function gerarAlertas({ lucro_bruto, custoResumo, meta_global, taxa_acerto }: any) {
  const alertas = []
  if (custoResumo?.custo_mes > lucro_bruto * 0.5) {
    alertas.push({ tipo: 'perigo', msg: 'Custos acima de 50% do lucro bruto' })
  }
  if (meta_global > 0 && lucro_bruto / meta_global < 0.1) {
    alertas.push({ tipo: 'aviso', msg: 'Menos de 10% da meta global atingida — acelere' })
  }
  if (taxa_acerto < 40) {
    alertas.push({ tipo: 'aviso', msg: 'Taxa de acerto abaixo de 40% — revise estratégia' })
  }
  return alertas
}


// ============================================================
// src/app/api/custos/route.ts
// GET  /api/custos — listar custos
// POST /api/custos — adicionar custo
// ============================================================
export async function getCustos(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data, error } = await supabase
    .from('custos')
    .select('*')
    .eq('admin_id', user.id)
    .order('data', { ascending: false })

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  // Resumo
  const hoje = new Date().toISOString().split('T')[0]
  const mes  = hoje.substring(0, 7)

  const custo_hoje = (data || []).filter(c => c.data === hoje).reduce((a, c) => a + c.valor, 0)
  const custo_mes  = (data || []).filter(c => c.data.startsWith(mes)).reduce((a, c) => a + c.valor, 0)

  return NextResponse.json({ data, resumo: { custo_hoje, custo_mes } })
}

export async function addCusto(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const TIPOS_CUSTO = ['proxy', 'sms', 'assinaturas', 'bot', 'vps', 'outros'] as const
  const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/

  const body = await req.json()
  const { tipo, valor, data: date, nota } = body

  if (!tipo || !TIPOS_CUSTO.includes(tipo)) {
    return NextResponse.json({ error: 'Tipo inválido' }, { status: 400 })
  }

  const valorNum = Number(valor)
  if (!isFinite(valorNum) || valorNum <= 0 || valorNum > 1_000_000) {
    return NextResponse.json({ error: 'Valor inválido' }, { status: 400 })
  }

  const dataFinal = date || new Date().toISOString().split('T')[0]
  if (!ISO_DATE.test(dataFinal)) {
    return NextResponse.json({ error: 'Data inválida' }, { status: 400 })
  }

  const notaFinal = nota ? String(nota).slice(0, 500) : null

  const { data, error } = await supabase
    .from('custos')
    .insert({
      admin_id: user.id,
      tipo,
      valor: valorNum,
      data: dataFinal,
      nota: notaFinal,
    })
    .select()
    .single()

  if (error) return NextResponse.json({ error: 'Erro ao registrar custo' }, { status: 500 })

  return NextResponse.json({ data }, { status: 201 })
}


// ============================================================
// src/app/api/operadores/route.ts
// POST /api/operadores — convidar operador (gera token)
// GET  /api/operadores — listar operadores do admin
// ============================================================
export async function getOperadores(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data, error } = await supabase
    .from('operadores')
    .select('*')
    .eq('admin_id', user.id)
    .order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data })
}

export async function convidarOperador(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  // Verifica se o plano permite operadores
  const { data: assin } = await supabase
    .from('assinaturas')
    .select('plano, status')
    .eq('admin_id', user.id)
    .single()

  if (assin?.plano === 'solo') {
    return NextResponse.json({ error: 'Plano Solo não permite operadores. Faça upgrade para PRO.' }, { status: 403 })
  }

  const body = await req.json()
  const nome = typeof body?.nome === 'string' ? body.nome.slice(0, 100).trim() : ''
  const email = typeof body?.email === 'string' ? body.email.slice(0, 254).trim().toLowerCase() : ''

  if (!nome || !email || !email.includes('@')) {
    return NextResponse.json({ error: 'Nome e e-mail válidos são obrigatórios' }, { status: 400 })
  }

  const conviteExpiraEm = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()

  const { data, error } = await supabase
    .from('operadores')
    .insert({ admin_id: user.id, nome, email, status: 'pendente', convite_expira_em: conviteExpiraEm })
    .select()
    .single()

  if (error) return NextResponse.json({ error: 'Erro ao criar convite' }, { status: 500 })

  const conviteLink = `${process.env.NEXT_PUBLIC_APP_URL}/convite/${data.convite_token}`

  // Marcar onboarding
  await supabase
    .from('onboarding')
    .update({ convidou_operador: true })
    .eq('admin_id', user.id)

  return NextResponse.json({ data, convite_link: conviteLink }, { status: 201 })
}


// ============================================================
// src/app/api/assinatura/route.ts
// GET   /api/assinatura        — dados da assinatura
// PATCH /api/assinatura/operadores — ajustar qtd operadores
// ============================================================
export async function getAssinatura(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data, error } = await supabase
    .from('assinaturas')
    .select('*')
    .eq('admin_id', user.id)
    .single()

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data })
}

export async function ajustarOperadores(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const body = await req.json()
  const qtd_operadores = Number(body?.qtd_operadores)

  if (!Number.isInteger(qtd_operadores) || qtd_operadores < 0 || qtd_operadores > 50) {
    return NextResponse.json({ error: 'Quantidade inválida' }, { status: 400 })
  }

  // Verifica que o admin tem plano PRO ativo — o plano NÃO é alterado aqui
  const { data: assin } = await supabase
    .from('assinaturas')
    .select('plano, status')
    .eq('admin_id', user.id)
    .single()

  if (!assin || assin.plano !== 'pro' || assin.status !== 'ativa') {
    return NextResponse.json({ error: 'Apenas o plano PRO ativo pode ajustar operadores' }, { status: 403 })
  }

  const { data, error } = await supabase
    .from('assinaturas')
    .update({ qtd_operadores })
    .eq('admin_id', user.id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: 'Erro ao atualizar quantidade de operadores' }, { status: 500 })

  return NextResponse.json({ data })
}
