// src/app/api/operadores/convite/[token]/route.ts
// GET /api/operadores/convite/:token — aceitar convite de operador

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export async function POST(req: NextRequest, { params }: { params: { token: string } }) {
  let body: any
  try { body = await req.json() } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }

  const { nome, email, password } = body

  if (!nome || typeof nome !== 'string' || nome.trim().length === 0) {
    return NextResponse.json({ error: 'Nome é obrigatório' }, { status: 400 })
  }
  if (!email || !EMAIL_RE.test(email)) {
    return NextResponse.json({ error: 'E-mail inválido' }, { status: 400 })
  }
  if (!password || typeof password !== 'string' || password.length < 8) {
    return NextResponse.json({ error: 'Senha deve ter no mínimo 8 caracteres' }, { status: 400 })
  }

  // 1. Valida o token
  const { data: operador } = await supabaseAdmin
    .from('operadores')
    .select('id, admin_id, convite_usado, convite_expira_em')
    .eq('convite_token', params.token)
    .single()

  if (!operador) return NextResponse.json({ error: 'Convite inválido' }, { status: 400 })
  if (operador.convite_usado) return NextResponse.json({ error: 'Convite já utilizado' }, { status: 400 })
  if (operador.convite_expira_em && new Date(operador.convite_expira_em) < new Date()) {
    return NextResponse.json({ error: 'Convite expirado' }, { status: 400 })
  }

  // 2. Cria conta no Auth
  const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  })
  if (authError) return NextResponse.json({ error: 'Erro ao criar conta de operador' }, { status: 400 })

  // 3. Vincula operador ao novo user
  const { error } = await supabaseAdmin
    .from('operadores')
    .update({
      user_id:       authData.user.id,
      nome,
      email,
      status:        'ativo',
      convite_usado: true,
    })
    .eq('id', operador.id)

  if (error) {
    // Rollback: remove auth user para não ficar órfão
    await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
    return NextResponse.json({ error: 'Erro ao ativar operador' }, { status: 500 })
  }

  return NextResponse.json({ data: { operador_id: operador.id, admin_id: operador.admin_id } })
}
