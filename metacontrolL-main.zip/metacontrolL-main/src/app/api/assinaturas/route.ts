// src/app/api/assinaturas/route.ts
// GET   /api/assinaturas — dados da assinatura do admin autenticado
// PATCH /api/assinaturas — altera data de vencimento (somente plano PRO)

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'

export async function GET(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data, error } = await supabase
    .from('assinaturas')
    .select('*')
    .eq('admin_id', user.id)
    .single()

  if (error) return NextResponse.json({ error: 'Assinatura não encontrada' }, { status: 404 })

  return NextResponse.json({ data })
}

export async function PATCH(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { vencimento } = await req.json()

  if (!vencimento) {
    return NextResponse.json({ error: 'Campo vencimento é obrigatório' }, { status: 400 })
  }

  // Valida formato de data (YYYY-MM-DD)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(vencimento)) {
    return NextResponse.json({ error: 'Formato inválido. Use YYYY-MM-DD' }, { status: 400 })
  }

  const { error } = await supabase.rpc('atualizar_vencimento', {
    p_vencimento: vencimento,
  })

  if (error) {
    const isPlanError = error.message.includes('plano PRO')
    return NextResponse.json(
      { error: isPlanError ? 'Apenas o plano PRO pode alterar a data de vencimento' : error.message },
      { status: isPlanError ? 403 : 500 }
    )
  }

  return NextResponse.json({ data: { vencimento, updated: true } })
}
