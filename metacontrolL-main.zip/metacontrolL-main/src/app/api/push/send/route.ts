import { NextRequest, NextResponse } from 'next/server'
import webpush from 'web-push'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

webpush.setVapidDetails(
  process.env.VAPID_SUBJECT!,
  process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!,
  process.env.VAPID_PRIVATE_KEY!,
)

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '')
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
    if (authError || !user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { title, body, tag } = await req.json() as {
      title: string
      body: string
      tag?: string
    }

    type Sub = { id: string; endpoint: string; p256dh: string; auth_key: string }

    const { data: subsRaw } = await supabaseAdmin
      .from('push_subscriptions')
      .select('id, endpoint, p256dh, auth_key')
      .eq('admin_id', user.id)

    const subs = subsRaw as Sub[] | null

    if (!subs?.length) return NextResponse.json({ ok: true, sent: 0 })

    const payload = JSON.stringify({
      title,
      body,
      icon: '/logo.png',
      badge: '/logo.png',
      tag: tag ?? 'notify',
      url: '/admin',
    })

    const staleIds: string[] = []

    await Promise.allSettled(
      subs.map(async (sub) => {
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth_key } },
            payload,
          )
        } catch (err: any) {
          // 404 / 410 = subscription expired or unsubscribed
          if (err.statusCode === 404 || err.statusCode === 410) {
            staleIds.push(sub.id)
          }
        }
      })
    )

    // Cleanup expired subscriptions
    if (staleIds.length) {
      await supabaseAdmin
        .from('push_subscriptions')
        .delete()
        .in('id', staleIds)
    }

    return NextResponse.json({ ok: true, sent: subs.length - staleIds.length })
  } catch {
    return NextResponse.json({ error: 'Erro ao enviar notificação' }, { status: 500 })
  }
}
