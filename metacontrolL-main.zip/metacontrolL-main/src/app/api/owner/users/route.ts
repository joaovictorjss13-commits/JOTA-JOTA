import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const OWNER_EMAIL = process.env.OWNER_EMAIL

// POST /api/owner/users — Criar usuário manualmente pelo painel owner
export async function POST(req: NextRequest) {
  const authHeader = req.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Token não fornecido' }, { status: 401 })

  const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
  if (authError || !user || user.email !== OWNER_EMAIL) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  let body: { nome: string; email: string; senha: string; plano?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }

  const { nome, email, senha, plano = 'solo' } = body
  if (!nome?.trim() || !email?.trim() || !senha) {
    return NextResponse.json({ error: 'Nome, email e senha são obrigatórios' }, { status: 400 })
  }

  // 1. Cria no Auth
  const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
    email: email.trim().toLowerCase(),
    password: senha,
    email_confirm: true,
    user_metadata: { nome: nome.trim() },
  })

  if (createErr) {
    const msg = createErr.message?.includes('already')
      ? 'Email já cadastrado'
      : createErr.message
    return NextResponse.json({ error: msg }, { status: 400 })
  }

  const newUserId = created.user.id

  // 2. Cria na tabela admins
  await supabaseAdmin.from('admins').upsert({
    id: newUserId,
    nome: nome.trim(),
    email: email.trim().toLowerCase(),
    plano,
  }, { onConflict: 'id' })

  // 3. Cria assinatura padrão
  const vencimento = new Date()
  if (plano === 'pro' || plano === 'infinit') {
    vencimento.setDate(vencimento.getDate() + (plano === 'infinit' ? 900 : 30))
  } else if (plano === 'trial') {
    vencimento.setDate(vencimento.getDate() + 3)
  }

  await supabaseAdmin.from('assinaturas').upsert({
    admin_id: newUserId,
    plano: plano === 'infinit' ? 'pro' : plano,
    status: plano === 'solo' ? 'cancelada' : plano === 'trial' ? 'trial' : 'ativa',
    vencimento: vencimento.toISOString().split('T')[0],
  }, { onConflict: 'admin_id' })

  // 4. Log no histórico
  try {
    await supabaseAdmin.from('historico_owner').insert({
      admin_id: newUserId,
      acao: 'usuario_criado',
      detalhes: { nome: nome.trim(), email: email.trim().toLowerCase(), plano, criado_por: 'owner_panel' },
    })
  } catch { /* tabela pode não existir ainda */ }

  // 5. Retorna o usuário completo
  const { data: fullUser } = await supabaseAdmin
    .from('admins')
    .select(`id, nome, email, plano, created_at, updated_at, assinaturas (id, status, trial_ends_at, vencimento, plano, qtd_operadores, valor_mensal, created_at, updated_at)`)
    .eq('id', newUserId)
    .single()

  return NextResponse.json({ data: fullUser }, { status: 201 })
}

// GET /api/owner/users — Listar todos os usuários
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Token não fornecido' }, { status: 401 })

  const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
  if (authError || !user || user.email !== OWNER_EMAIL) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { data, error } = await supabaseAdmin
    .from('admins')
    .select(`
      id, nome, email, plano, created_at, updated_at,
      assinaturas (
        id, status, trial_ends_at, vencimento, plano,
        qtd_operadores, valor_mensal, created_at, updated_at
      )
    `)
    .order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ data })
}
