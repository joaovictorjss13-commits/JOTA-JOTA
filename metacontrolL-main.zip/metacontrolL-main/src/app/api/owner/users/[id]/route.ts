import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const OWNER_EMAIL = process.env.OWNER_EMAIL

type Action =
  | { type: 'set_plan'; plan: 'solo' | 'trial' | 'pro' | 'infinit' }
  | { type: 'extend_days'; days: number }
  | { type: 'set_vencimento'; date: string }
  | { type: 'set_status'; status: 'ativa' | 'cancelada' | 'inadimplente' | 'trial' }
  | { type: 'update_nome'; nome: string }

async function logHistory(adminId: string, acao: string, detalhes: Record<string, unknown>) {
  try {
    await supabaseAdmin.from('historico_owner').insert({ admin_id: adminId, acao, detalhes })
  } catch { /* tabela pode não existir ainda */ }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const authHeader = req.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Token não fornecido' }, { status: 401 })

  const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
  if (authError || !user || user.email !== OWNER_EMAIL) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  let action: Action
  try {
    action = await req.json()
  } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }
  const adminId = params.id

  // Busca estado atual para o log
  const { data: currentAdmin } = await supabaseAdmin.from('admins').select('plano, nome').eq('id', adminId).single()
  const { data: currentAss } = await supabaseAdmin.from('assinaturas').select('status, vencimento').eq('admin_id', adminId).single()

  switch (action.type) {
    case 'set_plan': {
      const plan = action.plan
      const now = new Date()

      const planDefaults: Record<string, { status: string; days: number | null }> = {
        solo:   { status: 'cancelada', days: null },
        trial:  { status: 'trial',     days: 3   },
        pro:    { status: 'ativa',     days: 30  },
        infinit:{ status: 'ativa',     days: 900 },
      }

      const defaults = planDefaults[plan]

      await supabaseAdmin.from('admins').update({ plano: plan, updated_at: now.toISOString() }).eq('id', adminId)

      const assinaturaUpdate: Record<string, unknown> = { status: defaults.status, updated_at: now.toISOString() }
      if (defaults.days !== null) {
        const end = new Date(now)
        end.setDate(end.getDate() + defaults.days)
        const dateStr = end.toISOString().split('T')[0]
        if (plan === 'trial') assinaturaUpdate.trial_ends_at = end.toISOString()
        else assinaturaUpdate.vencimento = dateStr
      }

      await supabaseAdmin.from('assinaturas').update(assinaturaUpdate).eq('admin_id', adminId)
      await logHistory(adminId, 'plano_alterado', { de: currentAdmin?.plano, para: plan })
      break
    }

    case 'extend_days': {
      const { data: ass } = await supabaseAdmin
        .from('assinaturas')
        .select('vencimento, status')
        .eq('admin_id', adminId)
        .single()

      const base = ass?.vencimento && new Date(ass.vencimento) > new Date()
        ? new Date(ass.vencimento)
        : new Date()
      base.setDate(base.getDate() + action.days)
      const dateStr = base.toISOString().split('T')[0]

      await supabaseAdmin.from('assinaturas')
        .update({ vencimento: dateStr, status: 'ativa', updated_at: new Date().toISOString() })
        .eq('admin_id', adminId)

      const { data: adm } = await supabaseAdmin.from('admins').select('plano').eq('id', adminId).single()
      if (adm?.plano === 'solo' || adm?.plano === 'trial') {
        await supabaseAdmin.from('admins').update({ plano: 'pro', updated_at: new Date().toISOString() }).eq('id', adminId)
      }
      await logHistory(adminId, 'tempo_adicionado', { dias: action.days, novo_vencimento: dateStr, vencimento_anterior: currentAss?.vencimento })
      break
    }

    case 'set_vencimento': {
      await supabaseAdmin.from('assinaturas')
        .update({ vencimento: action.date, status: 'ativa', updated_at: new Date().toISOString() })
        .eq('admin_id', adminId)
      await supabaseAdmin.from('admins')
        .update({ plano: 'pro', updated_at: new Date().toISOString() })
        .eq('id', adminId)
      await logHistory(adminId, 'vencimento_definido', { data: action.date, anterior: currentAss?.vencimento })
      break
    }

    case 'set_status': {
      await supabaseAdmin.from('assinaturas')
        .update({ status: action.status, updated_at: new Date().toISOString() })
        .eq('admin_id', adminId)
      if (action.status === 'cancelada' || action.status === 'inadimplente') {
        await supabaseAdmin.from('admins').update({ plano: 'solo', updated_at: new Date().toISOString() }).eq('id', adminId)
      }
      await logHistory(adminId, 'status_alterado', { de: currentAss?.status, para: action.status })
      break
    }

    case 'update_nome': {
      if (!action.nome || action.nome.trim().length < 2) {
        return NextResponse.json({ error: 'Nome inválido' }, { status: 400 })
      }
      await supabaseAdmin.from('admins')
        .update({ nome: action.nome.trim(), updated_at: new Date().toISOString() })
        .eq('id', adminId)
      await logHistory(adminId, 'nome_alterado', { de: currentAdmin?.nome, para: action.nome.trim() })
      break
    }

    default:
      return NextResponse.json({ error: 'Ação inválida' }, { status: 400 })
  }

  const { data } = await supabaseAdmin
    .from('admins')
    .select(`id, nome, email, plano, created_at, updated_at, assinaturas (id, status, trial_ends_at, vencimento, plano, qtd_operadores, valor_mensal, created_at, updated_at)`)
    .eq('id', adminId)
    .single()

  return NextResponse.json({ data })
}

// GET /api/owner/users/[id] — Buscar histórico de alterações
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const authHeader = req.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Token não fornecido' }, { status: 401 })

  const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
  if (authError || !user || user.email !== OWNER_EMAIL) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { data, error } = await supabaseAdmin
    .from('historico_owner')
    .select('*')
    .eq('admin_id', params.id)
    .order('created_at', { ascending: false })
    .limit(50)

  if (error) return NextResponse.json({ data: [] })

  return NextResponse.json({ data: data || [] })
}
