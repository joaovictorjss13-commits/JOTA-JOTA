import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const OWNER_EMAIL = process.env.OWNER_EMAIL
const OWNER_PASSWORD = process.env.OWNER_BOOTSTRAP_PASSWORD

// Endpoint one-time: cria/reseta a conta owner no Supabase Auth.
// Só funciona se OWNER_EMAIL e OWNER_BOOTSTRAP_PASSWORD estiverem configurados.
export async function POST(req: NextRequest) {
  if (!OWNER_EMAIL || !OWNER_PASSWORD) {
    return NextResponse.json({ error: 'Env vars não configuradas', detail: { email: !!OWNER_EMAIL, password: !!OWNER_PASSWORD } }, { status: 403 })
  }

  const auth = req.headers.get('x-bootstrap-password')
  if (auth !== OWNER_PASSWORD) {
    return NextResponse.json({ error: 'Senha de bootstrap inválida' }, { status: 403 })
  }

  try {
    // ── 1. Tenta criar o usuário no Auth diretamente ──
    //    createUser via Admin API popula auth.users + auth.identities corretamente
    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: OWNER_EMAIL,
      password: OWNER_PASSWORD,
      email_confirm: true,
      user_metadata: { nome: 'Owner MetaControll' },
    })

    let userId: string

    if (createErr) {
      // Usuário já existe no Auth — precisa atualizar
      if (createErr.message?.includes('already') || createErr.status === 422) {
        // Busca o ID do usuário pela tabela admins
        const { data: adminRow } = await supabaseAdmin
          .from('admins')
          .select('id')
          .eq('email', OWNER_EMAIL)
          .maybeSingle()

        if (adminRow) {
          userId = adminRow.id
        } else {
          // Não está na tabela admins — precisa achar no Auth de outra forma
          // Usa getUserByEmail que não existe na API admin, então tentamos
          // deletar e recriar para garantir que auth.identities esteja correto
          return NextResponse.json({
            error: 'Usuário existe no Auth mas não na tabela admins.',
            fix: 'Execute no SQL Editor do Supabase: DELETE FROM auth.users WHERE email = \'' + OWNER_EMAIL + '\'; e depois chame este endpoint novamente.',
          }, { status: 409 })
        }

        // Atualiza a senha e confirma email
        const { error: updateErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
          password: OWNER_PASSWORD,
          email_confirm: true,
        })
        if (updateErr) {
          return NextResponse.json({ error: `Erro ao atualizar: ${updateErr.message}` }, { status: 500 })
        }
      } else {
        return NextResponse.json({ error: `Erro ao criar: ${createErr.message}` }, { status: 500 })
      }
    } else {
      userId = created.user.id
    }

    // ── 2. Garante registro na tabela admins ──
    const { error: upsertErr } = await supabaseAdmin.from('admins').upsert({
      id: userId,
      nome: 'Owner MetaControll',
      email: OWNER_EMAIL,
      plano: 'infinit',
    }, { onConflict: 'id' })

    if (upsertErr) {
      return NextResponse.json({ error: `Erro ao criar admin: ${upsertErr.message}` }, { status: 500 })
    }

    // ── 3. Garante assinatura ativa ──
    const vencimento = new Date()
    vencimento.setDate(vencimento.getDate() + 900)
    const { error: assErr } = await supabaseAdmin.from('assinaturas').upsert({
      admin_id: userId,
      plano: 'pro',
      status: 'ativa',
      vencimento: vencimento.toISOString().split('T')[0],
    }, { onConflict: 'admin_id' })

    if (assErr) {
      return NextResponse.json({ error: `Erro ao criar assinatura: ${assErr.message}` }, { status: 500 })
    }

    return NextResponse.json({
      ok: true,
      action: 'owner_configurado',
      email: OWNER_EMAIL,
      userId,
      msg: 'Agora faça login em /owner-controll-adminacess',
    })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err)
    return NextResponse.json({ error: `Erro inesperado: ${message}` }, { status: 500 })
  }
}
