import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin.server'

const OWNER_EMAIL = process.env.OWNER_EMAIL
const OWNER_PASSWORD = process.env.OWNER_BOOTSTRAP_PASSWORD

// Endpoint de diagnóstico temporário — DELETE após resolver o problema!
export async function GET(req: NextRequest) {
  const auth = req.headers.get('x-bootstrap-password')
  if (!OWNER_PASSWORD || auth !== OWNER_PASSWORD) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
  }

  const diagnostics: Record<string, unknown> = {
    timestamp: new Date().toISOString(),
    env: {
      OWNER_EMAIL_SET: !!OWNER_EMAIL,
      OWNER_EMAIL_VALUE: OWNER_EMAIL || null,
      OWNER_PASSWORD_SET: !!OWNER_PASSWORD,
      SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL?.slice(0, 30) + '...',
      SERVICE_ROLE_SET: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
    },
  }

  // 1. Testa query na tabela admins
  try {
    const { data, error } = await supabaseAdmin
      .from('admins')
      .select('id, email, plano')
      .eq('email', OWNER_EMAIL!)
      .maybeSingle()
    diagnostics.admins_table = error
      ? { error: error.message, code: error.code }
      : data
        ? { found: true, id: data.id, plano: data.plano }
        : { found: false, msg: 'Owner NÃO existe na tabela admins' }
  } catch (e: unknown) {
    diagnostics.admins_table = { error: e instanceof Error ? e.message : String(e) }
  }

  // 2. Testa query na tabela assinaturas (se admin existe)
  const adminId = (diagnostics.admins_table as any)?.id
  if (adminId) {
    try {
      const { data, error } = await supabaseAdmin
        .from('assinaturas')
        .select('status, plano, vencimento')
        .eq('admin_id', adminId)
        .maybeSingle()
      diagnostics.assinatura = error
        ? { error: error.message }
        : data || { found: false }
    } catch (e: unknown) {
      diagnostics.assinatura = { error: e instanceof Error ? e.message : String(e) }
    }
  }

  // 3. Testa login com signInWithPassword (o mesmo que o frontend usa)
  try {
    const { data: signInData, error: signInErr } = await supabaseAdmin.auth.signInWithPassword({
      email: OWNER_EMAIL!,
      password: OWNER_PASSWORD!,
    })
    diagnostics.login_test = signInErr
      ? { success: false, error: signInErr.message, status: signInErr.status }
      : { success: true, userId: signInData?.user?.id, email: signInData?.user?.email }
  } catch (e: unknown) {
    diagnostics.login_test = { error: e instanceof Error ? e.message : String(e) }
  }

  // 4. Verifica se auth.identities existe para este email via Admin API
  if (adminId) {
    try {
      const { data, error } = await supabaseAdmin.auth.admin.getUserById(adminId)
      diagnostics.auth_user = error
        ? { error: error.message }
        : {
            id: data?.user?.id,
            email: data?.user?.email,
            confirmed: !!data?.user?.email_confirmed_at,
            identities_count: data?.user?.identities?.length ?? 0,
            providers: data?.user?.identities?.map(i => i.provider) ?? [],
            created_at: data?.user?.created_at,
          }
    } catch (e: unknown) {
      diagnostics.auth_user = { error: e instanceof Error ? e.message : String(e) }
    }
  }

  return NextResponse.json({ diagnostics }, { status: 200 })
}
