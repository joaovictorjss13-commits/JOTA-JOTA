// src/app/api/dashboard/route.ts
// GET /api/dashboard — dados consolidados para o painel admin

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'

export async function GET(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const FILTROS_VALIDOS = ['tudo', 'hoje', 'ontem', '7d', '30d'] as const
  type Filtro = typeof FILTROS_VALIDOS[number]

  const { searchParams } = new URL(req.url)
  const filtroParam = searchParams.get('filtro') || 'tudo'
  const filtro: Filtro = (FILTROS_VALIDOS as readonly string[]).includes(filtroParam)
    ? filtroParam as Filtro
    : 'tudo'

  // Calcula range de datas baseado no filtro
  const now = new Date()
  const hoje = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  let rangeGte: string | null = null
  let rangeLt: string | null = null

  if (filtro === 'hoje') {
    rangeGte = hoje.toISOString()
  } else if (filtro === 'ontem') {
    const start = new Date(hoje); start.setDate(start.getDate() - 1)
    rangeGte = start.toISOString()
    rangeLt  = hoje.toISOString()
  } else if (filtro === '7d') {
    rangeGte = new Date(hoje.getTime() - 7 * 86400000).toISOString()
  } else if (filtro === '30d') {
    rangeGte = new Date(hoje.getTime() - 30 * 86400000).toISOString()
  }

  // Remessas do período (normal + bloqueado)
  let remessasQuery = supabase
    .from('remessas')
    .select('meta_id, deposito, saque, status, created_at')
    .in('status', ['normal', 'bloqueado'])

  // Filtramos remessas por período para cálculos corretos por data
  if (rangeGte) {
    // Usamos inner join via metas para garantir que são do admin correto
    remessasQuery = remessasQuery.gte('created_at', rangeGte)
  }
  if (rangeLt) remessasQuery = remessasQuery.lt('created_at', rangeLt)

  const [
    { data: metas },
    { data: remessasPeriodo },
    { data: remessasRecentes },
    { data: previsao },
    { data: onboarding },
    { data: analiseArr },
  ] = await Promise.all([
    supabase
      .from('metas')
      .select('id, status, deposito_total, bloqueado_total, saque_total, lucro_bruto, resultado_liquido, contas_atingidas, lucro_final, plataforma')
      .eq('admin_id', user.id)
      .neq('status', 'lixeira'),
    remessasQuery,
    supabase
      .from('remessas')
      .select(`resultado, created_at, operador:operadores(nome), meta:metas!inner(admin_id, plataforma)`)
      .eq('meta.admin_id', user.id)
      .eq('status', 'normal')
      .order('created_at', { ascending: false })
      .limit(5),
    supabase.from('vw_previsao').select('*').eq('admin_id', user.id).single(),
    supabase.from('onboarding').select('*').eq('admin_id', user.id).single(),
    supabase.rpc('analise_probabilistica', { p_admin_id: user.id }),
  ])

  const metaIds = new Set((metas || []).map(m => m.id))
  const remessas = (remessasPeriodo || []).filter(r => metaIds.has(r.meta_id))
  const normal    = remessas.filter(r => r.status === 'normal')
  const bloqueado = remessas.filter(r => r.status === 'bloqueado')

  // ── Totais financeiros ──────────────────────────────────────
  let deposito_normal: number
  let bloqueado_total: number
  let saque_total: number
  let lucro_bruto: number
  let resultado: number
  let taxa_acerto: number

  if (filtro === 'tudo') {
    deposito_normal = (metas || []).reduce((a, m) => a + Number(m.deposito_total  || 0), 0)
    bloqueado_total = (metas || []).reduce((a, m) => a + Number(m.bloqueado_total || 0), 0)
    saque_total     = (metas || []).reduce((a, m) => a + Number(m.saque_total     || 0), 0)
    lucro_bruto     = (metas || []).reduce((a, m) => a + Number(m.lucro_bruto     || 0), 0)
    resultado       = (metas || []).reduce((a, m) => a + Number(m.resultado_liquido || 0), 0)
    taxa_acerto     = (metas || []).length > 0
      ? Math.round((metas || []).filter(m => Number(m.resultado_liquido || 0) > 0).length / (metas || []).length * 100)
      : 0
  } else {
    deposito_normal = normal.reduce((a, r) => a + Number(r.deposito || 0), 0)
    bloqueado_total = bloqueado.reduce((a, r) => a + Number(r.deposito || 0), 0)
    saque_total     = normal.reduce((a, r) => a + Number(r.saque || 0), 0)
    lucro_bruto     = saque_total - deposito_normal
    resultado       = saque_total - deposito_normal - bloqueado_total
    taxa_acerto     = normal.length > 0
      ? Math.round(normal.filter(r => Number(r.saque || 0) > Number(r.deposito || 0)).length / normal.length * 100)
      : 0
  }

  const deposito_total = deposito_normal + bloqueado_total
  const metas_fechadas = (metas || []).filter(m => m.status === 'fechada').length
  const total_metas    = (metas || []).length
  const status_op      = resultado > 0 ? 'positivo' : resultado < 0 ? 'negativo' : 'neutro'

  return NextResponse.json({
    data: {
      lucro_acumulado:    resultado,
      deposito_total,
      deposito_normal,
      bloqueado_total,
      saque_total,
      lucro_bruto,
      taxa_acerto,
      total_metas,
      metas_fechadas,
      total_depositantes: (metas || []).reduce((a, m) => a + Number(m.contas_atingidas || 0), 0),
      status:             status_op,
      remessas_recentes:  remessasRecentes || [],
      previsao:           previsao || { lucro_medio_meta: 0, lucro_medio_conta: 0, metas_fechadas: 0 },
      onboarding:         onboarding || {},
      analise:            analiseArr?.[0] || null,
    }
  })
}
