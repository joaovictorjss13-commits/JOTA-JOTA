// POST /api/webhooks/asaas — recebe notificações de pagamento do Asaas
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const WEBHOOK_TOKEN = process.env.ASAAS_WEBHOOK_TOKEN

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  // Token OBRIGATÓRIO — sem token configurado, rejeita todas as chamadas
  if (!WEBHOOK_TOKEN) {
    console.error('[webhook/asaas] ASAAS_WEBHOOK_TOKEN não configurado — rejeitando requisição')
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const tokenHeader = req.headers.get('asaas-access-token')
  if (tokenHeader !== WEBHOOK_TOKEN) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let event: any
  try {
    event = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid payload' }, { status: 400 })
  }

  const { event: tipo, payment } = event

  if (!payment?.id) return NextResponse.json({ ok: true })

  switch (tipo) {
    case 'PAYMENT_RECEIVED':
    case 'PAYMENT_CONFIRMED': {
      // adminId vem EXCLUSIVAMENTE do nosso banco — nunca do payload externo
      const { data: pagamento } = await supabaseAdmin
        .from('pagamentos_pix')
        .select('id, admin_id, referencia_interna')
        .eq('asaas_charge_id', payment.id)
        .single()

      if (!pagamento) break

      await supabaseAdmin
        .from('pagamentos_pix')
        .update({ status: 'pago', pago_em: new Date().toISOString() })
        .eq('id', pagamento.id)

      if (pagamento.referencia_interna === 'pro-subscription') {
        try {
          await ativarPro(pagamento.admin_id)
        } catch (err) {
          console.error('[webhook/asaas] ativarPro falhou para admin', pagamento.admin_id, err)
        }
      }
      break
    }

    case 'PAYMENT_OVERDUE': {
      await supabaseAdmin
        .from('pagamentos_pix')
        .update({ status: 'vencido' })
        .eq('asaas_charge_id', payment.id)
      break
    }

    case 'PAYMENT_DELETED': {
      await supabaseAdmin
        .from('pagamentos_pix')
        .update({ status: 'cancelado' })
        .eq('asaas_charge_id', payment.id)
      break
    }
  }

  return NextResponse.json({ ok: true })
}

async function ativarPro(adminId: string) {
  const vencimento = new Date()
  vencimento.setDate(vencimento.getDate() + 30)
  const vencimentoStr = vencimento.toISOString().split('T')[0]

  const [adminResult, assinaturaResult] = await Promise.all([
    supabaseAdmin.from('admins').update({ plano: 'pro' }).eq('id', adminId),
    supabaseAdmin.from('assinaturas').update({ plano: 'pro', status: 'ativa', vencimento: vencimentoStr }).eq('admin_id', adminId),
  ])

  if (adminResult.error) throw new Error(`admins update: ${adminResult.error.message}`)
  if (assinaturaResult.error) throw new Error(`assinaturas update: ${assinaturaResult.error.message}`)
}
