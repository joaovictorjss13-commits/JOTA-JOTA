// src/app/api/remessas/route.ts
// POST /api/remessas — registrar nova remessa

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'
import type { RegistrarRemessaInput } from '@/types/database'

export async function POST(req: NextRequest) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  let body: RegistrarRemessaInput
  try { body = await req.json() } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }
  const { meta_id, titulo, tipo = 'remessa', saldo_ini = 0,
          contas, deposito, saque, status = 'normal', notas, slot_id } = body

  if (!meta_id || contas === undefined || deposito === undefined || saque === undefined) {
    return NextResponse.json({ error: 'meta_id, contas, deposito e saque são obrigatórios' }, { status: 400 })
  }

  // Verifica que a meta pertence ao admin e está ativa
  const { data: meta } = await supabase
    .from('metas')
    .select('id, status, admin_id, operador_id')
    .eq('id', meta_id)
    .single()

  if (!meta) return NextResponse.json({ error: 'Meta não encontrada' }, { status: 404 })

  const isAdmin    = meta.admin_id === user.id
  const isOperador = meta.operador_id && await isUserOperador(supabase, user.id, meta.operador_id as string)

  if (!isAdmin && !isOperador) {
    return NextResponse.json({ error: 'Sem permissão para esta meta' }, { status: 403 })
  }

  if (meta.status !== 'ativa') {
    return NextResponse.json({ error: 'Só é possível registrar remessas em metas ativas' }, { status: 400 })
  }

  // Obtém o operador_id do usuário logado (se for operador)
  let operador_id: string | null = null
  if (!isAdmin) {
    const { data: op } = await supabase
      .from('operadores')
      .select('id')
      .eq('user_id', user.id)
      .eq('admin_id', meta.admin_id)
      .single()
    operador_id = op?.id ?? null
  }

  const { data: remessa, error } = await supabase
    .from('remessas')
    .insert({
      meta_id,
      operador_id,
      slot_id:  slot_id || null,
      titulo:   titulo || null,
      tipo,
      saldo_ini,
      contas,
      deposito,
      saque,
      status,
      notas: notas || null,
    })
    .select(`*, slot:slots(id, nome, provider, imagem_url)`)
    .single()

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  // O trigger recalcular_meta() já atualizou os agregados da meta
  // Aqui só precisamos retornar a remessa criada

  return NextResponse.json({ data: remessa }, { status: 201 })
}

// ────────────────────────────────────────────────────────────
// Helper: verifica se user_id é operador de operador_id
// ────────────────────────────────────────────────────────────
async function isUserOperador(supabase: any, userId: string, operadorId: string): Promise<boolean> {
  const { data } = await supabase
    .from('operadores')
    .select('id')
    .eq('id', operadorId)
    .eq('user_id', userId)
    .single()
  return !!data
}
