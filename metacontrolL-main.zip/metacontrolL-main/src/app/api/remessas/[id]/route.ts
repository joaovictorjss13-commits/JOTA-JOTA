// src/app/api/remessas/[id]/route.ts
// PATCH  /api/remessas/:id — editar remessa ou restaurar da lixeira
// DELETE /api/remessas/:id — mover para lixeira (soft delete)

import { NextRequest, NextResponse } from 'next/server'
import { createRouteClient } from '@/lib/supabase-route'

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const body = await req.json()
  const { action, ...rest } = body

  const { data: remessa } = await supabase
    .from('remessas')
    .select('id, status, status_anterior, meta:metas(admin_id)')
    .eq('id', params.id)
    .single()

  if (!remessa || (remessa.meta as any)?.admin_id !== user.id) {
    return NextResponse.json({ error: 'Sem permissão' }, { status: 403 })
  }

  // Restaurar da lixeira
  if (action === 'restaurar') {
    if (remessa.status !== 'lixeira') {
      return NextResponse.json({ error: 'Remessa não está na lixeira' }, { status: 400 })
    }
    const statusAnterior = remessa.status_anterior ?? 'normal'
    const { data, error } = await supabase
      .from('remessas')
      .update({ status: statusAnterior, deleted_at: null, status_anterior: null })
      .eq('id', params.id)
      .select()
      .single()

    if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
    return NextResponse.json({ data })
  }

  const campos = ['titulo', 'tipo', 'saldo_ini', 'contas', 'deposito', 'saque', 'status', 'notas', 'slot_id']
  const update: Record<string, any> = {}
  campos.forEach(c => { if (rest[c] !== undefined) update[c] = rest[c] })

  const { data, error } = await supabase
    .from('remessas')
    .update(update)
    .eq('id', params.id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({ data })
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createRouteClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { data: remessa } = await supabase
    .from('remessas')
    .select('id, status, meta:metas(admin_id)')
    .eq('id', params.id)
    .single()

  if (!remessa || (remessa.meta as any)?.admin_id !== user.id) {
    return NextResponse.json({ error: 'Sem permissão' }, { status: 403 })
  }

  const now = new Date().toISOString()

  // Soft delete: move para lixeira preservando os dados
  const { error } = await supabase
    .from('remessas')
    .update({
      status: 'lixeira',
      deleted_at: now,
      status_anterior: remessa.status,
    })
    .eq('id', params.id)

  if (error) return NextResponse.json({ error: 'Erro interno' }, { status: 500 })

  return NextResponse.json({
    data: {
      deleted: true,
      deleted_at: now,
      message: 'Operação movida para a lixeira. Será excluída permanentemente em 1 dia (plano trial).',
    },
  })
}
