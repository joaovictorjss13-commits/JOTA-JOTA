'use client'

import { useState, useEffect, useCallback } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Tabs, PillTabs } from '@/components/ui/Tabs'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { StatCard } from '@/components/ui/StatCard'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { StatusBadge } from '@/components/ui/Badge'
import { GoalDetailModal } from '@/components/modals/GoalDetailModal'
import { cn, formatBRL } from '@/lib/utils'
import { useToast } from '@/components/ui/Toast'
import {
  DollarSign, RefreshCw, AlertTriangle,
  CheckCircle2, Loader2, TrendingUp, TrendingDown, Minus,
  Target, Activity, Zap, Bell, Edit2,
} from 'lucide-react'
import { getDashboardData, getMetas, updateMetaStatus, getAdminProfile } from '@/lib/supabase-service'
import { DateRangePicker } from '@/components/ui/DateRangePicker'
import { useUserProfile } from '@/hooks/useUserProfile'
import { ProGate } from '@/components/ui/ProGate'
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, ReferenceLine, BarChart, Bar, Cell,
} from 'recharts'

// ── types ──────────────────────────────────────────────────────────────────
const zeroData = {
  lucro_final: 0,
  deposito_total: 0,
  saque_total: 0,
  metas_fechadas: 0,
  total_metas: 0,
  metas_ativas: 0,
  casas_ativas: 0,
  taxa_acerto: 0,
  tendencia: 'Estável',
  metas: [] as any[],
  meta_global: 0,
}

// ── chart helpers ──────────────────────────────────────────────────────────
type Period = 'diario' | 'semanal' | 'mensal'

function periodKey(date: Date, period: Period): string {
  if (period === 'mensal') {
    return date.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' })
  }
  if (period === 'semanal') {
    const startOfYear = new Date(date.getFullYear(), 0, 1)
    const week = Math.ceil(((date.getTime() - startOfYear.getTime()) / 86400000 + startOfYear.getDay() + 1) / 7)
    return `S${week}`
  }
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })
}

function buildAreaData(metas: any[], period: Period) {
  const sorted = [...metas]
    .filter(m => m.created_at)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
  const grouped: Record<string, number> = {}
  sorted.forEach(m => {
    const k = periodKey(new Date(m.created_at), period)
    grouped[k] = (grouped[k] || 0) + Number(m.resultado_liquido || 0)
  })
  let cum = 0
  return Object.entries(grouped).map(([label, val]) => {
    cum += val
    return { label, lucro: Math.round(cum * 100) / 100 }
  })
}

function buildBarData(metas: any[], period: Period) {
  const sorted = [...metas]
    .filter(m => m.created_at)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
  const grouped: Record<string, { lucro: number; prejuizo: number }> = {}
  sorted.forEach(m => {
    const k = periodKey(new Date(m.created_at), period)
    const val = Number(m.resultado_liquido || 0)
    if (!grouped[k]) grouped[k] = { lucro: 0, prejuizo: 0 }
    if (val >= 0) grouped[k].lucro += val
    else grouped[k].prejuizo += Math.abs(val)
  })
  return Object.entries(grouped).map(([label, v]) => ({
    label,
    lucro: Math.round(v.lucro),
    prejuizo: Math.round(v.prejuizo),
  }))
}

// ── main page ──────────────────────────────────────────────────────────────
export default function FaturamentoPage() {
  const { addToast } = useToast()
  const { profile } = useUserProfile()
  const isFree = profile !== null && !profile.isPro
  const [activeTab, setActiveTab] = useState('visao_geral')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [data, setData] = useState(zeroData)
  const [fullMetas, setFullMetas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedMeta, setSelectedMeta] = useState<any>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [dash, metas, profile] = await Promise.all([
        getDashboardData(),
        getMetas(),
        getAdminProfile(),
      ])
      const metasArr: any[] = metas || []
      const metasComResultado = metasArr.filter(m => Number(m.resultado_liquido || 0) > 0)
      const taxa_acerto = metasArr.length > 0
        ? Math.round((metasComResultado.length / metasArr.length) * 100)
        : 0
      const lucro = Number(dash.lucro_acumulado)

      setFullMetas(metasArr)
      setData({
        lucro_final: lucro,
        deposito_total: Number(dash.deposito_total),
        saque_total: Number(dash.saque_total),
        metas_fechadas: metasArr.filter(m => m.status === 'fechada' || m.status === 'finalizada').length,
        total_metas: Number(dash.total_metas),
        metas_ativas: metasArr.filter(m => m.status === 'ativa').length,
        casas_ativas: Number(dash.casas_ativas),
        taxa_acerto,
        tendencia: lucro > 0 ? 'Subindo' : lucro < 0 ? 'Queda' : 'Estável',
        metas: metasArr,
        meta_global: Number(profile?.meta_global || 0),
      })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao carregar faturamento', message: err.message })
    } finally {
      setLoading(false)
    }
  }, [addToast])

  useEffect(() => { load() }, [load])

  const handleDeleteMeta = async (meta: any) => {
    try {
      await updateMetaStatus(meta.id, 'lixeira')
      setSelectedMeta(null)
      addToast({ type: 'success', title: 'Operação movida para a lixeira' })
      // Reload all panel data so totals (lucro, depósito, saque, taxa) also desaparecem
      await load()
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro', message: err.message })
    }
  }

  const tabs = [
    { key: 'visao_geral', label: 'Visão Geral' },
    { key: 'evolucao', label: 'Evolução' },
    { key: 'historico', label: 'Histórico' },
  ]

  return (
    <DashboardLayout>
      <div className="flex items-start justify-between mb-6 mt-8 md:mt-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-green/15 flex items-center justify-center">
            <DollarSign size={20} className="text-accent-green" />
          </div>
          <div>
            <h1 className="text-2xl font-black">Faturamento</h1>
            <p className="text-sm text-text-muted">Painel estratégico de gestão financeira</p>
          </div>
        </div>
        <Button variant="secondary" size="sm" onClick={load} disabled={loading}>
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          Atualizar
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <span className="text-xs text-text-muted font-semibold uppercase">Período:</span>
        <DateRangePicker
          from={dateFrom}
          to={dateTo}
          onChange={(f, t) => { setDateFrom(f); setDateTo(t) }}
        />
      </div>

      <Tabs tabs={tabs} active={activeTab} onChange={setActiveTab} className="mb-6" />

      {loading ? (
        <div className="py-20 text-center">
          <Loader2 size={32} className="animate-spin text-accent-green mx-auto mb-3" />
          <p className="text-sm text-text-muted">Carregando dados...</p>
        </div>
      ) : isFree ? (
        <ProGate>
          <div className="animate-fade-in">
            <VisaoGeralTab data={data} onSelectMeta={() => {}} />
          </div>
        </ProGate>
      ) : (
        <div className="animate-fade-in">
          {activeTab === 'visao_geral' && (
            <VisaoGeralTab data={data} onSelectMeta={setSelectedMeta} />
          )}
          {activeTab === 'evolucao' && (
            <EvolucaoTab metas={fullMetas} />
          )}
          {activeTab === 'historico' && (
            <HistoricoTab metas={fullMetas} onSelectMeta={setSelectedMeta} />
          )}
        </div>
      )}

      {!isFree && (
        <GoalDetailModal
          isOpen={!!selectedMeta}
          onClose={() => setSelectedMeta(null)}
          meta={selectedMeta}
          onDelete={handleDeleteMeta}
        />
      )}
    </DashboardLayout>
  )
}

// ═══════════════════════════════════════════════════════════════════════════
// META GLOBAL CARD
// ═══════════════════════════════════════════════════════════════════════════
const GOAL_PRESETS = [
  { label: 'R$ 50k',    value: 50000 },
  { label: 'R$ 100k',   value: 100000 },
  { label: 'R$ 250k',   value: 250000 },
  { label: 'R$ 500k',   value: 500000 },
  { label: 'R$ 1000k',  value: 1000000 },
]

function MetaGlobalCard({
  lucroFinal,
  metas,
  profileGoal,
}: {
  lucroFinal: number
  metas: any[]
  profileGoal: number
}) {
  const [goal, setGoal]       = useState(0)
  const [editing, setEditing] = useState(false)
  const [editVal, setEditVal] = useState('')

  useEffect(() => {
    const stored = localStorage.getItem('faturamento_meta_global')
    if (stored && Number(stored) > 0) {
      setGoal(Number(stored))
    } else if (profileGoal > 0) {
      setGoal(profileGoal)
    }
  }, [profileGoal])

  const applyGoal = (val: number) => {
    if (val > 0) {
      setGoal(val)
      localStorage.setItem('faturamento_meta_global', String(val))
    }
    setEditing(false)
    setEditVal('')
  }

  const saveCustom = () => {
    const val = parseFloat(editVal.replace(/[^0-9.,]/g, '').replace(',', '.'))
    if (!isNaN(val) && val > 0) applyGoal(val)
    else setEditing(false)
  }

  const pct   = goal > 0 ? Math.min(100, Math.round((Math.max(0, lucroFinal) / goal) * 100)) : 0
  const falta = Math.max(0, goal - lucroFinal)

  const previsao = (() => {
    if (falta <= 0 && goal > 0) return 'Meta atingida!'
    if (lucroFinal <= 0) return '—'
    const sorted = [...metas]
      .filter(m => m.created_at)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    if (!sorted.length) return '—'
    const daysElapsed = Math.max(1, (Date.now() - new Date(sorted[0].created_at).getTime()) / 86400000)
    const dailyRate   = lucroFinal / daysElapsed
    if (dailyRate <= 0) return '—'
    return `~${Math.ceil(falta / dailyRate)} dias`
  })()

  return (
    <div
      className="rounded-xl border p-4"
      style={{ background: 'rgba(16,185,129,0.05)', borderColor: 'rgba(16,185,129,0.20)' }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2">
            <Target size={14} className="text-accent-green" />
            <span className="text-sm font-bold">Meta global</span>
          </div>
          {goal > 0 && (
            <p className="text-[10px] text-text-muted mt-0.5">Objetivo: {formatBRL(goal)}</p>
          )}
        </div>
        <button
          onClick={() => { setEditVal(goal > 0 ? String(goal) : ''); setEditing(v => !v) }}
          className="flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all hover:opacity-80"
          style={{ background: 'rgba(16,185,129,0.15)', color: '#4ade80', border: '1px solid rgba(16,185,129,0.30)' }}
        >
          <Edit2 size={10} />
          Editar
        </button>
      </div>

      {/* Edit panel */}
      {editing && (
        <div
          className="mb-4 rounded-lg border p-3"
          style={{ background: 'rgba(0,0,0,0.25)', borderColor: 'rgba(16,185,129,0.20)' }}
        >
          <p className="text-[10px] font-bold text-text-muted uppercase mb-2">
            Definir meta de faturamento (R$)
          </p>
          <div className="flex gap-2 mb-2">
            <input
              className="flex-1 bg-bg-surface border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent-green/50"
              value={editVal}
              onChange={e => setEditVal(e.target.value)}
              placeholder="Ex: 100000"
              autoFocus
              onKeyDown={e => {
                if (e.key === 'Enter') saveCustom()
                if (e.key === 'Escape') setEditing(false)
              }}
            />
            <Button size="sm" variant="primary" onClick={saveCustom}>Salvar</Button>
            <Button size="sm" variant="secondary" onClick={() => setEditing(false)}>Cancelar</Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {GOAL_PRESETS.map(p => (
              <button
                key={p.value}
                onClick={() => applyGoal(p.value)}
                className="text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all hover:bg-bg-surface"
                style={{ background: 'rgba(255,255,255,0.04)', borderColor: 'rgba(255,255,255,0.10)', color: '#ccc' }}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Content */}
      {goal > 0 ? (
        <>
          <div className="mb-2">
            <span className="text-4xl font-black text-accent-green">{pct}%</span>
            <span className="text-sm text-text-muted ml-2">concluído</span>
          </div>

          <div className="h-2.5 bg-bg-surface rounded-full overflow-hidden mb-4">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${pct}%`,
                background: pct >= 100 ? '#4ade80' : 'linear-gradient(90deg, #10b981, #4ade80)',
              }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div
              className="rounded-xl p-3 border text-center"
              style={{ background: 'rgba(34,197,94,0.06)', borderColor: 'rgba(34,197,94,0.18)' }}
            >
              <p className="text-[9px] font-bold uppercase text-text-muted mb-1.5">Atingido</p>
              <p className="text-sm font-black text-accent-green">{formatBRL(Math.max(0, lucroFinal))}</p>
            </div>
            <div
              className="rounded-xl p-3 border text-center"
              style={{ background: 'rgba(239,68,68,0.06)', borderColor: 'rgba(239,68,68,0.18)' }}
            >
              <p className="text-[9px] font-bold uppercase text-text-muted mb-1.5">Falta</p>
              <p className="text-sm font-black text-accent-red">{formatBRL(falta)}</p>
            </div>
            <div
              className="rounded-xl p-3 border text-center"
              style={{ background: 'rgba(96,165,250,0.06)', borderColor: 'rgba(96,165,250,0.18)' }}
            >
              <p className="text-[9px] font-bold uppercase text-text-muted mb-1.5">Previsão</p>
              <p className="text-sm font-black text-accent-blue">{previsao}</p>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-6">
          <Target size={32} className="mx-auto text-text-muted mb-2 opacity-30" />
          <p className="text-sm text-text-muted">Defina sua meta global</p>
          <p className="text-[10px] text-text-muted mt-1">Clique em Editar para configurar</p>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════
// VISÃO GERAL
// ═══════════════════════════════════════════════════════════════════════════
function VisaoGeralTab({ data, onSelectMeta }: { data: typeof zeroData; onSelectMeta: (m: any) => void }) {
  const emLucro    = data.metas.filter(m => Number(m.resultado_liquido || 0) > 0).length
  const emPrejuizo = data.metas.filter(m => Number(m.resultado_liquido || 0) < 0).length
  const neutras    = data.metas.filter(m => Number(m.resultado_liquido || 0) === 0 && m.status === 'ativa').length

  const mediaFechadas = data.metas_fechadas > 0 ? data.lucro_final / data.metas_fechadas : 0

  // Read stored goal for alerts
  const storedGoal    = typeof window !== 'undefined'
    ? Number(localStorage.getItem('faturamento_meta_global') || data.meta_global || 0)
    : data.meta_global
  const pctGlobal     = storedGoal > 0
    ? Math.min(100, Math.round((Math.max(0, data.lucro_final) / storedGoal) * 100))
    : 0

  const tendenciaCor    = data.tendencia === 'Subindo' ? '#4ade80' : data.tendencia === 'Queda' ? '#f87171' : '#fbbf24'
  const tendenciaBg     = data.tendencia === 'Subindo' ? 'rgba(34,197,94,0.07)' : data.tendencia === 'Queda' ? 'rgba(239,68,68,0.07)' : 'rgba(245,158,11,0.07)'
  const tendenciaBorder = data.tendencia === 'Subindo' ? 'rgba(34,197,94,0.25)' : data.tendencia === 'Queda' ? 'rgba(239,68,68,0.25)' : 'rgba(245,158,11,0.25)'

  // Smart alerts
  const alertas: { msg: string; cor: string }[] = []
  if (emPrejuizo > 0)
    alertas.push({ msg: `${emPrejuizo} operaç${emPrejuizo > 1 ? 'ões' : 'ão'} em prejuízo — revise as remessas bloqueadas`, cor: '#f87171' })
  if (emLucro === 1 && data.total_metas > 2)
    alertas.push({ msg: 'Lucro concentrado em poucas metas — diversifique', cor: '#fbbf24' })
  if (data.saque_total > 0 && data.deposito_total > 0) {
    const margem = ((data.saque_total - data.deposito_total) / data.deposito_total) * 100
    if (margem < 10) alertas.push({ msg: 'Volume sacado muito próximo do depositado — margem apertada', cor: '#fbbf24' })
  }
  if (pctGlobal < 20 && storedGoal > 0)
    alertas.push({ msg: `Apenas ${pctGlobal}% da meta global — acelere`, cor: '#fbbf24' })
  if (alertas.length === 0)
    alertas.push({ msg: 'Operação saudável — sem alertas no momento', cor: '#4ade80' })

  // Leitura insights
  const leituraItems: string[] = []
  if (data.metas_fechadas > 0 && mediaFechadas > 0)
    leituraItems.push(`Média de ${formatBRL(mediaFechadas)} por meta fechada`)
  if (data.taxa_acerto > 0)
    leituraItems.push(`Taxa de acerto em ${data.taxa_acerto}% — ${data.taxa_acerto >= 70 ? 'excelente' : data.taxa_acerto >= 50 ? 'bom' : 'abaixo do esperado'}`)
  if (data.tendencia === 'Subindo')
    leituraItems.push('Tendência de crescimento — mantenha o ritmo')
  else if (data.tendencia === 'Queda')
    leituraItems.push('Tendência de queda — revise a estratégia')
  if (storedGoal > 0 && pctGlobal < 100 && mediaFechadas > 0) {
    const faltaVal = Math.max(0, storedGoal - data.lucro_final)
    const dias     = Math.ceil(faltaVal / (mediaFechadas / 30))
    if (dias > 0) leituraItems.push(`No ritmo atual, meta em ~${dias} dias`)
  }
  if (leituraItems.length === 0)
    leituraItems.push('Registre operações para obter análises automáticas')

  return (
    <div className="space-y-5">

      {/* ── ROW 1: Receita + Métricas laterais ── */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 lg:gap-6">
        <Card className="lg:col-span-3" glow="green">
          <p className="text-xs font-bold text-accent-green uppercase tracking-wider mb-1">Receita Consolidada</p>
          <p className="text-[10px] text-text-muted mb-3">Lucro final da operação — após custos</p>
          <MoneyDisplay value={data.lucro_final} size="xl" />

          {/* pills */}
          <div className="grid grid-cols-3 gap-3 mt-4">
            {[
              { label: 'EM LUCRO',    count: emLucro,    color: '#4ade80', bg: 'rgba(34,197,94,0.07)',  border: 'rgba(34,197,94,0.25)',  Icon: TrendingUp },
              { label: 'EM PREJUÍZO', count: emPrejuizo, color: '#f87171', bg: 'rgba(239,68,68,0.07)',  border: 'rgba(239,68,68,0.25)',  Icon: TrendingDown },
              { label: 'NEUTRAS',     count: neutras,    color: '#fbbf24', bg: 'rgba(245,158,11,0.07)', border: 'rgba(245,158,11,0.25)', Icon: Minus },
            ].map(({ label, count, color, bg, border, Icon }) => (
              <div key={label} className="rounded-xl p-3 border" style={{ background: bg, borderColor: border }}>
                <div className="flex items-center gap-2">
                  <Icon size={13} style={{ color }} />
                  <span className="text-xl font-black" style={{ color }}>{count}</span>
                  <span className="text-[9px] font-bold text-text-muted">{count === 1 ? 'operação' : 'operações'}</span>
                </div>
                <p className="text-[9px] font-black uppercase tracking-wider mt-1" style={{ color }}>{label}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 pt-3 border-t border-border text-sm">
            <div>
              <span className="text-text-muted text-[10px] uppercase">Operações Fechadas</span>
              <p className="font-bold">{data.metas_fechadas}</p>
            </div>
            <div>
              <span className="text-text-muted text-[10px] uppercase">Operações ativas</span>
              <p className="font-bold text-accent-green">{data.metas_ativas}</p>
            </div>
            <div>
              <span className="text-text-muted text-[10px] uppercase">Total operações</span>
              <p className="font-bold">{data.total_metas}</p>
            </div>
            <div>
              <span className="text-text-muted text-[10px] uppercase">Casas ativas</span>
              <p className="font-bold text-accent-blue">{data.casas_ativas}</p>
            </div>
          </div>
        </Card>

        <div className="space-y-3">
          <StatCard label="Lucro Bruto"     value={data.saque_total - data.deposito_total} glow="green" />
          <StatCard label="Total depositado" value={data.deposito_total} glow="red" />
          <StatCard label="Total sacado"     value={data.saque_total}    glow="blue" />
          <StatCard label="Taxa de acerto"   value={data.taxa_acerto} format="percent" glow="yellow" />
        </div>
      </div>

      {/* ── ROW 2: Inteligência + Meta Global ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {/* Inteligência da operação */}
        <div className="rounded-xl border p-4" style={{ background: 'rgba(124,58,237,0.06)', borderColor: 'rgba(124,58,237,0.25)' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Activity size={14} className="text-purple-400" />
              <span className="text-sm font-bold">Inteligência da operação</span>
            </div>
            <span className="flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded" style={{ background: 'rgba(124,58,237,0.15)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.30)' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse inline-block" />
              AO VIVO
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="rounded-lg p-3 border" style={{ background: tendenciaBg, borderColor: tendenciaBorder }}>
              <p className="text-[10px] text-text-muted uppercase mb-1">Tendência</p>
              <div className="flex items-center gap-1.5">
                {data.tendencia === 'Subindo'
                  ? <TrendingUp size={14} style={{ color: tendenciaCor }} />
                  : data.tendencia === 'Queda'
                  ? <TrendingDown size={14} style={{ color: tendenciaCor }} />
                  : <Minus size={14} style={{ color: tendenciaCor }} />}
                <p className="text-sm font-bold" style={{ color: tendenciaCor }}>{data.tendencia}</p>
              </div>
            </div>

            <div className="rounded-lg p-3 border" style={{ background: 'rgba(16,185,129,0.07)', borderColor: 'rgba(16,185,129,0.25)' }}>
              <p className="text-[10px] text-text-muted uppercase mb-1">Lucro final real</p>
              <p className={cn('text-sm font-bold', data.lucro_final >= 0 ? 'text-accent-green' : 'text-accent-red')}>
                {data.lucro_final >= 0 ? '+' : ''}{formatBRL(data.lucro_final)}
              </p>
            </div>
          </div>

          <div className="rounded-lg p-3 border" style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(255,255,255,0.07)' }}>
            <p className="text-[10px] text-text-muted uppercase mb-1">Operações fechadas</p>
            <p className="text-sm font-bold">{data.metas_fechadas} operações</p>
            {mediaFechadas > 0 && (
              <p className="text-[10px] text-text-muted mt-0.5">Média: {formatBRL(mediaFechadas)}/operação</p>
            )}
          </div>
        </div>

        <MetaGlobalCard
          lucroFinal={data.lucro_final}
          metas={data.metas}
          profileGoal={data.meta_global}
        />
      </div>

      {/* ── ROW 3: Leitura + Alertas ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {/* Leitura da operação */}
        <div className="rounded-xl border p-4" style={{ background: 'rgba(16,185,129,0.05)', borderColor: 'rgba(16,185,129,0.20)' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap size={14} className="text-accent-green" />
              <span className="text-sm font-bold">Leitura da operação</span>
            </div>
            <span
              className="text-[10px] font-black px-2 py-0.5 rounded border"
              style={{
                background: data.tendencia === 'Queda' ? 'rgba(239,68,68,0.10)' : 'rgba(16,185,129,0.15)',
                color: data.tendencia === 'Queda' ? '#f87171' : '#4ade80',
                borderColor: data.tendencia === 'Queda' ? 'rgba(239,68,68,0.25)' : 'rgba(16,185,129,0.30)',
              }}
            >
              {data.tendencia === 'Queda' ? 'Atenção' : 'Operação saudável'}
            </span>
          </div>
          <ul className="space-y-2.5">
            {leituraItems.map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-text-secondary">
                <CheckCircle2 size={13} className="text-accent-green mt-0.5 shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Alertas e atenção */}
        <div className="rounded-xl border p-4" style={{ background: 'rgba(245,158,11,0.05)', borderColor: 'rgba(245,158,11,0.20)' }}>
          <div className="flex items-center gap-2 mb-3">
            <Bell size={14} className="text-accent-yellow" />
            <span className="text-sm font-bold">Alertas e atenção</span>
          </div>
          <ul className="space-y-2.5">
            {alertas.map((alerta, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <AlertTriangle size={13} style={{ color: alerta.cor }} className="mt-0.5 shrink-0" />
                <span style={{ color: alerta.cor }}>{alerta.msg}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* ── ROW 4: Performance por plataforma ── */}
      {(() => {
        const casasMap: Record<string, number> = {}
        data.metas.forEach((m: any) => {
          const k = m.plataforma || '—'
          casasMap[k] = (casasMap[k] || 0) + Number(m.resultado_liquido || 0)
        })
        const casasData = Object.entries(casasMap)
          .map(([name, value]) => ({ name, value: Math.round(value) }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 10)
        if (casasData.length === 0) return null
        return (
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold">Performance por plataforma</h3>
              <span className="text-xs text-text-muted">{casasData.length} casas</span>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={casasData} margin={{ top: 4, right: 4, left: -8, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#555' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: '#555' }} tickLine={false} axisLine={false} tickFormatter={v => `R$${(Math.abs(v) / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ background: '#0f0f1a', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                    formatter={(val: any) => [formatBRL(val), 'Resultado']}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={40}>
                    {casasData.map((entry, i) => (
                      <Cell key={i} fill={entry.value >= 0 ? 'rgba(34,197,94,0.75)' : 'rgba(239,68,68,0.70)'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        )
      })()}

    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════
// EVOLUÇÃO — apenas gráficos
// ═══════════════════════════════════════════════════════════════════════════
function EvolucaoTab({ metas }: { metas: any[] }) {
  const [period, setPeriod] = useState<Period>('diario')

  const areaData = buildAreaData(metas, period)
  const barData  = buildBarData(metas, period)
  const hasData  = areaData.length > 1

  const chartTooltip = {
    contentStyle: {
      background: '#0f0f1a',
      border: '1px solid rgba(255,255,255,0.08)',
      borderRadius: 10,
      fontSize: 11,
    },
    labelStyle: { color: '#666', marginBottom: 4 },
  }

  return (
    <div className="space-y-5">

      {/* Toggle Diário / Semanal / Mensal */}
      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold">Evolução do faturamento</h2>
        <PillTabs
          options={['Diário', 'Semanal', 'Mensal']}
          active={period === 'diario' ? 'Diário' : period === 'semanal' ? 'Semanal' : 'Mensal'}
          onChange={v => setPeriod(v === 'Diário' ? 'diario' : v === 'Semanal' ? 'semanal' : 'mensal')}
        />
      </div>

      {/* Lucro acumulado — área */}
      <Card>
        {!hasData ? (
          <div className="h-64 flex items-center justify-center text-sm text-text-muted">
            Dados insuficientes. Registre operações para ver o gráfico.
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={areaData} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#555' }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#555' }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={v => `R$${(v / 1000).toFixed(1)}k`}
                />
                <Tooltip
                  {...chartTooltip}
                  formatter={(val: any) => [formatBRL(val), 'Lucro acumulado']}
                />
                <ReferenceLine y={0} stroke="#ef4444" strokeWidth={1.5} strokeDasharray="0" opacity={0.6} />
                <Area
                  type="monotone"
                  dataKey="lucro"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  fill="url(#areaGrad)"
                  dot={false}
                  activeDot={{ r: 4, fill: '#3b82f6' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      {/* Comparativo lucro vs prejuízo — barras */}
      <Card>
        <h3 className="text-sm font-bold mb-4">Comparativo lucro vs prejuízo</h3>
        {barData.length === 0 ? (
          <div className="h-48 flex items-center justify-center text-sm text-text-muted">
            Nenhum dado disponível.
          </div>
        ) : (
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#555' }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#555' }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={v => `R$${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  {...chartTooltip}
                  formatter={(val: any, name: string) => [
                    formatBRL(val),
                    name === 'lucro' ? 'Lucro' : 'Prejuízo',
                  ]}
                />
                <Bar dataKey="lucro"    fill="rgba(34,197,94,0.75)"  radius={[4, 4, 0, 0]} maxBarSize={40} />
                <Bar dataKey="prejuizo" fill="rgba(239,68,68,0.70)"  radius={[4, 4, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════
// HISTÓRICO
// ═══════════════════════════════════════════════════════════════════════════
const HISTORICO_STATUS_MAP: Record<string, string> = {
  'Todas': '', 'Ativas': 'ativa', 'Fechadas': 'fechada', 'Finalizadas': 'finalizada',
}

function HistoricoTab({ metas, onSelectMeta }: { metas: any[]; onSelectMeta: (m: any) => void }) {
  const [statusFilter, setStatusFilter] = useState('Todas')
  const filtered = statusFilter === 'Todas'
    ? metas.filter(m => m.status !== 'lixeira')
    : metas.filter(m => m.status === HISTORICO_STATUS_MAP[statusFilter])

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold">Histórico de operações</h3>
        <PillTabs
          options={['Todas', 'Ativas', 'Fechadas', 'Finalizadas']}
          active={statusFilter}
          onChange={setStatusFilter}
        />
      </div>

      {filtered.length === 0 ? (
        <div className="py-16 text-center text-sm text-text-muted">
          Nenhuma operação encontrada.
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((m: any) => {
            const resultado  = Number(m.resultado_liquido || 0)
            const initials   = (m.rede_sigla || m.plataforma || m.titulo || 'Op').substring(0, 2).toUpperCase()
            const progressPct = Math.min(100, Math.round(((m.contas_atingidas || 0) / (m.contas_total || 1)) * 100))
            return (
              <button
                key={m.id}
                onClick={() => onSelectMeta(m)}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-xl border transition-all hover:scale-[1.005] active:scale-[0.998] text-left"
                style={{
                  background: 'rgba(255,255,255,0.02)',
                  borderColor: resultado > 0 ? 'rgba(34,197,94,0.20)' : resultado < 0 ? 'rgba(239,68,68,0.20)' : 'rgba(255,255,255,0.07)',
                }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black text-violet-300 shrink-0"
                  style={{ background: 'rgba(124,58,237,0.20)', border: '1px solid rgba(124,58,237,0.30)' }}
                >
                  {initials}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm">{m.titulo}</span>
                    <StatusBadge status={m.status} />
                    {m.rede_sigla && (
                      <span
                        className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                        style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171' }}
                      >
                        {m.rede_sigla}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1">
                    <p className="text-[10px] text-text-muted">
                      {m.plataforma} · {m.contas_atingidas || 0}/{m.contas_total || 0} contas
                    </p>
                    <div className="flex-1 max-w-24 h-1 bg-bg-surface rounded-full overflow-hidden">
                      <div
                        className={cn('h-full rounded-full', resultado > 0 ? 'bg-accent-green' : resultado < 0 ? 'bg-accent-red' : 'bg-accent-yellow')}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-text-muted">{progressPct}%</span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <MoneyDisplay value={resultado} size="sm" />
                  <p className="text-[10px] text-text-muted mt-0.5">
                    {m.created_at ? new Date(m.created_at).toLocaleDateString('pt-BR') : '—'}
                  </p>
                </div>
              </button>
            )
          })}
        </div>
      )}
    </Card>
  )
}
