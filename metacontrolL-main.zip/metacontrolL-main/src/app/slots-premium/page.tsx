'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { PillTabs } from '@/components/ui/Tabs'
import { cn } from '@/lib/utils'
import { Crown, Lock, Star, TrendingUp, Search, Filter } from 'lucide-react'
import Link from 'next/link'
import * as SlotsLib from '@/data/slots-data'


export default function SlotsPremiumPage() {
  const { slotsData, providers, volatilidades } = SlotsLib
  // Toggle this to simulate subscribed/not subscribed
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [providerFilter, setProviderFilter] = useState('Todos')
  const [volFilter, setVolFilter] = useState('Todas')
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState<'todos' | 'novos' | 'lucro'>('todos')

  const filtered = slotsData.filter(s => {
    if (providerFilter !== 'Todos' && s.provider !== providerFilter) return false
    if (volFilter !== 'Todas' && s.volatilidade !== volFilter) return false
    if (search && !s.nome.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }).sort((a, b) => {
    if (tab === 'lucro') return b.retorno - a.retorno
    return 0
  })

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-start justify-between mb-6 mt-8 md:mt-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-yellow/15 flex items-center justify-center">
            <Crown size={20} className="text-accent-yellow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black">Slots Premium</h1>
              <Badge variant="danger">VIP</Badge>
            </div>
            <p className="text-sm text-text-muted">
              Slots ranqueados por performance · Atualizados 24/7
            </p>
          </div>
        </div>

        {/* Toggle for demo */}
        <button
          onClick={() => setIsSubscribed(!isSubscribed)}
          className={cn(
            'px-3 py-1.5 rounded-lg text-xs font-bold border transition-all',
            isSubscribed
              ? 'bg-accent-green/15 border-accent-green/30 text-accent-green'
              : 'bg-accent-red/15 border-accent-red/30 text-accent-red'
          )}
        >
          {isSubscribed ? '✓ PRO Ativo' : '✗ Sem assinatura'}
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <PillTabs
          options={providers}
          active={providerFilter}
          onChange={setProviderFilter}
        />
        <div className="w-px h-6 bg-border hidden md:block" />
        <PillTabs
          options={volatilidades}
          active={volFilter}
          onChange={setVolFilter}
        />
        <div className="flex-1" />
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar slot..."
            className="pl-9 pr-3 py-2 bg-bg-surface border border-border rounded-lg text-sm text-text-primary placeholder:text-text-muted
                       focus:outline-none focus:border-accent-green/50 transition-all w-48"
          />
        </div>
      </div>

      {/* Tab filters */}
      <div className="flex items-center gap-4 mb-6">
        {[
          { key: 'todos' as const, label: 'Todos' },
          { key: 'novos' as const, label: '🔥 Novos' },
          { key: 'lucro' as const, label: '💰 Lucro' },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={cn(
              'text-sm font-semibold transition-all pb-1 border-b-2',
              tab === t.key
                ? 'text-text-primary border-accent-green'
                : 'text-text-muted border-transparent hover:text-text-secondary'
            )}
          >
            {t.label}
          </button>
        ))}
        <div className="flex-1" />
        <span className="text-xs text-text-muted">{filtered.length} slots</span>
      </div>

      {/* Stats bar */}
      <div className="flex items-center gap-6 mb-6">
        <div className="flex items-center gap-2 text-sm">
          <span className="text-2xl font-black text-accent-green">+48</span>
          <span className="text-text-muted text-xs">slots<br/>ranqueados</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-2xl font-black text-accent-blue">8</span>
          <span className="text-text-muted text-xs">provedores</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-2xl font-black text-accent-yellow">24/7</span>
          <span className="text-text-muted text-xs">atualizado</span>
        </div>
      </div>

      {/* Not subscribed CTA banner */}
      {!isSubscribed && (
        <Card className="mb-6 bg-gradient-to-r from-cta/10 to-accent-yellow/10 border-cta/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock size={20} className="text-cta" />
              <div>
                <p className="text-sm font-bold">Conteúdo exclusivo para membros VIP</p>
                <p className="text-xs text-text-muted">Assine o PRO para desbloquear todos os slots com dados de performance</p>
              </div>
            </div>
            <Link href="/assinatura">
              <Button size="sm">
                <Crown size={14} />
                Desbloquear Slots Premium
              </Button>
            </Link>
          </div>
        </Card>
      )}

      {/* Slots grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((slot) => {
          const isLocked = slot.premium && !isSubscribed

          return (
            <div
              key={slot.id}
              className={cn(
                'group rounded-xl border overflow-hidden transition-all duration-300',
                isLocked
                  ? 'border-border/50'
                  : 'border-border hover:border-border-light hover:translate-y-[-2px]'
              )}
            >
              {/* Image */}
              <div className="relative aspect-[16/10] bg-bg-surface-light overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={slot.imagem}
                  alt={slot.nome}
                  className={cn(
                    'w-full h-full object-cover transition-all duration-300',
                    isLocked ? 'blur-md scale-105' : 'group-hover:scale-105'
                  )}
                />

                {/* Lock overlay for non-subscribed premium slots */}
                {isLocked && (
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="text-center">
                      <Lock size={24} className="mx-auto text-accent-yellow mb-1" />
                      <p className="text-[10px] font-bold text-accent-yellow uppercase">VIP</p>
                    </div>
                  </div>
                )}

                {/* Provider badge */}
                <div className="absolute top-2 left-2">
                  <span className="px-1.5 py-0.5 bg-black/60 backdrop-blur-sm rounded text-[9px] font-bold text-white uppercase">
                    {slot.provider.substring(0, 2)}
                  </span>
                </div>

                {/* Retorno badge */}
                {!isLocked && (
                  <div className="absolute top-2 right-2">
                    <span className={cn(
                      'px-1.5 py-0.5 rounded text-[9px] font-bold',
                      slot.retorno >= 97 ? 'bg-accent-green/80 text-black' : 'bg-accent-yellow/80 text-black'
                    )}>
                      {slot.retorno}%
                    </span>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className={cn(
                'px-3 py-2.5 bg-bg-surface',
                isLocked && 'blur-[3px]'
              )}>
                <p className="text-xs font-bold truncate">{slot.nome}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[10px] text-text-muted">{slot.provider}</span>
                  <div className="flex items-center gap-1">
                    <TrendingUp size={10} className={slot.retorno >= 96.5 ? 'text-accent-green' : 'text-accent-yellow'} />
                    <span className={cn(
                      'text-[10px] font-bold',
                      slot.retorno >= 96.5 ? 'text-accent-green' : 'text-accent-yellow'
                    )}>
                      {slot.retorno}%
                    </span>
                  </div>
                </div>
                <div className="mt-1">
                  <span className={cn(
                    'text-[9px] px-1.5 py-0.5 rounded font-bold',
                    slot.volatilidade === 'Alta' ? 'bg-accent-red/15 text-accent-red' :
                    slot.volatilidade === 'Média' ? 'bg-accent-yellow/15 text-accent-yellow' :
                    'bg-accent-green/15 text-accent-green'
                  )}>
                    {slot.volatilidade}
                  </span>
                </div>
              </div>

              {/* Locked info overlay */}
              {isLocked && (
                <div className="absolute bottom-0 left-0 right-0 px-3 py-2.5 bg-bg-surface">
                  <p className="text-xs font-bold truncate">{slot.nome}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[10px] text-text-muted">{slot.provider}</span>
                    <Lock size={10} className="text-accent-yellow" />
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Bottom CTA for non-subscribed */}
      {!isSubscribed && (
        <div className="mt-8 text-center">
          <p className="text-sm text-text-muted mb-2">
            Você está vendo apenas slots grátis. Slots com maior performance são exclusivos PRO.
          </p>
          <Link href="/assinatura">
            <Button size="lg">
              <Star size={16} />
              Desbloquear Slots Premium
            </Button>
          </Link>
          <p className="text-xs text-text-muted mt-2">3 dias grátis. Sem cartão. Cancele quando quiser.</p>
        </div>
      )}
    </DashboardLayout>
  )
}

