'use client'

import { useState, useEffect } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { AddCostModal } from '@/components/modals/AddCostModal'
import { ConfirmModal } from '@/components/modals/ConfirmModal'
import { useToast } from '@/components/ui/Toast'
import { cn, formatBRL } from '@/lib/utils'
import { Receipt, Plus, DollarSign, TrendingDown, Calendar, Trash2, Loader2 } from 'lucide-react'
import { getCustos, addCusto, deleteCusto } from '@/lib/supabase-service'
import { COST_TYPES } from '@/lib/cost-constants'

const tipoLabel = Object.fromEntries(Object.entries(COST_TYPES).map(([k, v]) => [k, v.label]))
const tipoCores = Object.fromEntries(Object.entries(COST_TYPES).map(([k, v]) => [k, v.color]))

export default function CustosPage() {
  const { addToast } = useToast()
  const [showAddCost, setShowAddCost] = useState(false)
  const [custos, setCustos] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Load custos from Supabase
  useEffect(() => {
    async function load() {
      setLoading(true)
      try {
        const data = await getCustos()
        setCustos(data)
      } catch (err: any) {
        addToast({ type: 'error', title: 'Erro ao carregar custos', message: err.message })
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  // Stats calculados dos dados reais
  const today = new Date().toISOString().split('T')[0]
  const mesAtual = today.substring(0, 7)
  const custoHoje = custos.filter(c => c.data === today).reduce((a, c) => a + Number(c.valor), 0)
  const custoMes = custos.filter(c => c.data?.startsWith(mesAtual)).reduce((a, c) => a + Number(c.valor), 0)

  // Add cost
  const handleAddCost = async (data: any) => {
    try {
      const created = await addCusto(data)
      setCustos(prev => [created, ...prev])
      addToast({ type: 'success', title: 'Custo registrado', message: `${tipoLabel[data.tipo]} — ${formatBRL(data.valor)}` })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao adicionar', message: err.message })
    }
  }

  // Delete cost
  const handleDeleteCost = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      await deleteCusto(deleteTarget)
      setCustos(prev => prev.filter(c => c.id !== deleteTarget))
      addToast({ type: 'success', title: 'Custo excluído' })
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao excluir', message: err.message })
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-start justify-between mb-6 mt-8 md:mt-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-yellow/15 flex items-center justify-center">
            <Receipt size={20} className="text-accent-yellow" />
          </div>
          <div>
            <h1 className="text-2xl font-black">Custos</h1>
            <p className="text-sm text-text-muted">Gastos operacionais da operação</p>
          </div>
        </div>
        <Button onClick={() => setShowAddCost(true)}>
          <Plus size={16} />
          Adicionar custo
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6">
        <Card glow="red">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-red/15 flex items-center justify-center">
              <DollarSign size={20} className="text-accent-red" />
            </div>
            <div>
              <p className="text-xs text-text-muted uppercase">Custo do dia</p>
              <p className="text-xl font-bold text-accent-red mono-value">{formatBRL(custoHoje)}</p>
            </div>
          </div>
        </Card>

        <Card glow="green">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-green/15 flex items-center justify-center">
              <TrendingDown size={20} className="text-accent-green" />
            </div>
            <div>
              <p className="text-xs text-text-muted uppercase">Custo total</p>
              <p className="text-xl font-bold text-accent-red mono-value">
                {formatBRL(custos.reduce((a, c) => a + Number(c.valor), 0))}
              </p>
            </div>
          </div>
        </Card>

        <Card glow="yellow">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-yellow/15 flex items-center justify-center">
              <Calendar size={20} className="text-accent-yellow" />
            </div>
            <div>
              <p className="text-xs text-text-muted uppercase">Custo do mês</p>
              <p className="text-xl font-bold text-accent-yellow mono-value">{formatBRL(custoMes)}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* History */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold">Histórico de custos</h3>
          <span className="text-xs text-text-muted">{custos.length} registros</span>
        </div>

        {loading ? (
          <div className="py-12 text-center">
            <Loader2 size={24} className="animate-spin text-accent-yellow mx-auto mb-2" />
            <p className="text-sm text-text-muted">Carregando custos...</p>
          </div>
        ) : custos.length === 0 ? (
          <div className="py-12 text-center text-sm text-text-muted">
            Nenhum custo registrado. Clique em "Adicionar custo" para começar.
          </div>
        ) : (
          <div className="space-y-2">
            {custos.map((custo) => (
              <div key={custo.id}
                className="flex items-center justify-between px-4 py-3 rounded-xl bg-bg-surface-light border border-border hover:border-border-light transition-colors">
                <div className="flex items-center gap-3">
                  <span className={cn('px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase', tipoCores[custo.tipo] || tipoCores.outros)}>
                    {tipoLabel[custo.tipo] || custo.tipo}
                  </span>
                  <div>
                    {custo.nota ? (
                      <>
                        <p className="text-sm font-medium">{custo.nota}</p>
                        <p className="text-[10px] text-text-muted">
                          {custo.data ? new Date(custo.data + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—'}
                        </p>
                      </>
                    ) : (
                      <p className="text-sm font-medium text-text-muted">
                        {custo.data ? new Date(custo.data + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—'}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-accent-red mono-value">-{formatBRL(Number(custo.valor))}</span>
                  <button
                    onClick={() => setDeleteTarget(custo.id)}
                    className="p-1.5 rounded-lg hover:bg-accent-red/10 text-text-muted hover:text-accent-red transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <AddCostModal isOpen={showAddCost} onClose={() => setShowAddCost(false)} onSubmit={handleAddCost} />

      <ConfirmModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDeleteCost}
        title="Excluir custo?"
        message="Tem certeza que deseja excluir este custo? Essa ação não pode ser desfeita."
        confirmLabel="Excluir"
        loading={deleting}
      />
    </DashboardLayout>
  )
}
