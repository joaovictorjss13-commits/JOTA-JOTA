'use client'

import { useEffect, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import {
  Crown, Users, RefreshCw, Search, Shield, Infinity,
  UserX, Clock, CheckCircle2, XCircle, AlertTriangle,
  ChevronDown, ChevronUp, CalendarDays, Wifi, WifiOff,
  Edit3, Save, Ban, BadgeCheck, Eye, EyeOff, LogIn, LogOut,
  UserPlus, History,
} from 'lucide-react'

// ── Tipos ──────────────────────────────────────────────────
type Plano = 'solo' | 'trial' | 'pro' | 'infinit'
type SubStatus = 'trial' | 'ativa' | 'cancelada' | 'inadimplente'

interface Assinatura {
  id: string
  status: SubStatus
  trial_ends_at: string | null
  vencimento: string | null
  plano: string
  qtd_operadores: number
  valor_mensal: number
  created_at: string
  updated_at: string
}

interface AdminUser {
  id: string
  nome: string
  email: string
  plano: Plano
  created_at: string
  updated_at: string
  assinaturas: Assinatura[]
}

// ── Configs ─────────────────────────────────────────────────
const PLAN_CONFIG: Record<Plano, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  solo:    { label: 'SOLO',    color: '#6b7280', bg: 'rgba(107,114,128,0.12)', border: 'rgba(107,114,128,0.30)', icon: <UserX size={11} /> },
  trial:   { label: 'TRIAL',  color: '#f59e0b', bg: 'rgba(245,158,11,0.12)',  border: 'rgba(245,158,11,0.30)',  icon: <Clock size={11} /> },
  pro:     { label: 'PRO',    color: '#a78bfa', bg: 'rgba(124,58,237,0.12)',  border: 'rgba(124,58,237,0.30)',  icon: <Crown size={11} /> },
  infinit: { label: 'INFINIT',color: '#34d399', bg: 'rgba(16,185,129,0.12)', border: 'rgba(16,185,129,0.30)', icon: <Infinity size={11} /> },
}

const STATUS_CONFIG: Record<SubStatus, { label: string; color: string; dot: string; bg: string; border: string }> = {
  trial:        { label: 'Trial',        color: '#f59e0b', dot: '#f59e0b', bg: 'rgba(245,158,11,0.12)',  border: 'rgba(245,158,11,0.30)'  },
  ativa:        { label: 'Ativa',        color: '#10b981', dot: '#10b981', bg: 'rgba(16,185,129,0.12)', border: 'rgba(16,185,129,0.30)' },
  cancelada:    { label: 'Cancelada',    color: '#6b7280', dot: '#6b7280', bg: 'rgba(107,114,128,0.12)',border: 'rgba(107,114,128,0.30)' },
  inadimplente: { label: 'Inadimplente', color: '#ef4444', dot: '#ef4444', bg: 'rgba(239,68,68,0.12)',  border: 'rgba(239,68,68,0.30)'  },
}

// ── Helpers ─────────────────────────────────────────────────
function daysUntil(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000)
}

function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—'
  return new Date(dateStr).toLocaleDateString('pt-BR')
}

function initials(nome: string) {
  return nome.split(' ').slice(0, 2).map(n => n[0]).join('').toUpperCase()
}

function toInputDate(dateStr: string | null | undefined): string {
  if (!dateStr) return ''
  return dateStr.split('T')[0]
}

// ── PlanBadge ───────────────────────────────────────────────
function PlanBadge({ plan }: { plan: Plano }) {
  const cfg = PLAN_CONFIG[plan] ?? PLAN_CONFIG.solo
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black"
      style={{ color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      {cfg.icon} {cfg.label}
    </span>
  )
}

// ── StatCard ────────────────────────────────────────────────
function StatCard({ label, value, color, icon }: { label: string; value: number; color: string; icon: React.ReactNode }) {
  return (
    <div
      className="flex-1 min-w-[120px] px-4 py-3 rounded-xl flex items-center gap-3"
      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: `rgba(${color},0.15)` }}>
        <span style={{ color: `rgb(${color})` }}>{icon}</span>
      </div>
      <div>
        <p className="text-lg font-black" style={{ color: `rgb(${color})` }}>{value}</p>
        <p className="text-[10px] text-text-muted uppercase tracking-wider">{label}</p>
      </div>
    </div>
  )
}

// ── Tipos extras ────────────────────────────────────────────
interface HistoryEntry { id: string; acao: string; detalhes: Record<string, unknown>; created_at: string }

const ACAO_LABELS: Record<string, string> = {
  plano_alterado: '📋 Plano alterado',
  tempo_adicionado: '⏳ Tempo adicionado',
  vencimento_definido: '📅 Vencimento definido',
  status_alterado: '🔄 Status alterado',
  nome_alterado: '✏️ Nome alterado',
  usuario_criado: '👤 Usuário criado',
}

// ── UserCard ────────────────────────────────────────────────
function UserCard({ user, onUpdate }: { user: AdminUser; onUpdate: (updated: AdminUser) => void }) {
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [customDate, setCustomDate] = useState('')
  const [editNome, setEditNome] = useState(user.nome)
  const [editingNome, setEditingNome] = useState(false)
  const [pendingTime, setPendingTime] = useState<number | null>(null)
  const [showTimePanel, setShowTimePanel] = useState(false)
  const [pendingPlan, setPendingPlan] = useState<Plano | null>(null)
  const [showPlanPanel, setShowPlanPanel] = useState(false)
  const [pendingStatus, setPendingStatus] = useState<SubStatus | null>(null)
  const [toast, setToast] = useState<string | null>(null)

  const ass: Assinatura | null = user.assinaturas?.[0] ?? null
  const planCfg = PLAN_CONFIG[user.plano] ?? PLAN_CONFIG.solo
  const statusCfg = ass ? (STATUS_CONFIG[ass.status] ?? STATUS_CONFIG.cancelada) : STATUS_CONFIG.cancelada

  const dateSource = ass?.status === 'ativa' ? ass?.vencimento : ass?.trial_ends_at
  const days = daysUntil(dateSource)
  const isExpired = days !== null && days <= 0

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(null), 2500)
  }

  async function doAction(body: object, successMsg?: string) {
    setLoading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(`/api/owner/users/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session?.access_token}` },
        body: JSON.stringify(body),
      })
      const json = await res.json()
      if (json.data) {
        onUpdate(json.data)
        if (successMsg) showToast(successMsg)
      }
    } finally {
      setLoading(false)
      setPendingTime(null); setShowTimePanel(false)
      setPendingPlan(null); setShowPlanPanel(false)
      setPendingStatus(null)
    }
  }

  async function handleConfirmTime() {
    if (!pendingTime) return
    await doAction({ type: 'extend_days', days: pendingTime }, `+${pendingTime} dias adicionados`)
  }

  async function handleConfirmPlan() {
    if (!pendingPlan) return
    await doAction({ type: 'set_plan', plan: pendingPlan }, `Plano alterado para ${pendingPlan.toUpperCase()}`)
  }

  async function handleConfirmStatus() {
    if (!pendingStatus) return
    await doAction({ type: 'set_status', status: pendingStatus }, `Status → ${STATUS_CONFIG[pendingStatus].label}`)
  }

  async function handleSetVencimento() {
    if (!customDate) return
    await doAction({ type: 'set_vencimento', date: customDate }, `Vencimento definido: ${formatDate(customDate)}`)
    setCustomDate('')
  }

  async function handleSaveNome() {
    if (!editNome.trim() || editNome.trim() === user.nome) { setEditingNome(false); return }
    await doAction({ type: 'update_nome', nome: editNome }, 'Nome atualizado')
    setEditingNome(false)
  }

  return (
    <div
      className="relative rounded-xl transition-all duration-200"
      style={{
        background: 'rgba(255,255,255,0.025)',
        border: `1px solid ${isExpired && user.plano !== 'solo' ? 'rgba(239,68,68,0.25)' : expanded ? 'rgba(167,139,250,0.25)' : 'rgba(255,255,255,0.07)'}`,
      }}
    >
      {loading && (
        <div className="absolute inset-0 rounded-xl flex items-center justify-center z-10" style={{ background: 'rgba(0,0,0,0.55)' }}>
          <RefreshCw size={18} className="animate-spin text-text-muted" />
        </div>
      )}

      {toast && (
        <div className="absolute top-2 right-2 z-20 px-3 py-1.5 rounded-lg text-[11px] font-semibold" style={{ background: 'rgba(16,185,129,0.90)', color: '#fff' }}>
          {toast}
        </div>
      )}

      {/* Main row */}
      <div className="px-4 py-4 flex items-start gap-3">
        {/* Avatar */}
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-[11px] font-black shrink-0 mt-0.5"
          style={{ background: planCfg.bg, border: `1px solid ${planCfg.border}`, color: planCfg.color }}
        >
          {initials(user.nome)}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-sm truncate">{user.nome}</span>
            <PlanBadge plan={user.plano} />
            {ass && (
              <span className="inline-flex items-center gap-1 text-[10px]" style={{ color: statusCfg.color }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: statusCfg.dot }} />
                {statusCfg.label}
              </span>
            )}
          </div>
          <p className="text-[11px] text-text-muted truncate mt-0.5">{user.email}</p>

          <div className="flex items-center gap-3 mt-2 flex-wrap">
            {user.plano === 'infinit' ? (
              <span className="text-[10px] font-semibold" style={{ color: '#34d399' }}>∞ Acesso ilimitado</span>
            ) : dateSource ? (
              <span
                className="text-[10px] font-semibold"
                style={{ color: isExpired ? '#ef4444' : days !== null && days <= 5 ? '#f59e0b' : '#10b981' }}
              >
                {isExpired ? 'Expirado' : `${days}d restantes`} · vence {formatDate(dateSource)}
              </span>
            ) : (
              <span className="text-[10px] text-text-muted">Sem assinatura ativa</span>
            )}
            <span className="text-[10px] text-text-muted">Cadastro: {formatDate(user.created_at)}</span>
            {ass?.valor_mensal ? (
              <span className="text-[10px] text-text-muted">
                R$ {ass.valor_mensal.toFixed(0)}/mês
              </span>
            ) : null}
          </div>
        </div>

        {/* Quick actions */}
        <div className="flex items-center gap-1.5 shrink-0 flex-wrap justify-end">
          <button
            onClick={() => { setShowTimePanel(v => !v); setShowPlanPanel(false) }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all hover:brightness-110 active:scale-95"
            style={{ background: showTimePanel ? 'rgba(16,185,129,0.20)' : 'rgba(16,185,129,0.12)', color: '#34d399', border: `1px solid ${showTimePanel ? 'rgba(16,185,129,0.40)' : 'rgba(16,185,129,0.25)'}` }}
          >
            <Clock size={11} /> Adicionar tempo
          </button>

          <button
            onClick={() => { setShowPlanPanel(v => !v); setShowTimePanel(false) }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all hover:brightness-110 active:scale-95"
            style={{ background: showPlanPanel ? `${planCfg.bg}` : planCfg.bg, color: planCfg.color, border: `1px solid ${showPlanPanel ? planCfg.color : planCfg.border}` }}
          >
            <Crown size={11} /> Adicionar Plano
          </button>

          <button
            onClick={() => setExpanded(v => !v)}
            className="px-2 py-1 rounded-lg text-[10px] font-bold transition-all hover:brightness-110 active:scale-95"
            style={{ background: expanded ? 'rgba(167,139,250,0.15)' : 'rgba(255,255,255,0.06)', color: expanded ? '#a78bfa' : '#6b7280', border: `1px solid ${expanded ? 'rgba(167,139,250,0.30)' : 'rgba(255,255,255,0.10)'}` }}
            title="Edições avançadas"
          >
            {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
        </div>
      </div>

      {/* Time panel */}
      {showTimePanel && (
        <div className="px-4 py-3 border-t flex items-center gap-2 flex-wrap" style={{ borderColor: 'rgba(255,255,255,0.06)', background: 'rgba(16,185,129,0.03)' }}>
          <span className="text-[10px] text-text-muted mr-1">Selecione:</span>
          {[30, 90, 365].map(d => (
            <button key={d} onClick={() => setPendingTime(d)}
              className="px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
              style={{ background: pendingTime === d ? 'rgba(16,185,129,0.25)' : 'rgba(16,185,129,0.08)', color: '#34d399', border: `1px solid ${pendingTime === d ? 'rgba(16,185,129,0.50)' : 'rgba(16,185,129,0.20)'}` }}
            >+{d}d</button>
          ))}
          <div className="flex-1" />
          {pendingTime && (
            <>
              <button onClick={handleConfirmTime}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                style={{ background: 'rgba(16,185,129,0.20)', color: '#34d399', border: '1px solid rgba(16,185,129,0.40)' }}
              ><Save size={12} /> Salvar</button>
              <button onClick={() => { setPendingTime(null); setShowTimePanel(false) }}
                className="px-2 py-1.5 rounded-lg text-[11px] font-bold text-gray-500 hover:text-white"
              ><XCircle size={12} /></button>
            </>
          )}
        </div>
      )}

      {/* Plan panel */}
      {showPlanPanel && (
        <div className="px-4 py-3 border-t flex items-center gap-2 flex-wrap" style={{ borderColor: 'rgba(255,255,255,0.06)', background: 'rgba(124,58,237,0.03)' }}>
          <span className="text-[10px] text-text-muted mr-1">Selecione:</span>
          {(['solo', 'trial', 'pro', 'infinit'] as Plano[]).map(p => (
            <button key={p} onClick={() => setPendingPlan(p)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
              style={{ background: pendingPlan === p ? PLAN_CONFIG[p].bg : 'rgba(255,255,255,0.04)', color: pendingPlan === p ? PLAN_CONFIG[p].color : '#6b7280', border: `1px solid ${pendingPlan === p ? PLAN_CONFIG[p].border : 'rgba(255,255,255,0.08)'}` }}
            >{PLAN_CONFIG[p].icon} {PLAN_CONFIG[p].label}</button>
          ))}
          <div className="flex-1" />
          {pendingPlan && (
            <>
              <button onClick={handleConfirmPlan}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                style={{ background: 'rgba(124,58,237,0.20)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.40)' }}
              ><Save size={12} /> Salvar</button>
              <button onClick={() => { setPendingPlan(null); setShowPlanPanel(false) }}
                className="px-2 py-1.5 rounded-lg text-[11px] font-bold text-gray-500 hover:text-white"
              ><XCircle size={12} /></button>
            </>
          )}
        </div>
      )}

      {/* Expanded section */}
      {expanded && (
        <div
          className="px-4 pb-4 pt-0 space-y-4 border-t"
          style={{ borderColor: 'rgba(255,255,255,0.06)' }}
        >
          {/* Status de pagamento */}
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-2 mt-3">Status de Pagamento</p>
            <div className="flex flex-wrap gap-2">
              {(['ativa', 'trial', 'inadimplente', 'cancelada'] as SubStatus[]).map(s => {
                const cfg = STATUS_CONFIG[s]
                const isActive = ass?.status === s
                const isPending = pendingStatus === s
                return (
                  <button
                    key={s}
                    onClick={() => setPendingStatus(s === pendingStatus ? null : s)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                    style={{
                      background: isPending ? cfg.bg : isActive ? cfg.bg : 'rgba(255,255,255,0.04)',
                      color: isPending ? cfg.color : isActive ? cfg.color : '#6b7280',
                      border: `1px solid ${isPending ? cfg.color : isActive ? cfg.border : 'rgba(255,255,255,0.08)'}`,
                      outline: isPending ? `2px solid ${cfg.color}` : 'none',
                      outlineOffset: '1px',
                    }}
                  >
                    {s === 'ativa' && <BadgeCheck size={12} />}
                    {s === 'trial' && <Clock size={12} />}
                    {s === 'inadimplente' && <AlertTriangle size={12} />}
                    {s === 'cancelada' && <Ban size={12} />}
                    {cfg.label}
                    {isActive && !isPending && <span className="ml-0.5 opacity-60">✓</span>}
                  </button>
                )
              })}
              {pendingStatus && pendingStatus !== ass?.status && (
                <>
                  <button onClick={handleConfirmStatus}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                    style={{ background: 'rgba(16,185,129,0.20)', color: '#34d399', border: '1px solid rgba(16,185,129,0.40)' }}
                  ><Save size={12} /> Salvar</button>
                  <button onClick={() => setPendingStatus(null)}
                    className="px-2 py-1.5 rounded-lg text-[11px] font-bold text-gray-500 hover:text-white"
                  ><XCircle size={12} /></button>
                </>
              )}
            </div>
          </div>

          {/* Vencimento customizado */}
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-2">Definir Vencimento</p>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customDate}
                onChange={e => setCustomDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="px-3 py-2 rounded-lg text-[12px] bg-white/5 border border-white/10 text-text-primary outline-none focus:border-violet-500/50 transition-colors"
                style={{ colorScheme: 'dark' }}
              />
              {ass?.vencimento && (
                <span className="text-[10px] text-text-muted">
                  Atual: {formatDate(ass.vencimento)}
                </span>
              )}
              <button
                onClick={handleSetVencimento}
                disabled={!customDate}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: 'rgba(96,165,250,0.15)', color: '#60a5fa', border: '1px solid rgba(96,165,250,0.30)' }}
              >
                <CalendarDays size={12} /> Definir
              </button>
            </div>
          </div>

          {/* Editar nome */}
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-2">Nome do Usuário</p>
            <div className="flex items-center gap-2">
              {editingNome ? (
                <>
                  <input
                    type="text"
                    value={editNome}
                    onChange={e => setEditNome(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') handleSaveNome(); if (e.key === 'Escape') setEditingNome(false) }}
                    className="flex-1 px-3 py-2 rounded-lg text-[12px] bg-white/5 border border-violet-500/50 text-text-primary outline-none transition-colors"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveNome}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                    style={{ background: 'rgba(16,185,129,0.15)', color: '#34d399', border: '1px solid rgba(16,185,129,0.30)' }}
                  >
                    <Save size={12} /> Salvar
                  </button>
                  <button
                    onClick={() => { setEditingNome(false); setEditNome(user.nome) }}
                    className="px-3 py-2 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                    style={{ background: 'rgba(255,255,255,0.05)', color: '#6b7280', border: '1px solid rgba(255,255,255,0.10)' }}
                  >
                    <XCircle size={12} />
                  </button>
                </>
              ) : (
                <>
                  <span className="text-sm font-semibold flex-1">{user.nome}</span>
                  <button
                    onClick={() => setEditingNome(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-bold transition-all hover:brightness-110 active:scale-95"
                    style={{ background: 'rgba(255,255,255,0.05)', color: '#94a3b8', border: '1px solid rgba(255,255,255,0.10)' }}
                  >
                    <Edit3 size={12} /> Editar nome
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Info extra */}
          {ass && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {[
                { label: 'ID Assinatura', value: ass.id.slice(0, 8) + '…' },
                { label: 'Operadores', value: String(ass.qtd_operadores || 0) },
                { label: 'Valor/mês', value: ass.valor_mensal ? `R$ ${ass.valor_mensal.toFixed(2)}` : '—' },
                { label: 'Criado em', value: formatDate(ass.created_at) },
              ].map(item => (
                <div key={item.label} className="px-3 py-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
                  <p className="text-[9px] text-text-muted uppercase tracking-wider">{item.label}</p>
                  <p className="text-[11px] font-semibold mt-0.5">{item.value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Histórico de alterações */}
          <HistoryPanel userId={user.id} />
        </div>
      )}
    </div>
  )
}

// ── HistoryPanel ─────────────────────────────────────────────
function HistoryPanel({ userId }: { userId: string }) {
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)

  async function fetchHistory() {
    if (history.length > 0) { setOpen(v => !v); return }
    setLoading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(`/api/owner/users/${userId}`, {
        headers: { 'Authorization': `Bearer ${session?.access_token}` },
      })
      const json = await res.json()
      setHistory(json.data || [])
      setOpen(true)
    } finally { setLoading(false) }
  }

  function formatDetail(acao: string, det: Record<string, unknown>) {
    if (acao === 'plano_alterado') return `${String(det.de || '?').toUpperCase()} → ${String(det.para || '?').toUpperCase()}`
    if (acao === 'tempo_adicionado') return `+${det.dias}d · Novo venc: ${formatDate(det.novo_vencimento as string)}`
    if (acao === 'status_alterado') return `${det.de || '?'} → ${det.para || '?'}`
    if (acao === 'nome_alterado') return `${det.de || '?'} → ${det.para || '?'}`
    if (acao === 'vencimento_definido') return `${formatDate(det.data as string)}`
    if (acao === 'usuario_criado') return `${det.nome} (${det.plano})`
    return JSON.stringify(det)
  }

  return (
    <div>
      <button onClick={fetchHistory}
        className="flex items-center gap-1.5 text-[10px] text-text-muted uppercase tracking-wider hover:text-white transition-colors mt-1"
      >
        {loading ? <RefreshCw size={11} className="animate-spin" /> : <History size={11} />}
        {open ? 'Ocultar histórico' : 'Ver histórico de alterações'}
      </button>
      {open && (
        <div className="mt-2 space-y-1 max-h-48 overflow-y-auto pr-1">
          {history.length === 0 ? (
            <p className="text-[10px] text-text-muted italic">Nenhuma alteração registrada</p>
          ) : history.map(h => (
            <div key={h.id} className="flex items-start gap-2 px-3 py-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
              <span className="text-[10px] shrink-0">{ACAO_LABELS[h.acao] || h.acao}</span>
              <span className="text-[10px] text-text-muted flex-1">{formatDetail(h.acao, h.detalhes)}</span>
              <span className="text-[9px] text-text-muted shrink-0">{new Date(h.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ── CreateUserModal ──────────────────────────────────────────
function CreateUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: (u: AdminUser) => void }) {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [plano, setPlano] = useState<Plano>('solo')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch('/api/owner/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session?.access_token}` },
        body: JSON.stringify({ nome, email, senha, plano }),
      })
      const json = await res.json()
      if (!res.ok) { setError(json.error || 'Erro ao criar'); return }
      onCreated(json.data)
      onClose()
    } finally { setLoading(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4" style={{ background: 'rgba(0,0,0,0.70)' }} onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl p-6 space-y-4" style={{ background: '#0d0d1a', border: '1px solid rgba(167,139,250,0.25)' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-base font-black flex items-center gap-2"><UserPlus size={18} style={{ color: '#a78bfa' }} /> Adicionar Usuário</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><XCircle size={18} /></button>
        </div>
        <form onSubmit={handleCreate} className="space-y-3">
          <div>
            <label className="text-[10px] text-text-muted uppercase tracking-wider block mb-1">Nome</label>
            <input type="text" value={nome} onChange={e => setNome(e.target.value)} required placeholder="Nome completo"
              className="w-full px-3 py-2 rounded-lg text-sm bg-white/5 border border-white/10 text-white outline-none focus:border-violet-500/50" />
          </div>
          <div>
            <label className="text-[10px] text-text-muted uppercase tracking-wider block mb-1">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="email@exemplo.com"
              className="w-full px-3 py-2 rounded-lg text-sm bg-white/5 border border-white/10 text-white outline-none focus:border-violet-500/50" />
          </div>
          <div>
            <label className="text-[10px] text-text-muted uppercase tracking-wider block mb-1">Senha</label>
            <input type="text" value={senha} onChange={e => setSenha(e.target.value)} required placeholder="Mínimo 8 caracteres"
              className="w-full px-3 py-2 rounded-lg text-sm bg-white/5 border border-white/10 text-white outline-none focus:border-violet-500/50" />
          </div>
          <div>
            <label className="text-[10px] text-text-muted uppercase tracking-wider block mb-1">Plano</label>
            <div className="flex gap-2">
              {(['solo', 'trial', 'pro', 'infinit'] as Plano[]).map(p => (
                <button key={p} type="button" onClick={() => setPlano(p)}
                  className="flex-1 flex items-center justify-center gap-1 px-2 py-2 rounded-lg text-[11px] font-bold transition-all"
                  style={{ background: plano === p ? PLAN_CONFIG[p].bg : 'rgba(255,255,255,0.04)', color: plano === p ? PLAN_CONFIG[p].color : '#6b7280', border: `1px solid ${plano === p ? PLAN_CONFIG[p].border : 'rgba(255,255,255,0.08)'}` }}
                >{PLAN_CONFIG[p].icon} {PLAN_CONFIG[p].label}</button>
              ))}
            </div>
          </div>
          {error && <p className="text-[12px] text-red-400 flex items-center gap-1"><XCircle size={13} /> {error}</p>}
          <button type="submit" disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all hover:brightness-110 active:scale-95 disabled:opacity-50"
            style={{ background: 'rgba(124,58,237,0.80)', color: '#fff' }}
          >
            {loading ? <RefreshCw size={14} className="animate-spin" /> : <UserPlus size={14} />}
            {loading ? 'Criando...' : 'Criar Usuário'}
          </button>
        </form>
      </div>
    </div>
  )
}

// ── OwnerLogin ───────────────────────────────────────────────
function OwnerLogin({ onSuccess }: { onSuccess: () => void }) {
  const [email, setEmail] = useState('contato.metacontroll@gmail.com')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error: err } = await supabase.auth.signInWithPassword({ email, password })
    if (err) {
      setError('Email ou senha incorretos.')
      setLoading(false)
      return
    }
    onSuccess()
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: '#07070f' }}>
      <div
        className="w-full max-w-sm rounded-2xl p-8 space-y-6"
        style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(167,139,250,0.20)' }}
      >
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.30)' }}>
            <Shield size={22} style={{ color: '#a78bfa' }} />
          </div>
          <h1 className="text-lg font-black text-white">Owner Control</h1>
          <p className="text-xs text-text-muted">Acesso restrito ao administrador</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3">
          <div>
            <label className="text-[11px] text-text-muted uppercase tracking-wider block mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2.5 rounded-xl text-sm bg-white/5 border border-white/10 text-white outline-none focus:border-violet-500/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-[11px] text-text-muted uppercase tracking-wider block mb-1.5">Senha</label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                autoFocus
                placeholder="••••••••••••"
                className="w-full px-3 py-2.5 pr-10 rounded-xl text-sm bg-white/5 border border-white/10 text-white outline-none focus:border-violet-500/60 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPw(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-white transition-colors"
              >
                {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-[12px] text-red-400 flex items-center gap-1.5">
              <XCircle size={13} /> {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all hover:brightness-110 active:scale-95 disabled:opacity-50"
            style={{ background: 'rgba(124,58,237,0.80)', color: '#fff' }}
          >
            {loading ? <RefreshCw size={14} className="animate-spin" /> : <LogIn size={14} />}
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>
      </div>
    </div>
  )
}

// ── Page ─────────────────────────────────────────────────────
export default function OwnerControlPage() {
  const [authState, setAuthState] = useState<'checking' | 'login' | 'forbidden' | 'ready'>('checking')
  const [users, setUsers] = useState<AdminUser[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [planFilter, setPlanFilter] = useState<Plano | 'todos'>('todos')
  const [statusFilter, setStatusFilter] = useState<SubStatus | 'todos'>('todos')
  const [realtime, setRealtime] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [showCreateUser, setShowCreateUser] = useState(false)

  const fetchUsers = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) { setAuthState('login'); return }

    const res = await fetch('/api/owner/users', {
      headers: { 'Authorization': `Bearer ${session.access_token}` },
    })
    if (res.status === 403) {
      // Sessão de outro usuário — faz logout e mostra login owner
      await supabase.auth.signOut()
      setAuthState('login')
      return
    }
    const json = await res.json()
    if (json.data) {
      setUsers(json.data)
      setLastUpdate(new Date())
      setAuthState('ready')
    }
    setLoading(false)
  }, [])

  useEffect(() => { fetchUsers() }, [fetchUsers])

  useEffect(() => {
    if (authState !== 'ready') return
    const channel = supabase
      .channel('owner-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'admins' }, () => fetchUsers())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'assinaturas' }, () => fetchUsers())
      .subscribe(status => setRealtime(status === 'SUBSCRIBED'))

    return () => { supabase.removeChannel(channel) }
  }, [authState, fetchUsers])

  async function handleLogout() {
    await supabase.auth.signOut()
    setAuthState('login')
    setUsers([])
  }

  function handleUpdate(updated: AdminUser) {
    setUsers(prev => prev.map(u => u.id === updated.id ? updated : u))
    setLastUpdate(new Date())
  }

  // ── Auth states ──
  if (authState === 'checking') {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#07070f' }}>
        <RefreshCw size={22} className="animate-spin text-text-muted" />
      </div>
    )
  }

  if (authState === 'login') {
    return <OwnerLogin onSuccess={() => { setLoading(true); fetchUsers() }} />
  }

  if (authState === 'forbidden') {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4" style={{ background: '#07070f', color: '#e2e8f0' }}>
        <XCircle size={40} style={{ color: '#ef4444' }} />
        <p className="font-bold text-lg">Acesso negado</p>
        <p className="text-sm text-text-muted">Este email não tem permissão de owner.</p>
        <button onClick={handleLogout} className="text-xs text-text-muted hover:text-white flex items-center gap-1.5 mt-2">
          <LogOut size={13} /> Sair e tentar outro email
        </button>
      </div>
    )
  }

  const filtered = users.filter(u => {
    const matchSearch = !search || u.nome.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
    const matchPlan = planFilter === 'todos' || u.plano === planFilter
    const ass = u.assinaturas?.[0]
    const matchStatus = statusFilter === 'todos' || ass?.status === statusFilter
    return matchSearch && matchPlan && matchStatus
  })

  const stats = {
    total:        users.length,
    trial:        users.filter(u => u.plano === 'trial').length,
    pro:          users.filter(u => u.plano === 'pro').length,
    infinit:      users.filter(u => u.plano === 'infinit').length,
    solo:         users.filter(u => u.plano === 'solo').length,
    ativa:        users.filter(u => u.assinaturas?.[0]?.status === 'ativa').length,
    inadimplente: users.filter(u => u.assinaturas?.[0]?.status === 'inadimplente').length,
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#07070f' }}>
        <div className="flex flex-col items-center gap-3">
          <RefreshCw size={24} className="animate-spin text-text-muted" />
          <p className="text-sm text-text-muted">Carregando painel owner...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen px-4 py-6 md:px-8" style={{ background: '#07070f', color: '#e2e8f0' }}>
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield size={20} style={{ color: '#a78bfa' }} />
              <h1 className="text-xl font-black">Owner Control</h1>
              <span
                className="text-[9px] font-black px-2 py-0.5 rounded-full"
                style={{ background: 'rgba(124,58,237,0.15)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.30)' }}
              >
                RESTRITO
              </span>
            </div>
            <p className="text-xs text-text-muted">
              Gerenciamento em tempo real ·{' '}
              <span style={{ color: realtime ? '#10b981' : '#6b7280' }}>
                {realtime ? <><Wifi size={10} className="inline mb-0.5" /> ao vivo</> : <><WifiOff size={10} className="inline mb-0.5" /> offline</>}
              </span>
              {' '}· {lastUpdate.toLocaleTimeString('pt-BR')}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCreateUser(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:brightness-110 active:scale-95"
              style={{ background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.30)', color: '#a78bfa' }}
            >
              <UserPlus size={13} /> Adicionar
            </button>
            <button
              onClick={fetchUsers}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:brightness-110 active:scale-95"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.10)', color: '#94a3b8' }}
            >
              <RefreshCw size={13} /> Atualizar
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:brightness-110 active:scale-95"
              style={{ background: 'rgba(239,68,68,0.10)', border: '1px solid rgba(239,68,68,0.20)', color: '#f87171' }}
              title="Sair"
            >
              <LogOut size={13} />
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-3">
          <StatCard label="Total"        value={stats.total}        color="96,165,250"  icon={<Users size={16} />} />
          <StatCard label="Trial"        value={stats.trial}        color="245,158,11"  icon={<Clock size={16} />} />
          <StatCard label="PRO"          value={stats.pro}          color="167,139,250" icon={<Crown size={16} />} />
          <StatCard label="Infinit"      value={stats.infinit}      color="52,211,153"  icon={<Infinity size={16} />} />
          <StatCard label="Solo"         value={stats.solo}         color="107,114,128" icon={<UserX size={16} />} />
          <StatCard label="Pagantes"     value={stats.ativa}        color="34,197,94"   icon={<CheckCircle2 size={16} />} />
          <StatCard label="Inadimplente" value={stats.inadimplente} color="239,68,68"   icon={<AlertTriangle size={16} />} />
        </div>

        {/* Toolbar */}
        <div className="flex flex-col gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por nome ou email..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm bg-white/5 border border-white/10 text-text-primary placeholder-text-muted outline-none focus:border-violet-500/50 transition-colors"
            />
          </div>

          <div className="flex gap-1.5 flex-wrap">
            <span className="text-[10px] text-text-muted self-center mr-1">Plano:</span>
            {(['todos', 'trial', 'pro', 'infinit', 'solo'] as const).map(f => (
              <button
                key={f}
                onClick={() => setPlanFilter(f)}
                className="px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all"
                style={planFilter === f ? {
                  background: f === 'todos' ? 'rgba(96,165,250,0.20)' : PLAN_CONFIG[f as Plano]?.bg,
                  color: f === 'todos' ? '#60a5fa' : PLAN_CONFIG[f as Plano]?.color,
                  border: `1px solid ${f === 'todos' ? 'rgba(96,165,250,0.40)' : PLAN_CONFIG[f as Plano]?.border}`,
                } : {
                  background: 'rgba(255,255,255,0.04)',
                  color: '#6b7280',
                  border: '1px solid rgba(255,255,255,0.07)',
                }}
              >
                {f === 'todos' ? 'Todos' : f.toUpperCase()}
                {f !== 'todos' && <span className="ml-1 opacity-60">{stats[f as keyof typeof stats]}</span>}
              </button>
            ))}
          </div>

          <div className="flex gap-1.5 flex-wrap">
            <span className="text-[10px] text-text-muted self-center mr-1">Status:</span>
            {(['todos', 'ativa', 'trial', 'inadimplente', 'cancelada'] as const).map(f => {
              const cfg = f !== 'todos' ? STATUS_CONFIG[f as SubStatus] : null
              const isActive = statusFilter === f
              return (
                <button
                  key={f}
                  onClick={() => setStatusFilter(f)}
                  className="px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all"
                  style={isActive ? {
                    background: f === 'todos' ? 'rgba(96,165,250,0.20)' : cfg?.bg,
                    color: f === 'todos' ? '#60a5fa' : cfg?.color,
                    border: `1px solid ${f === 'todos' ? 'rgba(96,165,250,0.40)' : cfg?.border}`,
                  } : {
                    background: 'rgba(255,255,255,0.04)',
                    color: '#6b7280',
                    border: '1px solid rgba(255,255,255,0.07)',
                  }}
                >
                  {f === 'todos' ? 'Todos' : cfg?.label}
                </button>
              )
            })}
          </div>
        </div>

        {/* User list */}
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="py-16 flex flex-col items-center gap-2 text-text-muted">
              <Users size={32} className="opacity-30" />
              <p className="text-sm">Nenhum usuário encontrado</p>
            </div>
          ) : (
            filtered.map(u => (
              <UserCard key={u.id} user={u} onUpdate={handleUpdate} />
            ))
          )}
        </div>

        <p className="text-center text-[10px] text-text-muted pb-4">
          {filtered.length} de {users.length} usuários · MetaControll Owner Panel
        </p>
      </div>

      {showCreateUser && (
        <CreateUserModal
          onClose={() => setShowCreateUser(false)}
          onCreated={(u) => { setUsers(prev => [u, ...prev]); setLastUpdate(new Date()) }}
        />
      )}
    </div>
  )
}
