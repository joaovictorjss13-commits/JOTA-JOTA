import type { Metadata, Viewport } from 'next'
import './globals.css'
import { AppSplash } from '@/components/layout/AppSplash'
import { SecurityGuard } from '@/components/layout/SecurityGuard'

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#07070f',
}

export const metadata: Metadata = {
  title: 'MetaControll',
  description: 'Plataforma SaaS de gestão de operações para afiliados e gestores iGaming. Controle financeiro em tempo real, acompanhamento de metas e relatórios de performance.',
  keywords: ['igaming', 'gestão', 'afiliados', 'metas', 'controle financeiro', 'operações'],
  manifest: '/manifest.json',
  icons: {
    icon: '/logo.png',
    apple: '/logo.png',
    shortcut: '/logo.png',
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'MetaControll',
    startupImage: '/logo.png',
  },
  formatDetection: { telephone: false },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Rajdhani:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
        {/* iOS Safari PWA meta tags */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="MetaControll" />
        <link rel="apple-touch-icon" href="/logo.png" />
      </head>
      <body className="bg-bg-primary text-text-primary antialiased">
        <SecurityGuard />
        <AppSplash />
        {children}
      </body>
    </html>
  )
}
