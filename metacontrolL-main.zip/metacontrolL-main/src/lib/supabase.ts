// src/lib/supabase.ts
// Cliente Supabase para o browser (anon key) — seguro para importar em componentes client
// Para o cliente admin (service role), use @/lib/supabase-admin.server (server-only)

import { createClient } from '@supabase/supabase-js'

const url  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(url, anon)

export async function getUser() {
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error || !user) return null
  return user
}

export async function getAdminId(): Promise<string | null> {
  const user = await getUser()
  return user?.id ?? null
}
