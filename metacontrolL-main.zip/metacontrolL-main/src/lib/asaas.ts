function getConfig() {
  const key = process.env.ASAAS_API_KEY
  if (!key) throw new Error('ASAAS_API_KEY não está definida nas variáveis de ambiente do servidor.')

  // ASAAS_BASE_URL deve ser a URL base completa da API, sem barra final
  // Sandbox:   https://sandbox.asaas.com/api/v3
  // Produção:  https://api.asaas.com/v3
  const base = (process.env.ASAAS_BASE_URL ?? 'https://sandbox.asaas.com/api/v3').replace(/\/$/, '')

  return { key, base }
}

async function asaasRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const { key, base } = getConfig()
  const fullUrl = `${base}${path}`

  const res = await fetch(fullUrl, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'access_token': key.trim(),
      ...options.headers,
    },
  })

  const text = await res.text()

  if (!text) {
    throw new Error(`Asaas retornou resposta vazia (HTTP ${res.status}) em ${fullUrl}. Verifique ASAAS_API_KEY e ASAAS_BASE_URL.`)
  }

  let data: any
  try {
    data = JSON.parse(text)
  } catch {
    throw new Error(`Resposta inesperada do Asaas (HTTP ${res.status}): ${text.slice(0, 300)}`)
  }

  if (!res.ok) {
    const msg = data?.errors?.[0]?.description ?? data?.message ?? `Erro Asaas HTTP ${res.status}`
    throw new Error(msg)
  }

  return data as T
}

export interface AsaasCustomer { id: string; name: string; cpfCnpj: string }
export interface AsaasCharge   { id: string; status: string; value: number; billingType: string; dueDate: string; invoiceUrl: string }
export interface AsaasPixQrCode { encodedImage: string; payload: string; expirationDate: string }

// Gera um CPF matematicamente válido usando crypto para evitar colisões
export function gerarCpf(): string {
  const r = () => crypto.getRandomValues(new Uint8Array(1))[0] % 9
  const n = Array.from({ length: 9 }, r)

  let s = n.reduce((acc, v, i) => acc + v * (10 - i), 0)
  const d1 = (s * 10) % 11 >= 10 ? 0 : (s * 10) % 11
  n.push(d1)

  s = n.reduce((acc, v, i) => acc + v * (11 - i), 0)
  const d2 = (s * 10) % 11 >= 10 ? 0 : (s * 10) % 11
  n.push(d2)

  return n.join('')
}

export async function findOrCreateCustomer(params: {
  name: string
  cpfCnpj: string
  email?: string
}): Promise<AsaasCustomer> {
  const list = await asaasRequest<{ data: AsaasCustomer[] }>(
    `/customers?cpfCnpj=${params.cpfCnpj}`
  )
  if (list.data.length > 0) return list.data[0]

  return asaasRequest<AsaasCustomer>('/customers', {
    method: 'POST',
    body: JSON.stringify(params),
  })
}

export async function createPixCharge(params: {
  customer: string
  value: number
  dueDate: string
  description?: string
  externalReference?: string
}): Promise<AsaasCharge> {
  return asaasRequest<AsaasCharge>('/payments', {
    method: 'POST',
    body: JSON.stringify({ ...params, billingType: 'PIX' }),
  })
}

export async function getPixQrCode(chargeId: string): Promise<AsaasPixQrCode> {
  return asaasRequest<AsaasPixQrCode>(`/payments/${chargeId}/pixQrCode`)
}
