export const COST_TYPES = {
  proxy:       { label: 'Proxy',        color: 'bg-accent-blue/15 text-accent-blue' },
  sms:         { label: 'SMS',          color: 'bg-accent-green/15 text-accent-green' },
  assinaturas: { label: 'Assinaturas',  color: 'bg-accent-red/15 text-accent-red' },
  bot:         { label: 'Bot',          color: 'bg-accent-yellow/15 text-accent-yellow' },
  vps:         { label: 'VPS',          color: 'bg-accent-lime/15 text-accent-lime' },
  outros:      { label: 'Outros',       color: 'bg-bg-surface-light text-text-secondary' },
} as const

export type CostTypeKey = keyof typeof COST_TYPES

export const costTypeList = Object.entries(COST_TYPES).map(([value, { label }]) => ({ value, label }))
