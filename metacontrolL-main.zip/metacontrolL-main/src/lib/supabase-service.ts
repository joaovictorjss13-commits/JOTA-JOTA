// src/lib/supabase-service.ts
// Service layer — acesso direto ao Supabase via client-side SDK
// O RLS garante segurança: cada admin vê apenas seus dados

import { supabase } from './supabase'

// ════════════════════════════════════════════════════════════
// AUTH
// ════════════════════════════════════════════════════════════

export async function signUp(email: string, password: string, nome: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { nome, plano: 'solo' },
    },
  })
  if (error) throw new Error(error.message)
  return data
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw new Error(error.message)
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw new Error(error.message)
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser()
  return user
}

// ════════════════════════════════════════════════════════════
// METAS
// ════════════════════════════════════════════════════════════

export async function createMeta(input: {
  titulo: string
  plataforma: string
  rede_sigla?: string
  contas_total: number
  modelo: 'salario_bau' | 'apenas_bau'
}) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Não autenticado')

  const { data, error } = await supabase
    .from('metas')
    .insert({
      admin_id: user.id,
      titulo: input.titulo,
      plataforma: input.plataforma,
      rede_sigla: input.rede_sigla || '',
      contas_total: input.contas_total,
      modelo: input.modelo,
      status: 'ativa',
    } as any)
    .select('*')
    .single()

  if (error) throw new Error(error.message)
  return data as any
}

export async function updateMeta(id: string, data: {
  titulo: string
  rede_sigla: string
  contas_total: number
  plataforma: string
  notas?: string
}) {
  const { error } = await supabase
    .from('metas')
    .update({ ...data, updated_at: new Date().toISOString() })
    .eq('id', id)
  if (error) throw new Error(error.message)
}

export async function getMetas(status?: string) {
  let query = supabase
    .from('metas')
    .select('*')
    .order('created_at', { ascending: false })

  if (status) {
    query = query.eq('status', status)
  } else {
    query = query.neq('status', 'lixeira')
  }

  const { data, error } = await query
  if (error) throw new Error(error.message)
  return (data || []) as any[]
}

export async function getMetaById(id: string) {
  const { data, error } = await supabase
    .from('metas')
    .select('*')
    .eq('id', id)
    .single()

  if (error) throw new Error(error.message)
  return data as any
}

export async function updateMetaStatus(id: string, action: 'finalizar' | 'fechar' | 'reativar' | 'lixeira', extra?: {
  salario?: number
  bau?: number
  gastos_operacionais?: number
}) {
  const updates: Record<string, any> = {}

  switch (action) {
    case 'finalizar':
      updates.status = 'finalizada'
      break
    case 'fechar':
      updates.status = 'fechada'
      if (extra) {
        updates.salario = extra.salario || 0
        updates.bau = extra.bau || 0
        updates.gastos_operacionais = extra.gastos_operacionais || 0
      }
      break
    case 'reativar':
      updates.status = 'ativa'
      updates.fechada_at = null
      updates.finalizada_at = null
      break
    case 'lixeira':
      updates.status = 'lixeira'
      break
  }

  const { data, error } = await supabase
    .from('metas')
    .update(updates)
    .eq('id', id)
    .select('*')
    .single()

  if (error) throw new Error(error.message)
  return data as any
}

export async function deleteMeta(id: string) {
  return updateMetaStatus(id, 'lixeira')
}

export async function permanentDeleteMeta(id: string) {
  const { error } = await supabase.from('metas').delete().eq('id', id)
  if (error) throw new Error(error.message)
}

export async function saveMetaCosts(id: string, costs: { salario: number; bau: number; custo_fixo: number; taxa_agente: number }) {
  const { error } = await supabase
    .from('metas')
    .update({
      salario: costs.salario,
      bau: costs.bau,
      gastos_operacionais: costs.custo_fixo + costs.taxa_agente,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
  if (error) throw new Error(error.message)
}

// ════════════════════════════════════════════════════════════
// REMESSAS
// ════════════════════════════════════════════════════════════

// Maps UI labels → DB enum values
const STATUS_MAP: Record<string, string> = {
  normal:    'normal',
  Normal:    'normal',
  pendente:  'pendente',
  Pendente:  'pendente',
  bloqueado: 'bloqueado',
  Bloqueado: 'bloqueado',
  analise:   'analise',
  'Análise': 'analise',
  analise_:  'analise',
  // legacy values → map to closest
  perdeu:    'normal',
  bloqueio:  'bloqueado',
  noite:     'normal',
}

function normalizeStatus(s?: string): string {
  if (!s) return 'normal'
  return STATUS_MAP[s] ?? s.toLowerCase().replace(/[^a-z]/g, '') ?? 'normal'
}

export async function createRemessa(input: {
  meta_id: string
  titulo?: string
  tipo?: string
  saldo_ini?: number
  contas: number
  deposito: number
  saque: number
  status?: string
  notas?: string
}) {
  const { data, error } = await supabase
    .from('remessas')
    .insert({
      meta_id: input.meta_id,
      titulo: input.titulo || null,
      tipo: (input.tipo || 'remessa') as any,
      saldo_ini: input.saldo_ini || 0,
      contas: input.contas,
      deposito: input.deposito,
      saque: input.saque,
      status: normalizeStatus(input.status) as any,
      notas: input.notas || null,
    })
    .select('*')
    .single()

  if (error) throw new Error(error.message)
  return data as any
}

export async function getRemessas(metaId: string) {
  const { data, error } = await supabase
    .from('remessas')
    .select('*')
    .eq('meta_id', metaId)
    .order('created_at', { ascending: false })

  if (error) throw new Error(error.message)
  return (data || []) as any[]
}

export async function deleteRemessa(id: string) {
  const { error } = await supabase
    .from('remessas')
    .delete()
    .eq('id', id)

  if (error) throw new Error(error.message)
}

export async function updateRemessaStatus(id: string, status: string) {
  const { error } = await supabase
    .from('remessas')
    .update({ status: normalizeStatus(status) as any })
    .eq('id', id)

  if (error) throw new Error(error.message)
}

// ════════════════════════════════════════════════════════════
// CUSTOS
// ════════════════════════════════════════════════════════════

export async function getCustos() {
  const { data, error } = await supabase
    .from('custos')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw new Error(error.message)
  return (data || []) as any[]
}

export async function addCusto(input: {
  tipo: string
  valor: number
  data?: string
  nota?: string
}) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Não autenticado')

  const { data, error } = await supabase
    .from('custos')
    .insert({
      admin_id: user.id,
      tipo: input.tipo as any,
      valor: input.valor,
      data: input.data || new Date().toISOString().split('T')[0],
      nota: input.nota || null,
    })
    .select('*')
    .single()

  if (error) throw new Error(error.message)
  return data as any
}

export async function deleteCusto(id: string) {
  const { error } = await supabase
    .from('custos')
    .delete()
    .eq('id', id)

  if (error) throw new Error(error.message)
}

// ════════════════════════════════════════════════════════════
// DASHBOARD (dados agregados)
// ════════════════════════════════════════════════════════════

function buildDateRange(filtro: string): { gte?: string; lt?: string } {
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  switch (filtro) {
    case 'Hoje':
      return { gte: today.toISOString() }
    case 'Ontem': {
      const start = new Date(today); start.setDate(start.getDate() - 1)
      return { gte: start.toISOString(), lt: today.toISOString() }
    }
    case '7d':
      return { gte: new Date(today.getTime() - 7 * 86400000).toISOString() }
    case '30d':
      return { gte: new Date(today.getTime() - 30 * 86400000).toISOString() }
    default:
      return {}
  }
}

export async function getDashboardData(filtro: string = 'Tudo') {
  const user = await getCurrentUser()
  if (!user) throw new Error('Não autenticado')

  const range = buildDateRange(filtro)

  // Busca remessas do período (normal + bloqueado) e análise de IA em paralelo
  let remessasQuery = supabase
    .from('remessas')
    .select('*')
    .in('status', ['normal', 'bloqueado'])
    .order('created_at', { ascending: false })

  if (range.gte) remessasQuery = remessasQuery.gte('created_at', range.gte)
  if (range.lt)  remessasQuery = remessasQuery.lt('created_at', range.lt)

  const [metasRes, remessasRes, adminRes, analiseRes] = await Promise.all([
    supabase
      .from('metas')
      .select('*')
      .neq('status', 'lixeira')
      .order('created_at', { ascending: false }),
    remessasQuery,
    supabase.from('admins').select('nome').eq('id', user.id).single(),
    supabase.rpc('analise_probabilistica', { p_admin_id: user.id }),
  ])

  const metas     = (metasRes.data    || []) as any[]
  const remessas  = (remessasRes.data || []) as any[]
  const adminNome = adminRes.data?.nome || 'Admin'
  const analise   = analiseRes.data?.[0] || null

  const normalRemessas    = remessas.filter((r: any) => r.status === 'normal')
  const bloqueadoRemessas = remessas.filter((r: any) => r.status === 'bloqueado')

  const metasMap = Object.fromEntries(metas.map(m => [m.id, m]))

  // ── Totais financeiros ──────────────────────────────────────
  // deposito_display = normal + bloqueado (todo dinheiro enviado)
  // lucro_bruto      = saque_normal - deposito_normal (antes das perdas de bloqueio)
  // resultado        = saque - deposito_normal - bloqueado = lucro líquido
  let deposito_normal: number
  let bloqueado_total: number
  let saque_total: number
  let lucro_bruto: number
  let resultado: number
  let taxa_acerto: number
  let metas_filtradas: any[]

  if (filtro === 'Tudo') {
    deposito_normal  = metas.reduce((a, m) => a + Number(m.deposito_total   || 0), 0)
    bloqueado_total  = metas.reduce((a, m) => a + Number(m.bloqueado_total  || 0), 0)
    saque_total      = metas.reduce((a, m) => a + Number(m.saque_total      || 0), 0)
    lucro_bruto      = metas.reduce((a, m) => a + Number(m.lucro_bruto      || 0), 0)
    resultado        = metas.reduce((a, m) => a + Number(m.resultado_liquido || 0), 0)
    taxa_acerto      = metas.length > 0
      ? Math.round(metas.filter(m => Number(m.resultado_liquido || 0) > 0).length / metas.length * 100)
      : 0
    metas_filtradas  = metas
  } else {
    deposito_normal  = normalRemessas.reduce((a: number, r: any) => a + Number(r.deposito || 0), 0)
    bloqueado_total  = bloqueadoRemessas.reduce((a: number, r: any) => a + Number(r.deposito || 0), 0)
    saque_total      = normalRemessas.reduce((a: number, r: any) => a + Number(r.saque    || 0), 0)
    lucro_bruto      = saque_total - deposito_normal
    resultado        = saque_total - deposito_normal - bloqueado_total
    // taxa_acerto por período: % de remessas normais lucrativas
    taxa_acerto      = normalRemessas.length > 0
      ? Math.round(
          normalRemessas.filter((r: any) => Number(r.saque || 0) > Number(r.deposito || 0)).length
          / normalRemessas.length * 100
        )
      : 0
    // Metas que tiveram atividade no período (para o chart de performance)
    const metaIdsNoPeriodo = new Set(remessas.map((r: any) => r.meta_id))
    metas_filtradas = metas.filter(m => metaIdsNoPeriodo.has(m.id))
  }

  const deposito_total = deposito_normal + bloqueado_total

  const metas_fechadas = metas.filter(m => m.status === 'fechada' || m.status === 'finalizada').length
  const total_metas    = metas.length
  const casas_ativas   = new Set(metas.filter(m => m.status === 'ativa').map(m => m.plataforma)).size

  // Breakdown por status (tags de remessa) — usa remessas do período
  const breakdown_normal    = deposito_normal
  const breakdown_bloqueado = bloqueado_total
  const breakdown_pendente  = 0 // pendente não é carregado na query; reservado para exibição futura

  return {
    lucro_acumulado:   resultado,
    deposito_total,
    deposito_normal,
    bloqueado_total,
    saque_total,
    lucro_bruto,
    taxa_acerto,
    total_metas,
    metas_fechadas,
    casas_ativas,
    total_depositantes: metas.reduce((a, m) => a + Number(m.contas_atingidas || 0), 0),
    status: resultado > 0 ? 'positivo' : resultado < 0 ? 'negativo' : 'neutro',
    breakdown: { normal: breakdown_normal, bloqueado: breakdown_bloqueado, pendente: breakdown_pendente },
    analise,
    remessas_recentes: normalRemessas.slice(0, 5).map((r: any) => ({
      operador_nome: adminNome,
      rede_sigla: metasMap[r.meta_id]?.plataforma || '—',
      resultado: Number(r.saque) - Number(r.deposito),
      created_at: r.created_at,
    })),
    metas,
    metas_filtradas,
  }
}

// ════════════════════════════════════════════════════════════
// ADMIN PROFILE
// ════════════════════════════════════════════════════════════

export async function getAdminProfile() {
  const user = await getCurrentUser()
  if (!user) return null

  const { data } = await supabase
    .from('admins')
    .select('*')
    .eq('id', user.id)
    .single()

  return data
}

export async function getSubscription() {
  const user = await getCurrentUser()
  if (!user) return null

  const { data } = await supabase
    .from('assinaturas')
    .select('*')
    .eq('admin_id', user.id)
    .single()

  return data
}
