type NotifyEvent =
  | 'notificacoes_ativadas'
  | 'remessa_registrada'
  | 'remessa_bloqueada'
  | 'remessa_pendente'
  | 'remessa_analise'
  | 'meta_criada'
  | 'meta_finalizada'
  | 'meta_fechada'
  | 'meta_reativada'
  | 'custo_adicionado'

interface NotifyData {
  titulo?: string
  resultado?: number
  lucroFinal?: number
  contas?: number
  rede?: string
  valor?: number
  descricao?: string
}

const ICON = '/logo.png'

function fmtBRL(value: number): string {
  const abs = Math.abs(value)
  const prefix = value >= 0 ? '+R$ ' : '-R$ '
  return prefix + abs.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
}

function buildMessage(event: NotifyEvent, data: NotifyData): { title: string; body: string } {
  const { titulo, resultado = 0, lucroFinal = 0, contas = 1, rede, valor = 0, descricao } = data

  const positiveLines = [
    'Boa remessa! Segue firme.',
    'Excelente resultado. Continue assim!',
    'No lucro. Mantém o foco.',
    'Resultado positivo registrado!',
  ]
  const randomLine = positiveLines[Math.floor(Math.random() * positiveLines.length)]

  switch (event) {
    case 'notificacoes_ativadas':
      return {
        title: 'Alertas ativados',
        body: 'Você receberá avisos em tempo real sobre bloqueios, saques e operações.',
      }

    case 'remessa_registrada': {
      const label = titulo || 'Remessa'
      const resultLine = resultado !== 0 ? ` — Resultado: ${fmtBRL(resultado)}` : ''
      const contasLabel = contas > 1 ? ` · ${contas} contas` : ''
      const extra = resultado > 0 ? `\n${randomLine}` : resultado < 0 ? '\nRevise a estratégia.' : ''
      return {
        title: 'Remessa registrada!',
        body: `${label}${contasLabel}${resultLine}${extra}`,
      }
    }

    case 'remessa_bloqueada':
      return {
        title: 'Bloqueio registrado',
        body: 'Conta bloqueada — verifique imediatamente e tome as devidas providências.',
      }

    case 'remessa_pendente':
      return {
        title: 'Saque pendente detectado',
        body: 'Remessa aguardando liberação — acompanhe o status de perto.',
      }

    case 'remessa_analise':
      return {
        title: 'Banco em análise',
        body: 'Conta sob revisão — aguarde retorno antes de realizar novas operações.',
      }

    case 'meta_criada':
      return {
        title: 'Nova operação criada!',
        body: `${titulo || 'Operação'}${rede ? ` · ${rede}` : ''} — Boa operação!`,
      }

    case 'meta_finalizada':
      return {
        title: 'Operação finalizada!',
        body: `${titulo || 'Operação'} encerrada — Resultado: ${fmtBRL(resultado)}`,
      }

    case 'meta_fechada':
      return {
        title: 'Operação fechada com sucesso',
        body: `Lucro final: ${fmtBRL(lucroFinal)} — Missão cumprida.`,
      }

    case 'meta_reativada':
      return {
        title: 'Operação reativada',
        body: `${titulo || 'Operação'} está ativa novamente. Bora operar!`,
      }

    case 'custo_adicionado':
      return {
        title: 'Custo registrado',
        body: `${descricao || 'Custo'}: ${fmtBRL(valor)} adicionado à operação.`,
      }
  }
}

// ── Toast type mapping (mirrors Toast.tsx ToastType) ─────────
type NotifyToastType = 'success' | 'error' | 'warning' | 'info' | 'critical'

function eventToToastType(event: NotifyEvent): NotifyToastType {
  switch (event) {
    case 'remessa_bloqueada': return 'critical'
    case 'remessa_pendente':  return 'warning'
    case 'remessa_analise':   return 'info'
    case 'remessa_registrada':
    case 'meta_finalizada':
    case 'meta_fechada':      return 'success'
    default:                  return 'info'
  }
}

// ── Toast bus (remote-received popup) ────────────────────────
type ToastFn = (type: NotifyToastType, title: string, body: string, duration: number) => void
let _toastFn: ToastFn | null = null

export function setNotifyToast(fn: ToastFn | null): void {
  _toastFn = fn
}

// ── Web notification bus (in-app panel) ──────────────────────
type WebListener = (event: NotifyEvent, title: string, body: string) => void
const _webListeners = new Set<WebListener>()

export function addNotifyWebListener(fn: WebListener): () => void {
  _webListeners.add(fn)
  return () => _webListeners.delete(fn)
}

// ── Multi-device broadcast bus (Supabase Realtime — open tabs) ─
type BroadcastFn = (event: NotifyEvent, data: NotifyData) => void
let _broadcastFn: BroadcastFn | null = null

export function setNotifyBroadcast(fn: BroadcastFn | null): void {
  _broadcastFn = fn
}

// ── Server push bus (Web Push VAPID — closed app) ─────────────
type PushFn = (title: string, body: string, tag: string) => void
let _pushFn: PushFn | null = null

export function setNotifyPush(fn: PushFn | null): void {
  _pushFn = fn
}

// ── Deduplication — evita toast duplo quando Realtime + SW relay chegam juntos ─
// Janela de 3 s por tag. Chamadas diretas (skipBroadcast=false) sempre marcam.
// Chamadas via sync (skipBroadcast=true) ou via SW relay só exibem se ainda não marcado.
const _shownTs = new Map<string, number>()

function _wasShownRecently(tag: string): boolean {
  const last = _shownTs.get(tag)
  return !!last && Date.now() - last < 3000
}

function _markShown(tag: string): void {
  _shownTs.set(tag, Date.now())
  if (_shownTs.size > 30) {
    const cutoff = Date.now() - 6000
    _shownTs.forEach((v, k) => { if (v < cutoff) _shownTs.delete(k) })
  }
}

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window
}

export function getNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!isNotificationSupported()) return 'unsupported'
  return Notification.permission
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false
  if (Notification.permission === 'granted') return true
  if (Notification.permission === 'denied') return false
  const result = await Notification.requestPermission()
  return result === 'granted'
}

export function notify(event: NotifyEvent, data: NotifyData = {}, skipBroadcast = false): void {
  const { title, body } = buildMessage(event, data)

  // Via Realtime (skipBroadcast=true): pula se SW relay já exibiu no mesmo dispositivo
  if (skipBroadcast && _wasShownRecently(event)) return

  // Atualiza painel de notificações (sempre)
  _webListeners.forEach(fn => fn(event, title, body))

  // Broadcast para sessões abertas (Supabase Realtime)
  if (!skipBroadcast) _broadcastFn?.(event, data)

  // Push para dispositivos fechados/background (Web Push VAPID)
  if (!skipBroadcast) _pushFn?.(title, body, event)

  // Marca como exibido ANTES do toast — impede relay duplicado do SW
  _markShown(event)
  _toastFn?.(eventToToastType(event), title, body, 5000)

  if (!isNotificationSupported() || Notification.permission !== 'granted') return

  // Toast already handles foreground; system notification only needed when page is hidden
  if (typeof document !== 'undefined' && document.visibilityState === 'visible') return

  const options: NotificationOptions = {
    body,
    icon: ICON,
    badge: ICON,
    tag: event,
    silent: false,
  }

  // Service worker notification works on desktop PWA, mobile PWA, and background tabs
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready
      .then(reg => reg.showNotification(title, options))
      .catch(() => {
        try { new Notification(title, options) } catch { /* blocked */ }
      })
    return
  }

  try {
    new Notification(title, options)
  } catch {
    // Notification API may be blocked in some contexts
  }
}

// Exibe toast + painel a partir de dados já formatados pelo push/SW relay
// Pula silenciosamente se notify() ou Realtime já exibiu na janela de 3 s
export function notifyFromPush(title: string, body: string, tag: string): void {
  if (_wasShownRecently(tag)) return
  _markShown(tag)
  _toastFn?.(eventToToastType(tag as NotifyEvent), title, body, 5000)
  _webListeners.forEach(fn => fn(tag as NotifyEvent, title, body))
}
