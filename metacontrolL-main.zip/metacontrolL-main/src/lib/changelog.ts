export interface ChangelogEntry {
  version: string
  date: string
  label?: 'novo' | 'melhoria' | 'fix' | 'segurança'
  items: { type: 'add' | 'fix' | 'change'; text: string }[]
}

export const CURRENT_VERSION = '1.09.1'

export const changelog: ChangelogEntry[] = [
  {
    version: '1.09.1',
    date: '20/04/2026',
    label: 'segurança',
    items: [
      { type: 'fix',    text: 'Proteção dupla em /admin: middleware + verificação no componente bloqueiam acesso sem sessão ativa' },
      { type: 'fix',    text: 'Landing page redireciona automaticamente para /admin quando o usuário já está logado' },
      { type: 'add',    text: 'Sistema de logs de novidades com badge "NEW" e persistência via localStorage' },
    ],
  },
  {
    version: '1.09',
    date: '18/04/2026',
    label: 'melhoria',
    items: [
      { type: 'add',    text: 'Filtros de período no dashboard: Hoje, Ontem, 7d, 30d e Tudo' },
      { type: 'add',    text: 'Cards de status operacional com cores dinâmicas (Saudável / Atenção / Estável)' },
      { type: 'add',    text: 'Taxa de acerto e lucro bruto calculados por período selecionado' },
      { type: 'change', text: 'Visão geral reorganizada com strip lateral de métricas compactas' },
    ],
  },
  {
    version: '1.08',
    date: '15/04/2026',
    label: 'novo',
    items: [
      { type: 'add',    text: 'Lixeira de metas com opção de restauração e confirmação antes de excluir' },
      { type: 'add',    text: 'Score da operação (0–100) com cores dinâmicas por desempenho' },
      { type: 'add',    text: 'Insights automáticos por operação: estado estável, atenção ou sem remessas' },
      { type: 'add',    text: 'Painel de eventos da operação: saques pendentes, contas bloqueadas e bancos em análise' },
      { type: 'add',    text: 'Barra de alertas fixada no rodapé da meta quando há eventos ativos' },
      { type: 'change', text: 'Animação de troca de aba com re-mount suave via key prop' },
    ],
  },
  {
    version: '1.07',
    date: '12/04/2026',
    label: 'novo',
    items: [
      { type: 'add',    text: 'Página de Slots Premium com ranking por RTP e volatilidade' },
      { type: 'add',    text: 'Filtros de provedor, volatilidade e busca por nome em Slots Premium' },
      { type: 'add',    text: 'Cards de slot com overlay de bloqueio para não assinantes' },
      { type: 'add',    text: 'Tutorial interativo com checklist de 6 etapas e barra de progresso' },
      { type: 'add',    text: 'Guia passo a passo para ativar notificações via PWA no celular' },
      { type: 'add',    text: 'Links rápidos de navegação no tutorial (Painel, Operação, Assinatura)' },
    ],
  },
  {
    version: '1.06.5',
    date: '10/04/2026',
    label: 'novo',
    items: [
      { type: 'add',    text: 'Página de Faturamento com visão geral e histórico completo de operações' },
      { type: 'add',    text: 'Filtro por intervalo de datas no faturamento (de/até)' },
      { type: 'add',    text: 'Análise automática da operação com insights de lucratividade e performance' },
      { type: 'add',    text: 'Página de Custos com categorias, valores diários, mensais e total' },
      { type: 'add',    text: 'Modal de adição de custo com tipo, valor, data e nota' },
      { type: 'add',    text: 'Exclusão de custo com modal de confirmação' },
      { type: 'fix',    text: 'Sidebar colapsável sem perder estado de navegação entre páginas' },
    ],
  },
  {
    version: '1.06.1',
    date: '05/04/2026',
    label: 'novo',
    items: [
      { type: 'add',    text: 'Sistema de trial de 7 dias com barra de progresso e contagem regressiva' },
      { type: 'add',    text: 'Expiração automática do trial via Supabase RPC sem intervenção manual' },
      { type: 'add',    text: 'Página de Assinatura com detalhes do plano PRO, preço e data de renovação' },
      { type: 'add',    text: 'Badge de plano PRO / Gratuito com avatar e email no sidebar' },
      { type: 'add',    text: 'Sidebar responsivo: colapsável no desktop, drawer no mobile' },
    ],
  },
  {
    version: '1.05',
    date: '01/04/2026',
    items: [
      { type: 'add',    text: 'Edição inline de status de remessa diretamente na lista (Normal / Pendente / Bloqueado / Análise)' },
      { type: 'add',    text: 'Fechamento de meta com modal: salário, bau e gastos operacionais deduzidos do lucro final' },
      { type: 'add',    text: 'Reativação de meta fechada ou finalizada' },
      { type: 'add',    text: 'Média de resultado por conta calculada em tempo real' },
      { type: 'add',    text: 'Barra de progresso de contas atingidas por meta' },
      { type: 'change', text: 'Formulário de remessa colapsável com botões de atalho para contagem de contas' },
    ],
  },
  {
    version: '1.04',
    date: '27/03/2026',
    items: [
      { type: 'add',    text: 'Cálculo automático do resultado (saque − depósito) em tempo real ao digitar' },
      { type: 'add',    text: 'Histórico de remessas por meta com depósito, saque e resultado por conta' },
      { type: 'add',    text: 'Exclusão de remessa com confirmação' },
      { type: 'add',    text: 'Estatísticas da operação: depósito total, saque total, lucro acumulado e prejuízo' },
      { type: 'add',    text: 'Suporte a múltiplos status por remessa com cores distintas' },
    ],
  },
  {
    version: '1.03',
    date: '22/03/2026',
    items: [
      { type: 'add',    text: 'Criação de metas com título, plataforma, rede, contas e modelo' },
      { type: 'add',    text: 'Edição de meta via modal com todos os campos' },
      { type: 'add',    text: 'Registro de remessa com título, contas, depósito, saque, status e notas' },
      { type: 'add',    text: 'Listagem de metas ativas, finalizadas e fechadas com filtro por status' },
      { type: 'add',    text: 'Página de detalhe da meta (/admin/meta/[id]) com visão completa da operação' },
    ],
  },
  {
    version: '1.00',
    date: '15/03/2026',
    items: [
      { type: 'add',    text: 'Autenticação completa com Supabase: cadastro, login, logout e sessão por cookie' },
      { type: 'add',    text: 'Middleware de proteção de rotas: páginas protegidas redirecionam para /login' },
      { type: 'add',    text: 'Trigger automático no Supabase cria perfil de admin ao registrar usuário' },
      { type: 'add',    text: 'Landing page de vendas com contador animado, preview do dashboard e CTAs' },
      { type: 'add',    text: 'Dashboard base com abas Visão geral, Minha operação, Metas & Fechamento e Lixeira' },
      { type: 'add',    text: 'Row-Level Security (RLS) no Supabase: cada admin acessa apenas seus próprios dados' },
    ],
  },
]
