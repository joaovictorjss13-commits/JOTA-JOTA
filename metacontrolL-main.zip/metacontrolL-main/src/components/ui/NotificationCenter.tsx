'use client'

import { useState, useEffect, useRef } from 'react'
import { Bell, X, CheckCircle2, Info, ShieldAlert, Zap } from 'lucide-react'
import { cn } from '@/lib/utils'
import { addNotifyWebListener } from '@/lib/notifications'

interface WebNotif {
  id: string
  event: string
  title: string
  body: string
  type: 'critical' | 'warning' | 'info' | 'success'
  ts: number
  read: boolean
}

function eventToType(event: string): WebNotif['type'] {
  if (event === 'remessa_bloqueada') return 'critical'
  if (event === 'remessa_pendente') return 'warning'
  if (event === 'remessa_analise') return 'info'
  if (event === 'remessa_registrada') return 'success'
  if (event.startsWith('meta_')) return 'success'
  return 'info'
}

function ago(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000)
  if (s < 60) return 'agora'
  if (s < 3600) return `${Math.floor(s / 60)}m`
  if (s < 86400) return `${Math.floor(s / 3600)}h`
  return `${Math.floor(s / 86400)}d`
}

export function NotificationCenter({ collapsed }: { collapsed: boolean }) {
  const [list, setList] = useState<WebNotif[]>([])
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  const unread = list.filter(n => !n.read).length

  useEffect(() => {
    return addNotifyWebListener((event, title, body) => {
      setList(prev => [
        {
          id: `${Date.now()}${Math.random().toString(36).slice(2)}`,
          event, title, body,
          type: eventToType(event),
          ts: Date.now(),
          read: false,
        },
        ...prev,
      ].slice(0, 30))
    })
  }, [])

  // Mark all read when panel opens
  useEffect(() => {
    if (open) setList(prev => prev.map(n => ({ ...n, read: true })))
  }, [open])

  // Close on outside click
  useEffect(() => {
    if (!open) return
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])

  return (
    <div className="relative" ref={ref}>
      {/* Bell button — matches sidebar nav item style */}
      <button
        onClick={() => setOpen(v => !v)}
        title={collapsed ? 'Notificações' : undefined}
        className={cn(
          'flex items-center gap-3 w-full py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
          collapsed ? 'justify-center px-0' : 'px-3',
          open
            ? 'text-[#c4b5fd]'
            : 'text-[rgba(148,163,184,0.65)] hover:text-[#c4b5fd] hover:bg-[rgba(124,58,237,0.08)]',
        )}
        style={open ? {
          background: 'rgba(124,58,237,0.14)',
          border: '1px solid rgba(124,58,237,0.28)',
          boxShadow: '0 0 12px rgba(124,58,237,0.12), inset 0 1px 0 rgba(255,255,255,0.05)',
        } : {
          border: '1px solid transparent',
        }}
      >
        <div className="relative shrink-0">
          <Bell size={16} />
          {unread > 0 && (
            <span
              className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] rounded-full text-[9px] font-bold text-white flex items-center justify-center px-[2px] leading-none"
              style={{ background: '#ef4444', animation: 'pulse-glow 1.5s ease-in-out infinite' }}
            >
              {unread > 9 ? '9+' : unread}
            </span>
          )}
        </div>
        {!collapsed && 'Notificações'}
      </button>

      {/* Panel */}
      {open && (
        <div
          className="absolute left-full bottom-0 ml-2 flex flex-col"
          style={{
            width: '320px',
            maxHeight: '480px',
            background: 'rgba(10,10,24,0.98)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '16px',
            boxShadow: '0 24px 48px rgba(0,0,0,0.65), 0 0 0 1px rgba(124,58,237,0.10)',
            zIndex: 60,
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3 shrink-0"
            style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}
          >
            <div className="flex items-center gap-2">
              <Bell size={13} style={{ color: '#a78bfa' }} />
              <span className="text-sm font-bold text-text-primary">Notificações</span>
              {unread > 0 && (
                <span
                  className="px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                  style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171' }}
                >
                  {unread} nova{unread > 1 ? 's' : ''}
                </span>
              )}
            </div>
            <button
              onClick={() => setOpen(false)}
              className="p-0.5 rounded text-text-muted hover:text-text-primary transition-colors"
            >
              <X size={14} />
            </button>
          </div>

          {/* List */}
          <div className="overflow-y-auto flex-1 py-1">
            {list.length === 0 ? (
              <div className="py-12 text-center">
                <Bell size={28} className="mx-auto mb-3" style={{ color: '#a78bfa', opacity: 0.2 }} />
                <p className="text-xs text-text-muted">Nenhuma notificação ainda</p>
                <p className="text-[10px] text-text-muted mt-1" style={{ opacity: 0.6 }}>
                  As notificações aparecerão aqui
                </p>
              </div>
            ) : (
              list.map(n => <NotifRow key={n.id} n={n} />)
            )}
          </div>

          {/* Footer */}
          {list.length > 0 && (
            <div
              className="px-4 py-2.5 shrink-0 flex items-center justify-between"
              style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
            >
              <span className="text-[10px] text-text-muted">
                {list.length} notificaç{list.length === 1 ? 'ão' : 'ões'}
              </span>
              <button
                onClick={() => setList([])}
                className="text-[10px] text-text-muted hover:text-text-secondary transition-colors"
              >
                Limpar tudo
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── Row ────────────────────────────────────────────────────────

const ICON: Record<WebNotif['type'], React.ReactNode> = {
  critical: <ShieldAlert size={14} style={{ color: '#f87171' }} />,
  warning:  <Zap        size={14} style={{ color: '#f59e0b' }} />,
  info:     <Info       size={14} style={{ color: '#60a5fa' }} />,
  success:  <CheckCircle2 size={14} style={{ color: '#10b981' }} />,
}

const STYLE: Record<WebNotif['type'], { bg: string; border: string; dot: string; title: string }> = {
  critical: { bg: 'rgba(239,68,68,0.10)',  border: 'rgba(239,68,68,0.30)',  dot: '#ef4444', title: '#fca5a5' },
  warning:  { bg: 'rgba(245,158,11,0.10)', border: 'rgba(245,158,11,0.30)', dot: '#f59e0b', title: '#fcd34d' },
  info:     { bg: 'rgba(59,130,246,0.10)', border: 'rgba(59,130,246,0.30)', dot: '#3b82f6', title: '#93c5fd' },
  success:  { bg: 'rgba(16,185,129,0.10)', border: 'rgba(16,185,129,0.30)', dot: '#10b981', title: '#6ee7b7' },
}

function NotifRow({ n }: { n: WebNotif }) {
  const s = STYLE[n.type]
  return (
    <div
      className="flex items-start gap-3 px-4 py-3 transition-colors hover:bg-white/[0.02]"
      style={!n.read ? { background: 'rgba(124,58,237,0.03)' } : {}}
    >
      <div
        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
        style={{ background: s.bg, border: `1px solid ${s.border}` }}
      >
        {ICON[n.type]}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-1">
          <p className="text-xs font-semibold leading-tight" style={{ color: s.title }}>{n.title}</p>
          <span className="text-[10px] text-text-muted shrink-0 mt-px">{ago(n.ts)}</span>
        </div>
        <p className="text-[11px] text-text-muted mt-0.5 leading-relaxed" style={{
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}>{n.body}</p>
      </div>
      {!n.read && (
        <div
          className="w-1.5 h-1.5 rounded-full shrink-0 mt-1.5"
          style={{ background: s.dot }}
        />
      )}
    </div>
  )
}
