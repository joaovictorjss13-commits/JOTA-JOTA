'use client'

import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/utils'
import { X } from 'lucide-react'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  children: React.ReactNode
  title?: string
  subtitle?: string
  className?: string
}

export function Modal({ isOpen, onClose, children, title, subtitle, className }: ModalProps) {
  useEffect(() => {
    if (!isOpen) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [isOpen])

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    if (isOpen) window.addEventListener('keydown', handleEsc)
    return () => window.removeEventListener('keydown', handleEsc)
  }, [isOpen, onClose])

  if (!isOpen) return null

  return createPortal(
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm animate-fade-in" />

      {/* Card — floats above everything, independent of any parent container */}
      <div
        className={cn(
          'relative z-10 w-full max-w-lg bg-bg-surface rounded-2xl border border-border',
          'shadow-2xl shadow-black/50 animate-scale-in',
          'max-h-[90dvh] overflow-y-auto',
          className
        )}
        onClick={(e) => e.stopPropagation()}
      >
        {(title || subtitle) && (
          <div className="flex items-start justify-between p-6 pb-4">
            <div>
              {title && <h2 className="text-xl font-bold text-text-primary">{title}</h2>}
              {subtitle && <p className="text-sm text-text-secondary mt-1">{subtitle}</p>}
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-bg-surface-light transition-colors text-text-muted hover:text-text-primary"
            >
              <X size={18} />
            </button>
          </div>
        )}

        <div className={cn(title ? 'px-6 pb-6' : 'p-6')}>
          {children}
        </div>
      </div>
    </div>,
    document.body
  )
}
