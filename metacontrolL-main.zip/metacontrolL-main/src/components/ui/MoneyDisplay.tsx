'use client'

import { useState, useEffect, useRef } from 'react'
import { cn, formatBRL, getResultColor } from '@/lib/utils'

function useCountUp(target: number, duration = 750): number {
  const [current, setCurrent] = useState(0)
  const prevTarget = useRef<number>(0)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    // Animate on first load from 0 → non-zero
    if (prevTarget.current === 0 && target !== 0) {
      const startTime = performance.now()
      const sign = target < 0 ? -1 : 1
      const abs = Math.abs(target)

      const tick = (now: number) => {
        const elapsed = now - startTime
        const progress = Math.min(elapsed / duration, 1)
        const eased = 1 - Math.pow(1 - progress, 3)
        setCurrent(sign * abs * eased)
        if (progress < 1) {
          rafRef.current = requestAnimationFrame(tick)
        } else {
          setCurrent(target)
        }
      }
      rafRef.current = requestAnimationFrame(tick)
    } else {
      setCurrent(target)
    }
    prevTarget.current = target

    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [target])

  return current
}

interface MoneyDisplayProps {
  value: number
  size?: 'sm' | 'md' | 'lg' | 'xl'
  showSign?: boolean
  animate?: boolean
  className?: string
}

export function MoneyDisplay({ value, size = 'md', showSign = true, animate = true, className }: MoneyDisplayProps) {
  const animated = useCountUp(animate ? value : 0)
  const displayValue = animate ? animated : value

  const sizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-4xl',
  }

  const formatted = showSign
    ? displayValue > 0 ? `+${formatBRL(displayValue)}` : formatBRL(displayValue)
    : formatBRL(Math.abs(displayValue))

  return (
    <span
      className={cn(
        'font-bold mono-value tabular-nums',
        sizes[size],
        showSign ? getResultColor(value) : 'text-text-primary',
        className
      )}
      style={{ fontFamily: 'var(--font-mono)', fontVariantNumeric: 'tabular-nums' }}
    >
      {formatted}
    </span>
  )
}
