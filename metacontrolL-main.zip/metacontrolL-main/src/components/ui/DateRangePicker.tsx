'use client'

import { useState, useRef, useEffect } from 'react'
import { Calendar, ChevronLeft, ChevronRight, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface DateRangePickerProps {
  from: string
  to: string
  onChange: (from: string, to: string) => void
}

const MONTHS = [
  'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
  'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro',
]
const WEEKDAYS = ['D','S','T','Q','Q','S','S']

function todayStr() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

function addDays(dateStr: string, days: number) {
  const d = new Date(dateStr + 'T00:00:00')
  d.setDate(d.getDate() + days)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

function thisMonthStart() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`
}

const PRESETS = [
  { label: 'Hoje',      range: () => { const t = todayStr(); return { from: t, to: t } } },
  { label: 'Ontem',     range: () => { const y = addDays(todayStr(), -1); return { from: y, to: y } } },
  { label: '7 dias',    range: () => ({ from: addDays(todayStr(), -6), to: todayStr() }) },
  { label: '30 dias',   range: () => ({ from: addDays(todayStr(), -29), to: todayStr() }) },
  { label: 'Este mês',  range: () => ({ from: thisMonthStart(), to: todayStr() }) },
]

function formatDisplay(from: string, to: string) {
  if (!from && !to) return 'Selecionar período'
  const fmt = (s: string) => {
    const [y, m, d] = s.split('-')
    return `${d}/${m}/${y}`
  }
  if (from && !to) return fmt(from)
  if (from === to) return fmt(from)
  return `${fmt(from)} → ${fmt(to)}`
}

export function DateRangePicker({ from, to, onChange }: DateRangePickerProps) {
  const [open, setOpen] = useState(false)
  const [hovered, setHovered] = useState('')
  const [phase, setPhase] = useState<'from' | 'to'>('from')
  const ref = useRef<HTMLDivElement>(null)

  const initView = () => {
    const d = from ? new Date(from + 'T00:00:00') : new Date()
    return { year: d.getFullYear(), month: d.getMonth() }
  }
  const [view, setView] = useState(initView)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
        setHovered('')
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const { year, month } = view
  const firstWeekday = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells: (string | null)[] = Array(firstWeekday).fill(null)
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push(`${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`)
  }

  function handleDay(day: string) {
    if (phase === 'from') {
      onChange(day, '')
      setPhase('to')
    } else {
      const [f, t] = day < from ? [day, from] : [from, day]
      onChange(f, t)
      setPhase('from')
      setOpen(false)
      setHovered('')
    }
  }

  function previewEnd() {
    return phase === 'to' ? (hovered || to) : to
  }

  function isInRange(day: string) {
    const end = previewEnd()
    if (!from || !end) return false
    const [f, e] = from <= end ? [from, end] : [end, from]
    return day > f && day < e
  }

  function isStart(day: string) { return !!from && day === from }
  function isEnd(day: string) { const e = previewEnd(); return !!e && day === e }

  function prevMonth() {
    setView(v => v.month === 0
      ? { year: v.year - 1, month: 11 }
      : { year: v.year, month: v.month - 1 })
  }

  function nextMonth() {
    setView(v => v.month === 11
      ? { year: v.year + 1, month: 0 }
      : { year: v.year, month: v.month + 1 })
  }

  function applyPreset(p: typeof PRESETS[0]) {
    const r = p.range()
    onChange(r.from, r.to)
    setPhase('from')
    setOpen(false)
    setHovered('')
  }

  function clear(e: React.MouseEvent) {
    e.stopPropagation()
    onChange('', '')
    setPhase('from')
  }

  const hasValue = !!(from || to)

  return (
    <div ref={ref} className="relative inline-block">
      <button
        onClick={() => setOpen(o => !o)}
        className={cn(
          'flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs transition-all select-none',
          'bg-bg-surface border-border text-text-primary',
          'hover:border-accent-green/40',
          open && 'border-accent-green/60 shadow-[0_0_0_2px_rgba(34,197,94,0.08)]',
          hasValue && !open && 'border-accent-green/30',
        )}
      >
        <Calendar size={13} className={cn('shrink-0', hasValue ? 'text-accent-green' : 'text-text-muted')} />
        <span className={cn('whitespace-nowrap', hasValue ? 'text-text-primary' : 'text-text-muted')}>
          {formatDisplay(from, to)}
        </span>
        {hasValue && (
          <X
            size={12}
            className="shrink-0 text-text-muted hover:text-accent-red transition-colors"
            onClick={clear}
          />
        )}
      </button>

      {open && (
        <div className={cn(
          'absolute top-[calc(100%+6px)] left-0 z-50',
          'bg-bg-surface border border-border rounded-xl shadow-2xl p-4 w-[272px]',
          'animate-fade-in',
        )}>
          {/* Presets */}
          <div className="flex flex-wrap gap-1.5 mb-3 pb-3 border-b border-border">
            {PRESETS.map(p => (
              <button
                key={p.label}
                onClick={() => applyPreset(p)}
                className={cn(
                  'px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all',
                  'bg-bg-surface-light border border-border text-text-muted',
                  'hover:border-accent-green/50 hover:text-accent-green hover:bg-accent-green/5',
                )}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Month navigation */}
          <div className="flex items-center justify-between mb-2">
            <button
              onClick={prevMonth}
              className="p-1.5 rounded-md hover:bg-bg-surface-light text-text-muted hover:text-text-primary transition-colors"
            >
              <ChevronLeft size={13} />
            </button>
            <span className="text-xs font-bold text-text-primary capitalize">
              {MONTHS[month]} {year}
            </span>
            <button
              onClick={nextMonth}
              className="p-1.5 rounded-md hover:bg-bg-surface-light text-text-muted hover:text-text-primary transition-colors"
            >
              <ChevronRight size={13} />
            </button>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 mb-1">
            {WEEKDAYS.map((w, i) => (
              <div key={i} className="text-center text-[10px] text-text-muted font-semibold py-1">
                {w}
              </div>
            ))}
          </div>

          {/* Day cells */}
          <div className="grid grid-cols-7 gap-y-0.5">
            {cells.map((day, i) => {
              if (!day) return <div key={`e-${i}`} />
              const start = isStart(day)
              const end = isEnd(day)
              const inRange = isInRange(day)
              const dayNum = parseInt(day.split('-')[2])
              return (
                <button
                  key={day}
                  onClick={() => handleDay(day)}
                  onMouseEnter={() => phase === 'to' && setHovered(day)}
                  onMouseLeave={() => setHovered('')}
                  className={cn(
                    'relative text-center text-xs py-1.5 transition-all font-medium leading-none',
                    !start && !end && !inRange && [
                      'rounded-md text-text-secondary',
                      'hover:bg-accent-green/10 hover:text-accent-green',
                    ],
                    inRange && 'bg-accent-green/10 text-accent-green rounded-none',
                    (start || end) && 'bg-accent-green text-white font-bold z-10',
                    start && 'rounded-l-md rounded-r-none',
                    end && 'rounded-r-md rounded-l-none',
                    start && end && 'rounded-md',
                  )}
                >
                  {dayNum}
                </button>
              )
            })}
          </div>

          {/* Phase hint */}
          <p className="text-center text-[10px] text-text-muted mt-3">
            {phase === 'from' ? '↑ Clique para definir o início' : '↑ Clique para definir o fim do período'}
          </p>
        </div>
      )}
    </div>
  )
}
