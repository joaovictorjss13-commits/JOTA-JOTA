'use client'

import { cn } from '@/lib/utils'

interface CardProps {
  children: React.ReactNode
  className?: string
  glow?: 'green' | 'red' | 'yellow' | 'blue' | 'violet' | 'none'
  hover?: boolean
  onClick?: () => void
}

const glowStyles: Record<string, React.CSSProperties> = {
  green:  { borderLeft: '2px solid #10b981', border: '1px solid rgba(16,185,129,0.45)',  boxShadow: '0 0 24px rgba(16,185,129,0.10), inset 4px 0 24px rgba(16,185,129,0.08)' },
  red:    { borderLeft: '2px solid #ef4444', border: '1px solid rgba(239,68,68,0.45)',   boxShadow: '0 0 24px rgba(239,68,68,0.10),  inset 4px 0 24px rgba(239,68,68,0.08)'  },
  yellow: { borderLeft: '2px solid #f59e0b', border: '1px solid rgba(245,158,11,0.45)',  boxShadow: '0 0 24px rgba(245,158,11,0.10), inset 4px 0 24px rgba(245,158,11,0.08)' },
  blue:   { borderLeft: '2px solid #3b82f6', border: '1px solid rgba(59,130,246,0.45)',  boxShadow: '0 0 24px rgba(59,130,246,0.10), inset 4px 0 24px rgba(59,130,246,0.08)' },
  violet: { borderLeft: '2px solid #7c3aed', border: '1px solid rgba(124,58,237,0.45)',  boxShadow: '0 0 24px rgba(124,58,237,0.12), inset 4px 0 24px rgba(124,58,237,0.10)' },
  none:   {},
}

export function Card({ children, className, glow = 'none', hover = false, onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'rounded-2xl p-5',
        'relative overflow-hidden',          // needed for sweep clip
        'card-live card-sweep card-breathe', // float + light sweep + border breathe
        'transition-all duration-300',
        hover && 'cursor-pointer',
        onClick && 'cursor-pointer',
        className
      )}
      style={{
        background: 'rgba(255,255,255,0.02)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        border: '1px solid rgba(255,255,255,0.06)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.45)',
        ...glowStyles[glow],
      }}
      onMouseEnter={hover ? (e) => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = 'rgba(124,58,237,0.35)'
        el.style.boxShadow = '0 12px 40px rgba(0,0,0,0.50), 0 0 24px rgba(124,58,237,0.12)'
        el.style.transform = 'translateY(-6px)'
      } : undefined}
      onMouseLeave={hover ? (e) => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = 'rgba(255,255,255,0.06)'
        el.style.boxShadow = '0 8px 32px rgba(0,0,0,0.45)'
        el.style.transform = ''
      } : undefined}
    >
      {/* Content sits above the ::after sweep layer */}
      <div className="relative z-[1]">
        {children}
      </div>
    </div>
  )
}
