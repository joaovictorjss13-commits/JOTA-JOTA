'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Crown, X, Sparkles } from 'lucide-react'

export function FreeUserBanner() {
  const router = useRouter()
  const [dismissed, setDismissed] = useState(false)

  if (dismissed) return null

  return (
    <div
      className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl mb-4 flex-wrap"
      style={{
        background: 'linear-gradient(135deg, rgba(234,179,8,0.12), rgba(161,98,7,0.08))',
        border: '1px solid rgba(234,179,8,0.35)',
        boxShadow: '0 0 20px rgba(234,179,8,0.08)',
      }}
    >
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: 'rgba(234,179,8,0.18)', border: '1px solid rgba(234,179,8,0.30)' }}
        >
          <Sparkles size={15} style={{ color: '#fbbf24' }} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-bold" style={{ color: '#fbbf24' }}>
            Renove sua assinatura e desbloqueie tudo!
          </p>
          <p className="text-xs text-gray-400 truncate">
            Acesso completo às operações, relatórios e muito mais com o plano PRO.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => router.push('/assinatura')}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-black transition-all hover:opacity-90 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #eab308, #d97706)',
            color: '#000',
            boxShadow: '0 2px 12px rgba(234,179,8,0.30)',
          }}
        >
          <Crown size={12} />
          Seja PRO
        </button>
        <button
          onClick={() => setDismissed(true)}
          className="p-1.5 rounded-lg transition-colors hover:bg-white/10 text-gray-500 hover:text-gray-300"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  )
}
