'use client'

import { cn } from '@/lib/utils'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'gold'
  size?: 'sm' | 'md' | 'lg'
  children: React.ReactNode
}

export function Button({ variant = 'primary', size = 'md', className, children, ...props }: ButtonProps) {
  const variants: Record<string, string> = {
    primary: [
      'text-white font-semibold tracking-wide',
      'bg-violet-700 hover:bg-violet-600',
      'shadow-[0_0_20px_rgba(124,58,237,0.45)]',
      'hover:shadow-[0_0_35px_rgba(124,58,237,0.75)]',
      'border border-violet-500/30',
    ].join(' '),

    secondary: [
      'text-text-primary font-medium',
      'backdrop-blur-md',
      'border border-white/[0.08] hover:border-white/[0.15]',
    ].join(' '),

    ghost: [
      'text-text-secondary hover:text-text-primary font-medium',
      'hover:bg-white/[0.04]',
    ].join(' '),

    danger: [
      'text-accent-red font-medium',
      'border border-accent-red/30 hover:border-accent-red/50',
    ].join(' '),

    gold: [
      'text-black font-bold tracking-wide',
      'bg-amber-500 hover:bg-amber-400',
      'shadow-[0_0_25px_rgba(245,158,11,0.45)]',
      'hover:shadow-[0_0_40px_rgba(245,158,11,0.80)]',
    ].join(' '),
  }

  const sizes = {
    sm: 'px-3 py-1.5 text-xs rounded-lg',
    md: 'px-4 py-2.5 text-sm rounded-xl',
    lg: 'px-6 py-3.5 text-base rounded-xl',
  }

  const baseStyle = variant === 'secondary'
    ? { background: 'rgba(13,13,31,0.70)' }
    : variant === 'danger'
      ? { background: 'rgba(239,68,68,0.08)' }
      : undefined

  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2',
        'transition-all duration-300 active:scale-[0.97]',
        'disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100',
        variants[variant],
        sizes[size],
        className
      )}
      style={baseStyle}
      {...props}
    >
      {children}
    </button>
  )
}
