'use client'

import { useRouter } from 'next/navigation'
import { Lock, Crown } from 'lucide-react'

interface ProGateProps {
  children: React.ReactNode
}

export function ProGate({ children }: ProGateProps) {
  const router = useRouter()

  return (
    <div className="relative">
      {/* Content — blurred */}
      <div
        style={{
          filter: 'blur(6px)',
          pointerEvents: 'none',
          userSelect: 'none',
          opacity: 0.45,
        }}
        aria-hidden="true"
      >
        {children}
      </div>

      {/* Lock overlay */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ zIndex: 20 }}
      >
        <div
          className="flex flex-col items-center text-center px-8 py-8 rounded-2xl max-w-sm w-full mx-4"
          style={{
            background: 'rgba(10, 10, 20, 0.92)',
            border: '1px solid rgba(234, 179, 8, 0.35)',
            boxShadow: '0 0 40px rgba(234, 179, 8, 0.12), 0 20px 60px rgba(0,0,0,0.6)',
            backdropFilter: 'blur(20px)',
          }}
        >
          {/* Icon */}
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{
              background: 'linear-gradient(135deg, rgba(234,179,8,0.20), rgba(161,98,7,0.15))',
              border: '1px solid rgba(234,179,8,0.35)',
              boxShadow: '0 0 20px rgba(234,179,8,0.15)',
            }}
          >
            <Lock size={28} style={{ color: '#eab308' }} />
          </div>

          {/* Badge */}
          <span
            className="text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full mb-3"
            style={{
              background: 'rgba(234,179,8,0.15)',
              color: '#fbbf24',
              border: '1px solid rgba(234,179,8,0.30)',
            }}
          >
            Acesso Restrito
          </span>

          {/* Message */}
          <p className="text-base font-bold text-white leading-snug mb-1">
            Sua assinatura expirou
          </p>
          <p className="text-sm text-gray-400 mb-6 leading-relaxed">
            Torne-se um membro{' '}
            <span style={{ color: '#fbbf24', fontWeight: 700 }}>PRO</span>{' '}
            e tenha acesso a todos os recursos!
          </p>

          {/* CTA */}
          <button
            onClick={() => router.push('/assinatura')}
            className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl text-sm font-black transition-all duration-200 hover:opacity-90 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #eab308, #d97706)',
              color: '#000',
              boxShadow: '0 4px 20px rgba(234,179,8,0.35)',
            }}
          >
            <Crown size={16} />
            Tornar-se PRO
          </button>
        </div>
      </div>
    </div>
  )
}
