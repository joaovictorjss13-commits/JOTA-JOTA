'use client'

import { cn } from '@/lib/utils'

type BadgeVariant = 'success' | 'danger' | 'warning' | 'info' | 'neutral' | 'lucro' | 'perda'

interface BadgeProps {
  variant?: BadgeVariant
  children: React.ReactNode
  className?: string
}

export function Badge({ variant = 'neutral', children, className }: BadgeProps) {
  const variants: Record<BadgeVariant, string> = {
    success: 'bg-accent-green/15 text-accent-green border-accent-green/30',
    danger: 'bg-accent-red/15 text-accent-red border-accent-red/30',
    warning: 'bg-accent-yellow/15 text-accent-yellow border-accent-yellow/30',
    info: 'bg-accent-blue/15 text-accent-blue border-accent-blue/30',
    neutral: 'bg-bg-surface-light text-text-secondary border-border',
    lucro: 'bg-accent-green/15 text-accent-green border-accent-green/30',
    perda: 'bg-accent-red/15 text-accent-red border-accent-red/30',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-semibold border',
        'uppercase tracking-wide',
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  )
}

// Convenience badge for meta status
export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { variant: BadgeVariant; label: string }> = {
    ativa: { variant: 'success', label: 'Ativa' },
    finalizada: { variant: 'info', label: 'Finalizada' },
    fechada: { variant: 'warning', label: 'Fechada' },
    lixeira: { variant: 'danger', label: 'Lixeira' },
  }
  const c = config[status] || { variant: 'neutral' as BadgeVariant, label: status }
  return <Badge variant={c.variant}>{c.label}</Badge>
}
