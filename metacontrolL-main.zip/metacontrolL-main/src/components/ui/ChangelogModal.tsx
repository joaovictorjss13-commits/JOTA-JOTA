'use client'

import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Plus, Wrench, ArrowRight } from 'lucide-react'
import { changelog, CURRENT_VERSION } from '@/lib/changelog'
import { cn } from '@/lib/utils'

const LS_KEY = 'mc_changelog_seen'

export function useChangelogBadge() {
  const [hasNew, setHasNew] = useState(false)

  useEffect(() => {
    const seen = localStorage.getItem(LS_KEY)
    setHasNew(seen !== CURRENT_VERSION)
  }, [])

  const markSeen = () => {
    localStorage.setItem(LS_KEY, CURRENT_VERSION)
    setHasNew(false)
  }

  return { hasNew, markSeen }
}

interface ChangelogModalProps {
  isOpen: boolean
  onClose: () => void
}

const typeIcon = {
  add: { icon: Plus, color: '#10b981' },
  fix: { icon: Wrench, color: '#f59e0b' },
  change: { icon: ArrowRight, color: '#60a5fa' },
}

const labelStyle: Record<string, { bg: string; color: string; text: string }> = {
  novo:      { bg: 'rgba(16,185,129,0.12)',  color: '#34d399', text: 'novo' },
  melhoria:  { bg: 'rgba(96,165,250,0.12)',  color: '#60a5fa', text: 'melhoria' },
  fix:       { bg: 'rgba(245,158,11,0.12)',  color: '#fbbf24', text: 'fix' },
  segurança: { bg: 'rgba(239,68,68,0.12)',   color: '#f87171', text: 'segurança' },
}

export function ChangelogModal({ isOpen, onClose }: ChangelogModalProps) {
  useEffect(() => {
    if (!isOpen) return
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [isOpen, onClose])

  if (!isOpen) return null

  return createPortal(
    <div
      className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center sm:justify-end p-0 sm:p-4 sm:pr-6"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{ background: 'rgba(7,7,15,0.6)', backdropFilter: 'blur(6px)' }}
    >
      <div
        className="w-full sm:w-[360px] max-h-[85vh] flex flex-col rounded-t-2xl sm:rounded-2xl overflow-hidden"
        style={{
          background: 'rgba(13,13,31,0.98)',
          border: '1px solid rgba(255,255,255,0.07)',
          boxShadow: '0 24px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(124,58,237,0.08)',
        }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4 shrink-0"
          style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}
        >
          <div>
            <p className="text-sm font-bold text-text-primary">Novidades</p>
            <p className="text-[11px] text-text-muted mt-0.5">v{CURRENT_VERSION}</p>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary transition-colors"
            style={{ background: 'rgba(255,255,255,0.04)' }}
          >
            <X size={14} />
          </button>
        </div>

        {/* Entries */}
        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-6">
          {changelog.map((entry, i) => (
            <div key={entry.version} className={cn(i > 0 && 'pt-5 border-t border-white/[0.04]')}>
              {/* Version header */}
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs font-bold text-text-secondary font-mono">v{entry.version}</span>
                {entry.label && (
                  <span
                    className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                    style={labelStyle[entry.label]}
                  >
                    {labelStyle[entry.label].text}
                  </span>
                )}
                <span className="text-[10px] text-text-muted ml-auto">{entry.date}</span>
              </div>

              {/* Items */}
              <ul className="space-y-2">
                {entry.items.map((item, j) => {
                  const { icon: Icon, color } = typeIcon[item.type]
                  return (
                    <li key={j} className="flex items-start gap-2">
                      <Icon size={11} className="shrink-0 mt-[3px]" style={{ color }} />
                      <span className="text-[12px] text-text-secondary leading-relaxed">{item.text}</span>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div
          className="px-5 py-3 shrink-0 text-center"
          style={{ borderTop: '1px solid rgba(255,255,255,0.04)' }}
        >
          <p className="text-[10px] text-text-muted">MetaControll · Todas as versões</p>
        </div>
      </div>
    </div>,
    document.body
  )
}
