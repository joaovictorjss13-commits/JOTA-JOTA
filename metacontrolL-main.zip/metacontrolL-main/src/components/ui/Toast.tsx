'use client'

import { useState, useEffect, createContext, useContext, useCallback } from 'react'
import { cn } from '@/lib/utils'
import { CheckCircle2, AlertTriangle, Info, X, Zap, ShieldAlert } from 'lucide-react'

type ToastType = 'success' | 'error' | 'warning' | 'info' | 'critical'

interface ToastItem {
  id: string
  type: ToastType
  title: string
  message?: string
  duration?: number
}

interface ToastContextType {
  addToast: (toast: Omit<ToastItem, 'id'>) => void
}

const ToastContext = createContext<ToastContextType>({ addToast: () => {} })

export function useToast() {
  return useContext(ToastContext)
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([])

  const addToast = useCallback((toast: Omit<ToastItem, 'id'>) => {
    const id = Date.now().toString() + Math.random().toString(36).slice(2)
    setToasts(prev => [...prev, { ...toast, id }])
  }, [])

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id))
  }, [])

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}

      {/* Toast container — top on mobile, bottom-right on desktop */}
      <div className="fixed top-4 left-4 right-4 z-[100] flex flex-col gap-2 max-w-sm w-auto pointer-events-none md:top-auto md:bottom-4 md:left-auto md:right-4 md:flex-col-reverse md:w-full">
        {toasts.map(toast => (
          <ToastCard key={toast.id} toast={toast} onRemove={removeToast} />
        ))}
      </div>
    </ToastContext.Provider>
  )
}

const STYLES: Record<ToastType, {
  border: string
  bg: string
  glow: string
  iconBg: string
  titleColor: string
  icon: React.ReactNode
}> = {
  success: {
    border: 'border-l-emerald-500 border-emerald-500/20',
    bg: 'bg-emerald-950/60',
    glow: 'shadow-emerald-500/20',
    iconBg: 'bg-emerald-500/15',
    titleColor: 'text-emerald-400',
    icon: <CheckCircle2 size={17} className="text-emerald-400" />,
  },
  error: {
    border: 'border-l-red-500 border-red-500/20',
    bg: 'bg-red-950/60',
    glow: 'shadow-red-500/20',
    iconBg: 'bg-red-500/15',
    titleColor: 'text-red-400',
    icon: <AlertTriangle size={17} className="text-red-400" />,
  },
  warning: {
    border: 'border-l-amber-500 border-amber-500/20',
    bg: 'bg-amber-950/60',
    glow: 'shadow-amber-500/20',
    iconBg: 'bg-amber-500/15',
    titleColor: 'text-amber-400',
    icon: <Zap size={17} className="text-amber-400" />,
  },
  info: {
    border: 'border-l-sky-500 border-sky-500/20',
    bg: 'bg-sky-950/60',
    glow: 'shadow-sky-500/20',
    iconBg: 'bg-sky-500/15',
    titleColor: 'text-sky-400',
    icon: <Info size={17} className="text-sky-400" />,
  },
  critical: {
    border: 'border-l-red-500 border-red-500/30',
    bg: 'bg-red-950/70',
    glow: 'shadow-red-600/30',
    iconBg: 'bg-red-500/20',
    titleColor: 'text-red-400',
    icon: <ShieldAlert size={17} className="text-red-400 animate-pulse" />,
  },
}

function ToastCard({ toast, onRemove }: { toast: ToastItem; onRemove: (id: string) => void }) {
  const [exiting, setExiting] = useState(false)
  const s = STYLES[toast.type]

  useEffect(() => {
    const duration = toast.duration ?? 5000
    const timer = setTimeout(() => {
      setExiting(true)
      setTimeout(() => onRemove(toast.id), 300)
    }, duration)
    return () => clearTimeout(timer)
  }, [toast, onRemove])

  return (
    <div
      className={cn(
        'pointer-events-auto rounded-xl p-4',
        'border border-l-[3px]',
        'shadow-2xl',
        s.border,
        s.bg,
        s.glow,
        toast.type === 'critical' && 'animate-critical-ring',
        'backdrop-blur-sm',
        'transition-all duration-300',
        exiting ? 'opacity-0 translate-x-8 scale-95' : 'opacity-100 translate-x-0 animate-slide-up'
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn('shrink-0 mt-0.5 w-8 h-8 rounded-lg flex items-center justify-center', s.iconBg)}>
          {s.icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className={cn('text-sm font-bold', s.titleColor)}>{toast.title}</p>
          {toast.message && (
            <p className="text-xs text-text-muted mt-0.5 leading-relaxed">{toast.message}</p>
          )}
        </div>
        <button
          onClick={() => { setExiting(true); setTimeout(() => onRemove(toast.id), 300) }}
          className="shrink-0 p-0.5 rounded hover:bg-white/10 text-text-muted hover:text-text-primary transition-colors"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  )
}
