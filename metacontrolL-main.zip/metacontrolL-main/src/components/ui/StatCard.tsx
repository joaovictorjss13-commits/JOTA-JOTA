'use client'

import { cn } from '@/lib/utils'
import { formatBRL, formatNumber } from '@/lib/utils'

interface StatCardProps {
  label: string
  value: number
  format?: 'currency' | 'number' | 'percent'
  glow?: 'green' | 'red' | 'yellow' | 'blue' | 'violet' | 'none'
  className?: string
}

const glowStyles: Record<string, React.CSSProperties> = {
  green:  { borderLeft: '2px solid #10b981', boxShadow: 'inset 4px 0 20px rgba(16,185,129,0.08)' },
  red:    { borderLeft: '2px solid #ef4444', boxShadow: 'inset 4px 0 20px rgba(239,68,68,0.08)' },
  yellow: { borderLeft: '2px solid #f59e0b', boxShadow: 'inset 4px 0 20px rgba(245,158,11,0.08)' },
  blue:   { borderLeft: '2px solid #3b82f6', boxShadow: 'inset 4px 0 20px rgba(59,130,246,0.08)' },
  violet: { borderLeft: '2px solid #7c3aed', boxShadow: 'inset 4px 0 20px rgba(124,58,237,0.10)' },
  none:   {},
}

export function StatCard({ label, value, format = 'currency', glow = 'none', className }: StatCardProps) {
  const formatValue = () => {
    switch (format) {
      case 'currency': return formatBRL(value)
      case 'number': return formatNumber(value)
      case 'percent': return `${Math.round(value)}%`
    }
  }

  return (
    <div
      className={cn('rounded-xl p-4 flex items-center justify-between gap-3', className)}
      style={{
        background: 'rgba(255,255,255,0.02)',
        backdropFilter: 'blur(12px)',
        border: '1px solid rgba(255,255,255,0.06)',
        boxShadow: '0 4px 16px rgba(0,0,0,0.35)',
        ...glowStyles[glow],
      }}
    >
      <span className="text-sm text-text-secondary">{label}</span>
      <span className="text-lg font-bold mono-value text-text-primary" style={{ fontFamily: 'var(--font-mono)' }}>
        {formatValue()}
      </span>
    </div>
  )
}
