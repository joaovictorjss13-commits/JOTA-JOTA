'use client'

import { useState } from 'react'
import { Crown, User, ChevronUp, ChevronDown, LogOut } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useUserProfile } from '@/hooks/useUserProfile'
import { signOut } from '@/lib/supabase-service'

export function ProfileCard() {
  const { profile, loading } = useUserProfile()
  const [expanded, setExpanded] = useState(false)

  if (loading || !profile) return null

  const initials = profile.nome
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase()

  const router = useRouter()
  const isPro = profile.isPro
  const hasDays = profile.daysRemaining !== null

  async function handleSignOut() {
    await signOut()
    router.push('/login')
  }

  return (
    <div
      className="fixed right-4 z-50 bottom-[88px] md:bottom-4"
      style={{ maxWidth: '220px' }}
    >
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-200"
        style={{
          background: 'rgba(10,10,24,0.92)',
          backdropFilter: 'blur(16px)',
          border: isPro
            ? '1px solid rgba(124,58,237,0.35)'
            : '1px solid rgba(255,255,255,0.08)',
          boxShadow: isPro
            ? '0 4px 24px rgba(124,58,237,0.18)'
            : '0 4px 16px rgba(0,0,0,0.4)',
        }}
      >
        {/* Avatar */}
        <div
          className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0"
          style={{
            background: isPro ? 'rgba(124,58,237,0.25)' : 'rgba(100,116,139,0.25)',
            border: isPro ? '1px solid rgba(167,139,250,0.4)' : '1px solid rgba(100,116,139,0.3)',
            color: isPro ? '#a78bfa' : '#94a3b8',
          }}
        >
          {initials || <User size={12} />}
        </div>

        {/* Name + plan */}
        <div className="flex-1 text-left min-w-0">
          <p className="text-xs font-semibold text-text-primary truncate leading-none mb-0.5">
            {profile.nome.split(' ')[0]}
          </p>
          {isPro ? (
            <div className="flex items-center gap-1">
              <Crown size={9} style={{ color: profile.plano === 'infinit' ? '#34d399' : '#a78bfa' }} />
              <span className="text-[10px] font-medium" style={{ color: profile.plano === 'infinit' ? '#34d399' : '#a78bfa' }}>
                {profile.plano === 'infinit' ? 'INFINIT' : 'PRO'}
              </span>
              {hasDays && profile.daysRemaining! > 0 && profile.plano !== 'infinit' && (
                <span className="text-[10px]" style={{ color: 'rgba(167,139,250,0.6)' }}>
                  · {profile.daysRemaining}d
                </span>
              )}
            </div>
          ) : (
            <span className="text-[10px] font-medium" style={{ color: '#64748b' }}>FREE</span>
          )}
        </div>

        {expanded ? (
          <ChevronUp size={12} className="text-text-muted shrink-0" />
        ) : (
          <ChevronDown size={12} className="text-text-muted shrink-0" />
        )}
      </button>

      {/* Expanded details — rendered BELOW button */}
      {expanded && (
        <div
          className="mt-1.5 px-3 py-2.5 rounded-xl"
          style={{
            background: 'rgba(10,10,24,0.97)',
            backdropFilter: 'blur(16px)',
            border: isPro
              ? '1px solid rgba(124,58,237,0.25)'
              : '1px solid rgba(255,255,255,0.06)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <p className="text-[10px] text-text-muted truncate mb-2">{profile.email}</p>

          {isPro && profile.plano === 'infinit' && (
            <div
              className="rounded-lg p-2 mb-2 flex items-center justify-between"
              style={{
                background: 'rgba(16,185,129,0.10)',
                border: '1px solid rgba(16,185,129,0.25)',
              }}
            >
              <span className="text-[10px] font-bold" style={{ color: '#34d399' }}>∞ INFINIT</span>
              <span className="text-[10px] text-text-muted">Acesso ilimitado</span>
            </div>
          )}

          {isPro && hasDays && profile.plano !== 'infinit' && (
            <div
              className="rounded-lg p-2 mb-2"
              style={{
                background: profile.daysRemaining! > 2
                  ? 'rgba(124,58,237,0.10)'
                  : 'rgba(239,68,68,0.10)',
                border: profile.daysRemaining! > 2
                  ? '1px solid rgba(124,58,237,0.25)'
                  : '1px solid rgba(239,68,68,0.25)',
              }}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-medium" style={{
                  color: profile.daysRemaining! > 2 ? '#a78bfa' : '#f87171',
                }}>
                  {profile.isTrialActive ? 'Trial PRO' : 'Assinatura PRO'}
                </span>
                <span className="text-[10px] font-bold" style={{
                  color: profile.daysRemaining! > 2 ? '#a78bfa' : '#f87171',
                }}>
                  {profile.daysRemaining! > 0
                    ? `${profile.daysRemaining} dia${profile.daysRemaining !== 1 ? 's' : ''}`
                    : 'Expirado'}
                </span>
              </div>
              <div className="h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.08)' }}>
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${Math.min(100, ((profile.daysRemaining ?? 0) / (profile.isTrialActive ? 7 : 30)) * 100)}%`,
                    background: profile.daysRemaining! > 2
                      ? 'linear-gradient(90deg,#7c3aed,#a78bfa)'
                      : '#ef4444',
                  }}
                />
              </div>
            </div>
          )}

          {!isPro && (
            <button
              onClick={() => router.push('/assinatura')}
              className="w-full rounded-lg px-2 py-1.5 text-center transition-all duration-150 active:scale-95 mb-2"
              style={{
                background: 'linear-gradient(135deg,#7c3aed,#6d28d9)',
                border: '1px solid rgba(167,139,250,0.35)',
                boxShadow: '0 2px 8px rgba(124,58,237,0.3)',
              }}
            >
              <span className="text-[10px] font-semibold" style={{ color: '#f0e6ff' }}>
                Renovar plano PRO
              </span>
            </button>
          )}

          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-2 rounded-lg px-2 py-1.5 transition-all duration-150 active:scale-95"
            style={{
              background: 'rgba(239,68,68,0.08)',
              border: '1px solid rgba(239,68,68,0.18)',
            }}
          >
            <LogOut size={11} style={{ color: '#f87171' }} />
            <span className="text-[10px] font-semibold" style={{ color: '#f87171' }}>
              Sair
            </span>
          </button>
        </div>
      )}
    </div>
  )
}
