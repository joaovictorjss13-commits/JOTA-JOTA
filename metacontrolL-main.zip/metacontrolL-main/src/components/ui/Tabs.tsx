'use client'

import { useRef } from 'react'
import { cn } from '@/lib/utils'

interface TabItem {
  key: string
  label: string
  icon?: React.ReactNode
}

interface TabsProps {
  tabs: TabItem[]
  active: string
  onChange: (key: string) => void
  className?: string
}

function ripple(e: React.MouseEvent<HTMLButtonElement>) {
  const btn = e.currentTarget
  const circle = document.createElement('span')
  const rect = btn.getBoundingClientRect()
  const size = Math.max(rect.width, rect.height) * 1.4
  circle.style.cssText = `
    position:absolute;
    width:${size}px;height:${size}px;
    left:${e.clientX - rect.left - size / 2}px;
    top:${e.clientY - rect.top - size / 2}px;
    border-radius:50%;
    background:rgba(167,139,250,0.18);
    transform:scale(0);
    animation:ripple-expand 0.5s ease-out forwards;
    pointer-events:none;
  `
  btn.style.position = 'relative'
  btn.style.overflow = 'hidden'
  btn.appendChild(circle)
  setTimeout(() => circle.remove(), 550)
}

export function Tabs({ tabs, active, onChange, className }: TabsProps) {
  return (
    <div
      className={cn('flex items-center gap-1 overflow-x-auto scrollbar-hide p-1 rounded-xl', className)}
      style={{
        background: 'rgba(255,255,255,0.025)',
        backdropFilter: 'blur(14px)',
        border: '1px solid rgba(255,255,255,0.07)',
      }}
    >
      {tabs.map((tab) => {
        const isActive = active === tab.key
        return (
          <button
            key={tab.key}
            onClick={(e) => { ripple(e); onChange(tab.key) }}
            className={cn(
              'relative flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold',
              'whitespace-nowrap shrink-0',
              'cursor-pointer select-none',
              'transition-all duration-200',
              'hover:scale-[1.03] active:scale-[0.96]',
              isActive
                ? 'text-white'
                : 'text-text-muted hover:text-text-secondary hover:bg-white/5'
            )}
            style={isActive ? {
              background: 'linear-gradient(135deg, rgba(124,58,237,0.30), rgba(109,40,217,0.18))',
              border: '1px solid rgba(124,58,237,0.40)',
              boxShadow: '0 0 18px rgba(124,58,237,0.25), inset 0 1px 0 rgba(255,255,255,0.10)',
            } : {
              border: '1px solid transparent',
            }}
          >
            {tab.icon && (
              <span className={cn('transition-opacity duration-200', isActive ? 'opacity-100' : 'opacity-40')}>
                {tab.icon}
              </span>
            )}
            {tab.label}
            {/* Active underline dot */}
            {isActive && (
              <span
                className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-4 h-0.5 rounded-full"
                style={{ background: 'linear-gradient(90deg, #a78bfa, #7c3aed)' }}
              />
            )}
          </button>
        )
      })}
    </div>
  )
}

// Pill-style tabs for filters
interface PillTabsProps {
  options: string[]
  active: string
  onChange: (value: string) => void
  className?: string
  colorMap?: Record<string, { bg: string; shadow: string; text?: string }>
}

const STATUS_COLORS: Record<string, { bg: string; shadow: string; text: string }> = {
  normal:    { bg: 'linear-gradient(135deg,#059669,#047857)',   shadow: '0 0 14px rgba(5,150,105,0.50)',  text: '#fff' },
  pendente:  { bg: 'linear-gradient(135deg,#d97706,#b45309)',   shadow: '0 0 14px rgba(217,119,6,0.50)',   text: '#fff' },
  bloqueado: { bg: 'linear-gradient(135deg,#dc2626,#b91c1c)',   shadow: '0 0 14px rgba(220,38,38,0.55)',   text: '#fff' },
  análise:   { bg: 'linear-gradient(135deg,#0284c7,#0369a1)',   shadow: '0 0 14px rgba(2,132,199,0.50)',   text: '#fff' },
  analise:   { bg: 'linear-gradient(135deg,#0284c7,#0369a1)',   shadow: '0 0 14px rgba(2,132,199,0.50)',   text: '#fff' },
}

export function PillTabs({ options, active, onChange, className, colorMap }: PillTabsProps) {
  return (
    <div className={cn('flex items-center gap-1.5 flex-nowrap overflow-x-auto scrollbar-hide', className)}>
      {options.map((opt) => {
        const isActive = active === opt
        const palette = colorMap?.[opt.toLowerCase()] ?? STATUS_COLORS[opt.toLowerCase()]
        return (
          <button
            key={opt}
            onClick={(e) => { ripple(e); onChange(opt) }}
            className={cn(
              'relative px-3 py-1.5 rounded-lg text-xs font-semibold',
              'cursor-pointer select-none',
              'transition-all duration-200',
              'hover:scale-[1.04] active:scale-[0.95]',
              isActive ? '' : 'text-text-secondary hover:text-text-primary'
            )}
            style={isActive && palette ? {
              background: palette.bg,
              boxShadow: palette.shadow,
              color: palette.text ?? '#fff',
            } : isActive ? {
              background: 'linear-gradient(135deg, #7c3aed, #6d28d9)',
              boxShadow: '0 0 14px rgba(124,58,237,0.45)',
              color: '#fff',
            } : {
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.07)',
            }}
          >
            {opt}
          </button>
        )
      })}
    </div>
  )
}
