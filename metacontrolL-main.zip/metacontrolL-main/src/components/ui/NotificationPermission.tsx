'use client'

import { useState, useEffect } from 'react'
import { cn } from '@/lib/utils'
import { Bell, X } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import {
  getNotificationPermission,
  requestNotificationPermission,
  notify,
} from '@/lib/notifications'
import { supabase } from '@/lib/supabase'

function urlBase64ToUint8Array(base64: string): ArrayBufferView {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4)
  const b64 = (base64 + padding).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(b64)
  const arr = new Uint8Array(new ArrayBuffer(raw.length))
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i)
  return arr
}

async function subscribeToPush(accessToken: string): Promise<void> {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return
  const vapidKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
  if (!vapidKey) return

  try {
    const reg = await navigator.serviceWorker.ready
    let sub = await reg.pushManager.getSubscription()

    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidKey) as unknown as BufferSource,
      })
    }

    const json = sub.toJSON()
    await fetch('/api/push/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }),
    })
  } catch {
    // Push subscription not supported or blocked — non-fatal
  }
}

export function NotificationPermission() {
  const [visible, setVisible] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      const perm = getNotificationPermission()
      const alreadyDismissed = localStorage.getItem('mc_notif_dismissed')
      if (perm !== 'unsupported' && perm !== 'granted' && perm !== 'denied' && !alreadyDismissed) {
        setVisible(true)
      }
    }, 2500)
    return () => clearTimeout(timer)
  }, [])

  const handleDismiss = () => {
    setDismissed(true)
    setTimeout(() => setVisible(false), 300)
    localStorage.setItem('mc_notif_dismissed', 'true')
  }

  const handleActivate = async () => {
    handleDismiss()
    const granted = await requestNotificationPermission()
    if (granted) {
      notify('notificacoes_ativadas')
      // Subscribe to Web Push for background/closed-app notifications
      const { data: { session } } = await supabase.auth.getSession()
      if (session?.access_token) {
        await subscribeToPush(session.access_token)
      }
    }
  }

  if (!visible) return null

  return (
    <div className={cn(
      'fixed top-4 right-4 z-[90] max-w-xs w-full',
      'transition-all duration-300',
      dismissed ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0 animate-slide-down'
    )}>
      <div className="bg-bg-surface border border-border rounded-xl p-4 shadow-2xl shadow-black/40">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-cta/15 flex items-center justify-center shrink-0">
            <Bell size={18} className="text-cta" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-bold text-text-primary">Ative os alertas</p>
                <p className="text-xs text-text-muted mt-0.5 leading-relaxed">
                  Receba notificações de remessas, bloqueios e resultados — mesmo com o app fechado
                </p>
              </div>
              <button
                onClick={handleDismiss}
                className="p-0.5 rounded hover:bg-bg-surface-hover text-text-muted hover:text-text-primary transition-colors ml-2 shrink-0"
              >
                <X size={14} />
              </button>
            </div>
            <div className="flex items-center gap-2 mt-3">
              <Button size="sm" onClick={handleActivate}>
                Ativar alertas
              </Button>
              <button
                onClick={handleDismiss}
                className="px-3 py-1.5 text-xs font-semibold text-text-secondary hover:text-text-primary transition-colors"
              >
                Depois
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
