'use client'

import { useEffect, useState, useCallback } from 'react'

type Phase = 'visible' | 'hiding' | 'gone'

const AWAY_THRESHOLD_MS_MOBILE  = 3_000       // 3s — mobile mantém comportamento original
const AWAY_THRESHOLD_MS_DESKTOP = 60_000      // 1 min — PC só recarrega após longa ausência

function getAwayThreshold(): number {
  if (typeof navigator === 'undefined') return AWAY_THRESHOLD_MS_DESKTOP
  return /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)
    ? AWAY_THRESHOLD_MS_MOBILE
    : AWAY_THRESHOLD_MS_DESKTOP
}

function showSplash(
  setPhase: (p: Phase) => void,
  duration = 1300,
  fade = 450
) {
  setPhase('visible')
  const t1 = setTimeout(() => setPhase('hiding'), duration)
  const t2 = setTimeout(() => setPhase('gone'), duration + fade)
  return () => { clearTimeout(t1); clearTimeout(t2) }
}

export function AppSplash() {
  const [phase, setPhase] = useState<Phase>('visible')

  const trigger = useCallback((quick = false) => {
    return showSplash(setPhase, quick ? 700 : 1300, quick ? 300 : 450)
  }, [])

  useEffect(() => {
    // First open
    const cleanup = trigger(false)

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => null)
    }

    const awayThreshold = getAwayThreshold()
    let hiddenAt: number | null = null
    let cleanupFn: (() => void) | null = null

    function onVisibility() {
      if (document.visibilityState === 'hidden') {
        hiddenAt = Date.now()
        return
      }
      // Came back to the tab
      if (hiddenAt !== null && Date.now() - hiddenAt >= awayThreshold) {
        if (cleanupFn) cleanupFn()
        cleanupFn = trigger(true)
      }
      hiddenAt = null
    }

    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      cleanup()
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [trigger])

  if (phase === 'gone') return null

  const isHiding = phase === 'hiding'

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 99999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#07070f',
        transition: `opacity ${isHiding ? '0.45s' : '0s'} cubic-bezier(0.4, 0, 0.2, 1)`,
        opacity: isHiding ? 0 : 1,
        pointerEvents: isHiding ? 'none' : 'all',
      }}
    >
      {/* Orb de fundo */}
      <div
        style={{
          position: 'absolute',
          width: '520px',
          height: '520px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(124,58,237,0.22) 0%, transparent 70%)',
          filter: 'blur(80px)',
          animation: 'glow-pulse 2s ease-in-out infinite',
        }}
      />

      {/* Conteúdo centralizado */}
      <div
        style={{
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          animation: 'slide-up 0.5s ease-out both',
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/logo.png"
          alt="MetaControll"
          style={{
            display: 'block',
            width: '80px',
            height: '80px',
            borderRadius: '20px',
            objectFit: 'contain',
            marginBottom: '18px',
            boxShadow: '0 0 40px rgba(124,58,237,0.55)',
            animation: 'float 2s ease-in-out infinite',
          }}
        />

        <div style={{ marginBottom: '28px' }}>
          <span
            style={{
              fontSize: '26px',
              fontWeight: 700,
              color: '#7c3aed',
              fontFamily: 'Rajdhani, sans-serif',
              letterSpacing: '0.03em',
            }}
          >
            Meta
          </span>
          <span
            style={{
              fontSize: '26px',
              fontWeight: 700,
              color: '#f1f5f9',
              fontFamily: 'Rajdhani, sans-serif',
              letterSpacing: '0.03em',
            }}
          >
            Controll
          </span>
        </div>

        {/* Barra de carregamento */}
        <div
          style={{
            width: '120px',
            height: '2px',
            background: 'rgba(255,255,255,0.08)',
            borderRadius: '2px',
            margin: '0 auto',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              height: '100%',
              background: 'linear-gradient(90deg, #7c3aed, #a78bfa, #c4b5fd)',
              boxShadow: '0 0 10px rgba(124,58,237,0.9)',
              animation: 'splash-bar 1.3s cubic-bezier(0.4, 0, 0.6, 1) forwards',
            }}
          />
        </div>
      </div>
    </div>
  )
}
