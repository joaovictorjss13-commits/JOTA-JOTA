'use client'

// SecurityGuard: monta sem efeitos colaterais.
// Proteger dados sensíveis é responsabilidade do backend (RLS, auth, autorização por endpoint).
// Bloquear DevTools/Ctrl+C no cliente não oferece proteção real e prejudica usuários legítimos
// (acessibilidade, ferramentas de assistência, gerenciadores de senha, etc.).
export function SecurityGuard() {
  return null
}
