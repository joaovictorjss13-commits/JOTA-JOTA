'use client'

import { useState, useCallback, useEffect, Suspense } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { Sidebar } from './Sidebar'
import { NavigationProgress } from './NavigationProgress'
import { ToastProvider, useToast } from '@/components/ui/Toast'
import { NotificationPermission } from '@/components/ui/NotificationPermission'
import { ProfileCard } from '@/components/ui/ProfileCard'
import { cn } from '@/lib/utils'
import { useIdleTimeout } from '@/hooks/useIdleTimeout'
import { useNotificationSync } from '@/hooks/useNotificationSync'
import { setNotifyToast } from '@/lib/notifications'
import { signOut } from '@/lib/supabase-service'
import { useUserProfile } from '@/hooks/useUserProfile'
import { Crown, Zap } from 'lucide-react'
import { SubscribeModal } from '@/components/modals/SubscribeModal'

function LivingBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: -1 }}>

      {/* ── Dot grid — breathes slowly ── */}
      <div
        style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px)',
          backgroundSize: '38px 38px',
          animation: 'dot-grid-breathe 8s ease-in-out infinite',
        }}
      />

      {/* ── Orb 1 — large violet, top-left, drifts slowly ── */}
      <div
        style={{
          position: 'absolute',
          top: '-15%', left: '-8%',
          width: '700px', height: '700px',
          borderRadius: '50%',
          background: 'rgba(124,58,237,0.13)',
          filter: 'blur(130px)',
          animation: 'orb-drift-1 32s ease-in-out infinite',
        }}
      />

      {/* ── Orb 2 — medium violet, bottom-right ── */}
      <div
        style={{
          position: 'absolute',
          bottom: '-18%', right: '-8%',
          width: '580px', height: '580px',
          borderRadius: '50%',
          background: 'rgba(109,40,217,0.10)',
          filter: 'blur(110px)',
          animation: 'orb-drift-2 26s ease-in-out infinite',
          animationDelay: '-10s',
        }}
      />

      {/* ── Orb 3 — gold accent, center-right ── */}
      <div
        style={{
          position: 'absolute',
          top: '35%', left: '55%',
          width: '380px', height: '380px',
          borderRadius: '50%',
          background: 'rgba(245,158,11,0.055)',
          filter: 'blur(90px)',
          animation: 'orb-drift-3 38s ease-in-out infinite',
          animationDelay: '-18s',
        }}
      />

      {/* ── Orb 4 — teal micro-accent, mid-left ── */}
      <div
        style={{
          position: 'absolute',
          top: '55%', left: '15%',
          width: '260px', height: '260px',
          borderRadius: '50%',
          background: 'rgba(16,185,129,0.045)',
          filter: 'blur(80px)',
          animation: 'orb-drift-4 44s ease-in-out infinite',
          animationDelay: '-6s',
        }}
      />

      {/* ── Vignette — subtle dark edges that breathe ── */}
      <div
        style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse 85% 80% at 50% 50%, transparent 40%, rgba(7,7,15,0.55) 100%)',
          animation: 'vignette-breathe 12s ease-in-out infinite',
        }}
      />

      {/* ── Dark overlay — slightly deeper background ── */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'rgba(0,0,2,0.35)',
        pointerEvents: 'none',
      }} />
    </div>
  )
}

function IdleGuard() {
  const { addToast } = useToast()
  const router = useRouter()

  const onWarn = useCallback(() => {
    addToast({
      type: 'warning',
      title: 'Sessão expirando',
      message: 'Você será desconectado em 1 minuto por inatividade.',
      duration: 58000,
    })
  }, [addToast])

  const onLogout = useCallback(async () => {
    await signOut()
    router.push('/login')
  }, [router])

  useIdleTimeout({ onWarn, onLogout })
  return null
}

function NotificationSyncMount() {
  useNotificationSync()
  return null
}

function NotificationToastBridge() {
  const { addToast } = useToast()
  useEffect(() => {
    setNotifyToast((type, title, body, duration) => {
      addToast({ type, title, message: body || undefined, duration })
    })
    return () => setNotifyToast(null)
  }, [addToast])
  return null
}

function FreePersistentBanner({ onOpenModal }: { onOpenModal: () => void }) {
  const { profile } = useUserProfile()

  if (!profile || profile.isPro) return null

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[60] flex items-center justify-between gap-3 px-4 py-2.5"
      style={{
        background: 'linear-gradient(90deg, rgba(10,8,20,0.97) 0%, rgba(30,15,60,0.97) 50%, rgba(10,8,20,0.97) 100%)',
        borderBottom: '0px solid rgba(234,179,8,0.35)',
        animation: 'free-banner-pulse 3s ease-in-out infinite',
        backdropFilter: 'blur(12px)',
      }}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <div
          className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: 'rgba(234,179,8,0.18)', border: '1px solid rgba(234,179,8,0.35)' }}
        >
          <Crown size={13} style={{ color: '#fbbf24' }} />
        </div>
        <p className="text-xs font-bold truncate" style={{ color: '#fde68a' }}>
          Sua assinatura expirou — renove agora e tenha acesso a todos os recursos!
        </p>
      </div>
      <button
        onClick={onOpenModal}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-black shrink-0 transition-all hover:scale-105 active:scale-95"
        style={{
          background: 'linear-gradient(135deg, #eab308, #d97706)',
          color: '#000',
        }}
      >
        <Zap size={11} />
        Renovar PRO
      </button>
    </div>
  )
}

function DashboardLayoutInner({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [subscribeOpen, setSubscribeOpen] = useState(false)
  const pathname = usePathname()
  const { profile } = useUserProfile()
  const isFree = profile !== null && !profile.isPro

  return (
    <div className="min-h-screen bg-bg-primary relative">
      <NavigationProgress />
      <LivingBackground />
      <FreePersistentBanner onOpenModal={() => setSubscribeOpen(true)} />
      <SubscribeModal isOpen={subscribeOpen} onClose={() => setSubscribeOpen(false)} />

      <Suspense fallback={null}>
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
      </Suspense>
      <main
        className={cn(
          'min-h-screen transition-all duration-300',
          'px-4 pb-24 md:px-10 md:pb-8 lg:px-14 xl:px-16',
          isFree ? 'pt-12 md:pt-14' : 'pt-4 md:pt-8',
          sidebarCollapsed ? 'md:ml-[64px]' : 'md:ml-[240px]'
        )}
        style={{ position: 'relative', zIndex: 1 }}
      >
        <div
          key={pathname}
          className="max-w-[1440px] mx-auto"
          style={{ animation: 'page-enter 0.40s cubic-bezier(0.16, 1, 0.3, 1) both' }}
        >
          {children}
        </div>
      </main>

      <NotificationPermission />
      <ProfileCard />
    </div>
  )
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <ToastProvider>
      <IdleGuard />
      <NotificationSyncMount />
      <NotificationToastBridge />
      <DashboardLayoutInner>{children}</DashboardLayoutInner>
    </ToastProvider>
  )
}
