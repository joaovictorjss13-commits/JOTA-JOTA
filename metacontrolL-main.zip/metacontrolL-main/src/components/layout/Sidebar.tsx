'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { cn } from '@/lib/utils'
import { signOut } from '@/lib/supabase-service'
import {
  LayoutDashboard,
  DollarSign,
  Receipt,
  CreditCard,
  GraduationCap,
  LogOut,
  Crown,
  ChevronRight,
  Lock,
} from 'lucide-react'
import { useUserProfile } from '@/hooks/useUserProfile'
import { ChangelogModal, useChangelogBadge } from '@/components/ui/ChangelogModal'
import { NotificationCenter } from '@/components/ui/NotificationCenter'

const sections = [
  {
    label: 'MENU PRINCIPAL',
    items: [
      { href: '/admin',       label: 'Admin',       icon: LayoutDashboard },
      { href: '/faturamento', label: 'Faturamento', icon: DollarSign },
      { href: '/custos',      label: 'Custos',      icon: Receipt },
    ],
  },
  {
    label: 'CONTA',
    items: [
      { href: '/assinatura', label: 'Assinatura', icon: CreditCard },
      { href: '/tutorial',   label: 'Tutorial',   icon: GraduationCap },
    ],
  },
]

const mobileNavItems: { href: string; label: string; icon: React.ElementType; isCenter?: boolean }[] = [
  { href: '/faturamento', label: 'Faturamento', icon: DollarSign },
  { href: '/custos',      label: 'Custos',      icon: Receipt },
  { href: '/admin',       label: 'Admin',       icon: LayoutDashboard, isCenter: true },
  { href: '/assinatura',  label: 'Assinatura',  icon: CreditCard },
  { href: '/tutorial',    label: 'Tutorial',    icon: GraduationCap },
]

interface SidebarProps {
  collapsed: boolean
  onToggle: () => void
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const { profile } = useUserProfile()
  const isPro = profile?.isPro ?? true
  const daysRemaining = profile?.daysRemaining ?? null
  const trialEndsAtFormatted = profile?.trialEndsAtFormatted ?? null
  const isTrialActive = profile?.isTrialActive ?? false
  const [changelogOpen, setChangelogOpen] = useState(false)
  const [confirmLogout, setConfirmLogout] = useState(false)
  const [adminSpinning, setAdminSpinning] = useState(false)
  const { hasNew, markSeen } = useChangelogBadge()
  const searchParams = useSearchParams()

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/')

  const ADMIN_CYCLE = ['visao_geral', 'minha_operacao', 'metas_fechamento', 'lixeira'] as const
  const ADMIN_TAB_LABEL: Record<string, string> = {
    visao_geral: 'Admin',
    minha_operacao: 'Minha operação',
    metas_fechamento: 'Operações',
    lixeira: 'Lixeira',
  }
  const currentAdminTab = isActive('/admin') ? (searchParams.get('tab') || 'visao_geral') : 'visao_geral'
  const currentAdminLabel = ADMIN_TAB_LABEL[currentAdminTab] || 'Admin'

  function handleAdminClick() {
    const idx = ADMIN_CYCLE.indexOf(currentAdminTab as typeof ADMIN_CYCLE[number])
    const next = idx === -1 ? ADMIN_CYCLE[0] : ADMIN_CYCLE[(idx + 1) % ADMIN_CYCLE.length]
    setAdminSpinning(true)
    setTimeout(() => setAdminSpinning(false), 500)
    router.replace(`/admin?tab=${next}`, { scroll: false })
  }

  const handleOpenChangelog = () => { setChangelogOpen(true); markSeen() }
  const handleLogout = async () => { try { await signOut() } catch (e) {} router.push('/login') }


  return (
    <>
      {/* ── Desktop Sidebar ── */}
      <aside
        onClick={collapsed ? onToggle : undefined}
        className={cn(
          'hidden md:flex fixed top-0 left-0 h-full z-40 flex-col',
          'transition-all duration-300 ease-in-out',
          collapsed ? 'w-[64px] cursor-pointer' : 'w-[240px] cursor-default',
        )}
        style={{
          background: 'rgba(10,10,20,0.72)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRight: '1px solid rgba(124,58,237,0.18)',
          boxShadow: collapsed ? 'none' : '4px 0 32px rgba(0,0,0,0.35)',
        }}
      >
        {/* ── Logo / header ── */}
        <div
          className="flex items-center h-[60px] px-4 shrink-0"
          style={{ borderBottom: '1px solid rgba(124,58,237,0.12)' }}
        >
          <div className={cn('flex items-center gap-2.5 flex-1 min-w-0', collapsed && 'justify-center')}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo.png" alt="MetaControll" className="w-8 h-8 rounded-lg object-contain shrink-0" />
            {!collapsed && (
              <span className="font-bold text-sm truncate" style={{ letterSpacing: '0.04em' }}>
                <span style={{ color: '#a78bfa' }}>Meta</span>
                <span className="text-white">Controll</span>
              </span>
            )}
          </div>
          {!collapsed && (
            <button
              onClick={onToggle}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-white/30 hover:text-[#a78bfa] hover:bg-[rgba(124,58,237,0.10)] transition-all duration-150 shrink-0"
              title="Recolher"
            >
              <ChevronRight size={14} style={{ transform: 'rotate(180deg)' }} />
            </button>
          )}
        </div>

        {/* ── Nav sections ── */}
        <nav
          className="flex-1 overflow-y-auto py-4 space-y-5"
          style={{ scrollbarWidth: 'none' }}
        >
          {sections.map((section) => (
            <div key={section.label}>
              <div className={cn('flex flex-col gap-1.5', collapsed ? 'px-2' : 'px-3')}>
                {section.items.map(({ href, label, icon: Icon }) => {
                  const active = isActive(href)
                  const isLocked = !isPro && href === '/faturamento'
                  const isAdminCycle = href === '/admin' && active

                  const sharedClassName = cn(
                    'group flex items-center gap-3 rounded-xl text-sm font-medium',
                    'transition-all duration-200',
                    collapsed ? 'justify-center p-3' : 'px-3 py-2.5',
                    active
                      ? 'text-white'
                      : isLocked
                        ? 'text-white/20 hover:text-white/35'
                        : 'text-white/35 hover:text-[#c4b5fd]',
                  )
                  const sharedStyle = active ? {
                    background: 'rgba(124,58,237,0.18)',
                    border: '1px solid rgba(124,58,237,0.30)',
                    boxShadow: '0 0 16px rgba(124,58,237,0.10)',
                  } : { border: '1px solid transparent' }

                  const iconEl = (
                    <Icon
                      size={collapsed ? 18 : 16}
                      className={cn('shrink-0 transition-all duration-200 group-hover:scale-125', isAdminCycle && adminSpinning && 'animate-spin')}
                      style={{ color: active ? '#a78bfa' : isLocked ? 'rgba(255,255,255,0.20)' : 'inherit' }}
                    />
                  )

                  if (isAdminCycle) {
                    return (
                      <button
                        key={href}
                        onClick={handleAdminClick}
                        title={collapsed ? currentAdminLabel : undefined}
                        className={sharedClassName}
                        style={sharedStyle}
                      >
                        {iconEl}
                        {!collapsed && (
                          <span
                            className="flex-1 text-left transition-opacity duration-200"
                            style={{ opacity: adminSpinning ? 0.4 : 1 }}
                          >
                            {currentAdminLabel}
                          </span>
                        )}
                        {!collapsed && <ChevronRight size={12} style={{ color: 'rgba(167,139,250,0.55)' }} />}
                      </button>
                    )
                  }

                  return (
                    <Link
                      key={href}
                      href={href}
                      title={collapsed ? label : undefined}
                      className={sharedClassName}
                      style={sharedStyle}
                    >
                      {iconEl}
                      {!collapsed && (
                        <>
                          <span className="flex-1">{label}</span>
                          {isLocked && <Lock size={11} style={{ color: 'rgba(234,179,8,0.60)' }} />}
                          {!isLocked && active && <ChevronRight size={12} style={{ color: 'rgba(167,139,250,0.55)' }} />}
                        </>
                      )}
                    </Link>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* ── Bottom area ── */}
        <div
          className={cn('shrink-0 space-y-1.5', collapsed ? 'p-2' : 'px-3 py-3')}
          style={{ borderTop: '1px solid rgba(124,58,237,0.12)' }}
        >
          {/* Profile row (expanded) */}
          {!collapsed && profile && (
            <div
              className="flex items-center gap-2.5 px-3 py-2 mb-1 rounded-xl"
              style={{
                background: 'rgba(124,58,237,0.06)',
                border: '1px solid rgba(124,58,237,0.14)',
              }}
            >
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{
                  background: isPro ? 'rgba(124,58,237,0.28)' : 'rgba(100,116,139,0.20)',
                  color: isPro ? '#a78bfa' : '#94a3b8',
                }}
              >
                {profile.nome.split(' ').slice(0, 2).map((n) => n[0]).join('').toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-white truncate leading-none">{profile.nome}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  {isPro ? (
                    <>
                      <Crown size={9} style={{ color: '#a78bfa' }} />
                      <span className="text-[10px]" style={{ color: '#a78bfa' }}>
                        PRO{isTrialActive && daysRemaining !== null ? ` · ${daysRemaining}d` : ''}
                      </span>
                    </>
                  ) : (
                    <span className="text-[10px] text-white/30">FREE</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Avatar (collapsed) */}
          {collapsed && profile && (
            <div className="flex justify-center mb-1">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold"
                style={{
                  background: isPro ? 'rgba(124,58,237,0.28)' : 'rgba(100,116,139,0.20)',
                  color: isPro ? '#a78bfa' : '#94a3b8',
                  border: isPro ? '1px solid rgba(167,139,250,0.25)' : '1px solid rgba(100,116,139,0.20)',
                }}
                title={`${profile.nome} — ${isPro ? 'PRO' : 'FREE'}`}
              >
                {profile.nome.split(' ').slice(0, 2).map((n) => n[0]).join('').toUpperCase()}
              </div>
            </div>
          )}

          {/* Trial progress bar */}
          {!collapsed && isPro && isTrialActive && daysRemaining !== null && daysRemaining > 0 && (
            <div className="px-1 pb-1">
              <div className="h-0.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${Math.min(100, (daysRemaining / 30) * 100)}%`,
                    background: daysRemaining <= 3 ? '#ef4444' : 'linear-gradient(90deg,#7c3aed,#a78bfa)',
                  }}
                />
              </div>
            </div>
          )}

          {/* Notifications */}
          <NotificationCenter collapsed={collapsed} />

          {/* Logout */}
          <button
            onClick={() => setConfirmLogout(true)}
            className={cn(
              'group flex items-center gap-3 w-full rounded-xl text-sm font-medium',
              'transition-all duration-200 text-white/30 hover:text-red-400',
              collapsed ? 'justify-center p-3' : 'px-3 py-2.5',
            )}
            style={{ border: '1px solid transparent' }}
            title={collapsed ? 'Sair da conta' : undefined}
          >
            <LogOut
              size={collapsed ? 18 : 16}
              className="shrink-0 transition-all duration-200 group-hover:scale-125"
            />
            {!collapsed && 'Sair da conta'}
          </button>
        </div>
      </aside>

      {/* ── Mobile Bottom Navigation — hidden on meta detail pages ── */}
      <nav
        className={cn('md:hidden fixed bottom-0 left-0 right-0 z-50', pathname.startsWith('/admin/meta/') && 'hidden')}
        style={{
          background: 'rgba(8,8,20,0.97)',
          backdropFilter: 'blur(24px)',
          borderTop: '1px solid rgba(124,58,237,0.15)',
          boxShadow: '0 -4px 24px rgba(0,0,0,0.4)',
        }}
      >
        <div className="flex items-end justify-around px-1 pt-2 pb-4">
          {mobileNavItems.map(({ href, label, icon: Icon, isCenter }) => {
            const active = isActive(href)
            if (isCenter) {
              const isAdminCycle = href === '/admin' && active
              const mobileAdminLabel = isAdminCycle ? (ADMIN_TAB_LABEL[currentAdminTab] || label) : label

              const centerContent = (
                <>
                  <div
                    className="w-[52px] h-[52px] rounded-2xl flex items-center justify-center transition-all duration-200"
                    style={{
                      background: active ? 'linear-gradient(135deg, #7c3aed, #a78bfa)' : 'linear-gradient(135deg, #4c1d95, #6d28d9)',
                      border: `2px solid ${active ? 'rgba(167,139,250,0.7)' : 'rgba(124,58,237,0.45)'}`,
                      boxShadow: active ? '0 0 24px rgba(124,58,237,0.7), 0 6px 16px rgba(0,0,0,0.5)' : '0 0 14px rgba(124,58,237,0.35), 0 4px 12px rgba(0,0,0,0.4)',
                    }}
                  >
                    <Icon
                      size={22}
                      color="#fff"
                      className={cn(isAdminCycle && adminSpinning && 'animate-spin')}
                    />
                  </div>
                  <span
                    className="text-[10px] font-semibold transition-opacity duration-200"
                    style={{
                      color: active ? '#a78bfa' : 'rgba(148,163,184,0.55)',
                      opacity: isAdminCycle && adminSpinning ? 0.4 : 1,
                    }}
                  >
                    {mobileAdminLabel}
                  </span>
                </>
              )

              if (isAdminCycle) {
                return (
                  <button key={href} onClick={handleAdminClick} className="flex flex-col items-center gap-1 -translate-y-4">
                    {centerContent}
                  </button>
                )
              }
              return (
                <Link key={href} href={href} className="flex flex-col items-center gap-1 -translate-y-4">
                  {centerContent}
                </Link>
              )
            }
            return (
              <Link key={href} href={href} className="flex flex-col items-center gap-1 pt-1 min-w-[54px]">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
                  style={{
                    background: active ? 'rgba(124,58,237,0.15)' : 'transparent',
                    border: active ? '1px solid rgba(124,58,237,0.3)' : '1px solid transparent',
                  }}
                >
                  <Icon size={17} style={{ color: active ? '#c4b5fd' : 'rgba(148,163,184,0.55)' }} />
                </div>
                <span className="text-[10px] font-medium" style={{ color: active ? '#c4b5fd' : 'rgba(148,163,184,0.5)' }}>{label}</span>
              </Link>
            )
          })}
        </div>
      </nav>

      <ChangelogModal isOpen={changelogOpen} onClose={() => setChangelogOpen(false)} />

      {confirmLogout && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)' }}
        >
          <div
            className="w-full max-w-xs rounded-2xl p-6 flex flex-col gap-4"
            style={{
              background: 'rgba(10,10,20,0.98)',
              border: '1px solid rgba(124,58,237,0.20)',
              boxShadow: '0 24px 48px rgba(0,0,0,0.6)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.25)' }}
              >
                <LogOut size={18} style={{ color: '#f87171' }} />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">Sair da conta?</p>
                <p className="text-[11px] text-white/40 mt-0.5">Você precisará fazer login novamente.</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setConfirmLogout(false)}
                className="flex-1 py-2 rounded-xl text-sm font-medium text-white/50 hover:text-white transition-colors"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
              >
                Cancelar
              </button>
              <button
                onClick={handleLogout}
                className="flex-1 py-2 rounded-xl text-sm font-semibold transition-colors"
                style={{ background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.30)', color: '#f87171' }}
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
