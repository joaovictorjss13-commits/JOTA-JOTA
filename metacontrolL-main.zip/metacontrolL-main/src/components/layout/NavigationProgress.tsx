'use client'

import { usePathname } from 'next/navigation'
import { useEffect, useState, useRef } from 'react'

export function NavigationProgress() {
  const pathname = usePathname()
  const [progress, setProgress] = useState(0)
  const [visible, setVisible] = useState(false)
  const timers = useRef<ReturnType<typeof setTimeout>[]>([])

  const clear = () => timers.current.forEach(clearTimeout)

  useEffect(() => {
    clear()
    setProgress(0)
    setVisible(true)

    timers.current = [
      setTimeout(() => setProgress(20),  30),
      setTimeout(() => setProgress(55),  150),
      setTimeout(() => setProgress(80),  350),
      setTimeout(() => setProgress(95),  600),
      setTimeout(() => setProgress(100), 750),
      setTimeout(() => setVisible(false), 1050),
    ]

    return clear
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  if (!visible) return null

  return (
    <>
      {/* Top progress bar */}
      <div
        className="fixed top-0 left-0 z-[9999] h-[2px] pointer-events-none"
        style={{
          width: `${progress}%`,
          transition: progress === 0
            ? 'none'
            : progress === 100
              ? 'width 0.15s ease-out'
              : 'width 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
          background: 'linear-gradient(90deg, #7c3aed, #a78bfa, #c4b5fd)',
          boxShadow: '0 0 10px rgba(124,58,237,0.9), 0 0 20px rgba(124,58,237,0.4)',
        }}
      />
      {/* Glow dot at the end */}
      <div
        className="fixed top-0 z-[9999] w-4 h-4 rounded-full pointer-events-none"
        style={{
          left: `calc(${progress}% - 8px)`,
          top: '-5px',
          transition: progress === 0
            ? 'none'
            : `left 0.4s cubic-bezier(0.16, 1, 0.3, 1)`,
          background: 'radial-gradient(circle, rgba(167,139,250,0.9) 0%, transparent 70%)',
          opacity: progress > 0 && progress < 100 ? 1 : 0,
        }}
      />
    </>
  )
}
