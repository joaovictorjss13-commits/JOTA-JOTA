'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { cn, formatBRL } from '@/lib/utils'
import { CheckCircle2 } from 'lucide-react'

interface CloseGoalModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (data: { salario: number; gastos_operacionais: number }) => Promise<void> | void
  metaTitulo: string
  metaRede: string
  lucroAcumulado: number
  prejuizoAcumulado: number
  resultadoLiquido: number
  loading?: boolean
}

export function CloseGoalModal({
  isOpen, onClose, onConfirm, metaTitulo, metaRede,
  lucroAcumulado, prejuizoAcumulado, resultadoLiquido, loading
}: CloseGoalModalProps) {
  const router = useRouter()
  const [salario, setSalario] = useState('0')
  const [gastos, setGastos] = useState('0')

  const salarioNum = parseFloat(salario) || 0
  const gastosNum = parseFloat(gastos) || 0

  const lucroFinal = resultadoLiquido + salarioNum
  const prejuizoFinal = gastosNum
  const resultadoFinal = lucroFinal - prejuizoFinal

  const handleConfirm = async () => {
    await onConfirm({ salario: salarioNum, gastos_operacionais: gastosNum })
    router.push('/admin')
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-accent-green/15 flex items-center justify-center shrink-0">
            <CheckCircle2 size={24} className="text-accent-green" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-text-primary">Fechamento de operação</h2>
            <p className="text-sm text-text-muted">{metaTitulo} · {metaRede}</p>
          </div>
        </div>

        {/* Summary pills */}
        <div className="grid grid-cols-3 gap-2">
          <div className="text-center p-4 rounded-xl border border-border bg-bg-surface-light">
            <p className="text-xs text-text-muted uppercase font-bold tracking-wider">Lucro acumulado</p>
            <p className={cn('text-base font-bold mono-value mt-1.5', lucroAcumulado >= 0 ? 'text-accent-green' : 'text-accent-red')}>
              {formatBRL(Math.max(0, lucroAcumulado))}
            </p>
          </div>
          <div className="text-center p-4 rounded-xl border border-border bg-bg-surface-light">
            <p className="text-xs text-text-muted uppercase font-bold tracking-wider">Prejuízo acumulado</p>
            <p className="text-base font-bold mono-value mt-1.5 text-accent-red">{formatBRL(prejuizoAcumulado)}</p>
          </div>
          <div className="text-center p-4 rounded-xl border border-border bg-bg-surface-light">
            <p className="text-xs text-text-muted uppercase font-bold tracking-wider">Resultado</p>
            <div className="mt-1.5"><MoneyDisplay value={resultadoLiquido} size="sm" /></div>
          </div>
        </div>

        {/* Input fields */}
        <div className="space-y-5">
          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-2">
              Lucro adicional (R$) <span className="text-accent-green">+ LUCRO</span>
            </label>
            <input
              type="number"
              value={salario}
              onChange={(e) => setSalario(e.target.value)}
              step="0.01"
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary focus:outline-none focus:border-accent-green/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-2">
              Gastos operacionais (R$) <span className="text-accent-red">— PREJUÍZO</span>
            </label>
            <input
              type="number"
              value={gastos}
              onChange={(e) => setGastos(e.target.value)}
              step="0.01"
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary focus:outline-none focus:border-accent-green/50 transition-all"
            />
          </div>
        </div>

        {/* Result summary */}
        <div className="p-5 rounded-xl border border-border bg-bg-surface-light space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">Acumulado</p>
              <p className="text-xs text-text-muted">Resultado + Lucro adicional</p>
            </div>
            <p className={cn('text-sm font-bold mono-value', lucroFinal >= 0 ? 'text-accent-green' : 'text-accent-red')}>
              {formatBRL(lucroFinal)}
            </p>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">Prejuízo final</p>
              <p className="text-[10px] text-text-muted">Acumulado + Gastos</p>
            </div>
            <p className="text-sm font-bold mono-value text-accent-red">{formatBRL(prejuizoFinal)}</p>
          </div>
          <div className="border-t border-border pt-2 mt-2">
            <div className="flex items-center justify-between">
              <p className="text-base font-black">Resultado final</p>
              <MoneyDisplay value={resultadoFinal} size="lg" />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <Button variant="secondary" size="lg" className="flex-1" onClick={onClose} disabled={loading}>
            Cancelar
          </Button>
          <Button
            size="lg"
            className="flex-1 bg-accent-green hover:bg-accent-green/80 text-black"
            onClick={handleConfirm}
            disabled={loading}
          >
            <CheckCircle2 size={16} />
            {loading ? 'Fechando...' : 'Confirmar fechamento'}
          </Button>
        </div>
      </div>
    </Modal>
  )
}
