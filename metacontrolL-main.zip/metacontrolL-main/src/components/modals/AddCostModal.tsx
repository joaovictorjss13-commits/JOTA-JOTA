'use client'

import { useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { cn } from '@/lib/utils'
import { Plus } from 'lucide-react'
import { costTypeList } from '@/lib/cost-constants'

interface AddCostModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit?: (data: any) => void
}

export function AddCostModal({ isOpen, onClose, onSubmit }: AddCostModalProps) {
  const [tipo, setTipo] = useState('')
  const [valor, setValor] = useState('')
  const [data, setData] = useState(new Date().toISOString().split('T')[0])
  const [nota, setNota] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (!tipo || !valor) return
    setLoading(true)

    onSubmit?.({ tipo, valor: parseFloat(valor), data, nota: nota || undefined })

    setLoading(false)
    onClose()
    setTipo('')
    setValor('')
    setNota('')
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Adicionar custo" subtitle="Registre um gasto operacional">
      <div className="space-y-4">
        {/* Type */}
        <div>
          <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
            Tipo de custo *
          </label>
          <div className="grid grid-cols-3 gap-2">
            {costTypeList.map(t => (
              <button
                key={t.value}
                type="button"
                onClick={() => setTipo(t.value)}
                className={cn(
                  'py-2.5 rounded-xl text-xs font-semibold border transition-all duration-200',
                  tipo === t.value
                    ? 'bg-accent-green/15 border-accent-green/30 text-accent-green'
                    : 'bg-bg-surface-light border-border text-text-secondary hover:border-border-light'
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Value + Date */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              Valor (R$) *
            </label>
            <input
              type="number"
              value={valor}
              onChange={(e) => setValor(e.target.value)}
              placeholder="0,00"
              step="0.01"
              min="0.01"
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary placeholder:text-text-muted
                         focus:outline-none focus:border-accent-green/50 transition-all duration-200"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              Data
            </label>
            <input
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                         text-text-primary
                         focus:outline-none focus:border-accent-green/50 transition-all duration-200"
            />
          </div>
        </div>

        {/* Note */}
        <div>
          <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
            Nota (opcional)
          </label>
          <input
            type="text"
            value={nota}
            onChange={(e) => setNota(e.target.value)}
            placeholder="Descrição do custo"
            className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                       text-text-primary placeholder:text-text-muted
                       focus:outline-none focus:border-accent-green/50 transition-all duration-200"
          />
        </div>

        <Button
          onClick={handleSubmit}
          size="lg"
          className="w-full"
          disabled={!tipo || !valor || loading}
        >
          <Plus size={16} />
          {loading ? 'Salvando...' : 'Adicionar custo'}
        </Button>
      </div>
    </Modal>
  )
}
