'use client'

import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import {
  Crown, X, Sparkles, BarChart3, Bell, TrendingUp, Shield, Activity,
  QrCode, Copy, Check, Loader2, AlertCircle, PartyPopper, ChevronRight, CheckCircle2,
} from 'lucide-react'

type ModalStep = 'benefits' | 'qrcode' | 'success'

interface QrCodeData {
  chargeId: string
  qrCode: { imagem: string; copiaCola: string; expiracao: string }
}

interface Props {
  isOpen: boolean
  onClose: () => void
}

export function SubscribeModal({ isOpen, onClose }: Props) {
  const panelRef = useRef<HTMLDivElement>(null)
  const [step, setStep] = useState<ModalStep>('benefits')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [qrData, setQrData] = useState<QrCodeData | null>(null)
  const [copied, setCopied] = useState(false)
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (isOpen && panelRef.current) {
      panelRef.current.scrollIntoView({ block: 'center', behavior: 'smooth' })
    }
    if (!isOpen) {
      stopPolling()
      setStep('benefits'); setError(''); setQrData(null); setCopied(false)
    }
  }, [isOpen])

  function stopPolling() {
    if (pollingRef.current) { clearInterval(pollingRef.current); pollingRef.current = null }
  }

  function startPolling(chargeId: string, token: string) {
    stopPolling()
    pollingRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/pagamentos/pix/${chargeId}/status`, {
          headers: { 'Authorization': `Bearer ${token}` },
        })
        if (!res.ok) return
        const json = await res.json()
        if (json.status === 'pago') {
          stopPolling()
          setStep('success')
          setTimeout(() => window.location.reload(), 1500)
        }
      } catch { }
    }, 4000)
  }

  async function getToken(): Promise<string> {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session?.access_token) throw new Error('Sessão expirada. Faça login novamente.')
    return session.access_token
  }

  async function handleGerarPix() {
    setError('')
    setLoading(true)
    try {
      const token = await getToken()
      const res = await fetch('/api/pagamentos/pix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({}),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error ?? 'Erro ao gerar PIX')
      setQrData(json.data)
      setStep('qrcode')
      startPolling(json.data.chargeId, token)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function handleCopy() {
    if (!qrData) return
    navigator.clipboard.writeText(qrData.qrCode.copiaCola)
    setCopied(true)
    setTimeout(() => setCopied(false), 2500)
  }

  if (!isOpen) return null
  return (
    <div
      className="fixed inset-0 z-[200] flex items-start md:items-center justify-center overflow-y-auto p-4 pt-8 pb-28 md:py-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div
        ref={panelRef}
        className="w-full max-w-lg rounded-2xl overflow-hidden my-auto"
        style={{
          background: 'rgba(10,10,24,0.98)',
          border: '1px solid rgba(124,58,237,0.35)',
          boxShadow: '0 0 60px rgba(124,58,237,0.25), 0 24px 48px rgba(0,0,0,0.6)',
        }}
      >
        {/* Header */}
        <div
          className="relative px-6 pt-6 pb-5"
          style={{
            background: 'linear-gradient(135deg, rgba(124,58,237,0.15) 0%, rgba(109,40,217,0.06) 100%)',
            borderBottom: '1px solid rgba(124,58,237,0.15)',
          }}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-white/5 transition-all"
          >
            <X size={16} />
          </button>
          <div className="flex items-center gap-3 mb-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: 'rgba(124,58,237,0.20)', border: '1px solid rgba(167,139,250,0.35)' }}
            >
              <Crown size={20} style={{ color: '#a78bfa' }} />
            </div>
            <div>
              <span
                className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full mb-1"
                style={{ background: 'rgba(124,58,237,0.20)', color: '#a78bfa', border: '1px solid rgba(124,58,237,0.35)' }}
              >
                <Sparkles size={9} /> OFERTA EXCLUSIVA
              </span>
              <h2 className="text-xl font-black">MetaControll PRO</h2>
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black" style={{ color: '#a78bfa' }}>R$ 29,90</span>
            <span className="text-sm text-text-muted">/mês</span>
            <span
              className="ml-auto text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse"
              style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.30)' }}
            >
              🔥 ÚLTIMAS VAGAS
            </span>
          </div>
          <p className="text-xs text-text-muted mt-0.5">Pagamento único via PIX · Ativação imediata</p>
        </div>

        {/* STEP: benefits */}
        {step === 'benefits' && (
          <>
            <div className="px-6 py-4">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-wider mb-3">
                Tudo que você desbloqueia
              </p>
              <div className="space-y-2">
                {[
                  { icon: BarChart3, title: 'Dashboard completo', desc: 'Lucro, metas e remessas sem limites' },
                  { icon: Sparkles, title: 'Inteligência IA', desc: 'Previsões automáticas e insights estratégicos' },
                  { icon: Bell, title: 'Alertas estratégicos', desc: 'Notificações instantâneas de eventos financeiros' },
                  { icon: TrendingUp, title: 'Ranking de redes', desc: 'Veja qual rede gera mais lucro para você' },
                  { icon: Activity, title: 'Dados em tempo real', desc: 'Cada remessa aparece no instante em que acontece' },
                  { icon: Shield, title: 'Relatórios avançados', desc: 'Análises completas do seu faturamento' },
                ].map(({ icon: Icon, title, desc }) => (
                  <div key={title} className="flex items-start gap-3 py-1.5">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                      style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.25)' }}
                    >
                      <Icon size={13} style={{ color: '#10b981' }} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-text-primary leading-none mb-0.5">{title}</p>
                      <p className="text-[11px] text-text-muted">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="px-6 pb-6 pt-2">
              {error && (
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs mb-3"
                  style={{ background: 'rgba(239,68,68,0.10)', color: '#f87171', border: '1px solid rgba(239,68,68,0.25)' }}
                >
                  <AlertCircle size={13} /> {error}
                </div>
              )}
              <button
                onClick={handleGerarPix}
                disabled={loading}
                className="w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
                style={{
                  background: 'linear-gradient(135deg, #059669, #10b981, #34d399)',
                  boxShadow: '0 0 32px rgba(16,185,129,0.55), 0 4px 16px rgba(16,185,129,0.30)',
                  color: '#fff',
                  letterSpacing: '0.04em',
                }}
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <QrCode size={17} />}
                {loading ? 'GERANDO SEU PIX...' : 'GERAR PIX QRCODE'}
                {!loading && <ChevronRight size={16} />}
              </button>
              <p className="text-center text-[10px] text-text-muted mt-2">
                🔒 PIX seguro · Ativação imediata · Cancele quando quiser
              </p>
            </div>
          </>
        )}

        {/* STEP: qrcode */}
        {step === 'qrcode' && qrData && (
          <div className="px-6 py-6 flex flex-col items-center gap-4">
            <div
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs"
              style={{ background: 'rgba(16,185,129,0.10)', color: '#34d399', border: '1px solid rgba(16,185,129,0.25)' }}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              PIX gerado com sucesso! Pague agora e ative em segundos.
            </div>
            <div className="rounded-2xl p-3" style={{ background: '#fff', boxShadow: '0 0 40px rgba(16,185,129,0.30)' }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`data:image/png;base64,${qrData.qrCode.imagem}`} alt="QR Code PIX" className="w-48 h-48 object-contain" />
            </div>
            <p className="text-xs text-text-muted text-center">
              Expira em: <span className="text-text-secondary font-semibold">
                {new Date(qrData.qrCode.expiracao).toLocaleString('pt-BR')}
              </span>
            </p>
            <div className="w-full">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-wider mb-1.5">PIX Copia e Cola</p>
              <div className="flex gap-2">
                <input readOnly value={qrData.qrCode.copiaCola}
                  className="flex-1 px-3 py-2 rounded-xl text-xs font-mono bg-white/5 border border-white/10 text-text-muted truncate" />
                <button
                  onClick={handleCopy}
                  className="px-4 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95 shrink-0"
                  style={{
                    background: copied ? 'rgba(16,185,129,0.20)' : 'linear-gradient(135deg, #059669, #10b981)',
                    color: copied ? '#34d399' : '#fff',
                    border: copied ? '1px solid rgba(16,185,129,0.40)' : 'none',
                    boxShadow: copied ? 'none' : '0 0 16px rgba(16,185,129,0.40)',
                  }}
                >
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                  {copied ? 'Copiado!' : 'Copiar'}
                </button>
              </div>
            </div>
            <p className="text-[10px] text-text-muted text-center">
              Após o pagamento, sua conta será ativada automaticamente · suporte@metacontroll.io
            </p>
            <div className="flex items-center justify-center gap-2 text-[11px] text-text-muted">
              <Loader2 size={12} className="animate-spin" />
              Aguardando confirmação do pagamento...
            </div>
          </div>
        )}

        {/* STEP: success */}
        {step === 'success' && (
          <div className="px-6 py-10 flex flex-col items-center gap-4 text-center">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(16,185,129,0.15)', border: '2px solid rgba(16,185,129,0.40)', boxShadow: '0 0 40px rgba(16,185,129,0.35)' }}
            >
              <PartyPopper size={36} style={{ color: '#10b981' }} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-white mb-1">Pagamento confirmado!</h3>
              <p className="text-sm text-text-muted">Sua conta PRO foi ativada. Recarregando...</p>
            </div>
            <div
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold"
              style={{ background: 'rgba(16,185,129,0.12)', color: '#34d399', border: '1px solid rgba(16,185,129,0.25)' }}
            >
              <CheckCircle2 size={16} />
              MetaControll PRO ativo por 30 dias
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
