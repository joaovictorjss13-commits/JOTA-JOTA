'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { Zap } from 'lucide-react'
import { createMeta } from '@/lib/supabase-service'
import { useToast } from '@/components/ui/Toast'
import { notify } from '@/lib/notifications'

interface NewGoalModalProps {
  isOpen: boolean
  onClose: () => void
  onCreated?: () => void
}

export function NewGoalModal({ isOpen, onClose, onCreated }: NewGoalModalProps) {
  const router = useRouter()
  const { addToast } = useToast()
  const [plataforma, setPlataforma] = useState('')
  const [titulo, setTitulo] = useState('')
  const [tipo, setTipo] = useState('Métodos')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (!plataforma || !titulo) return
    setLoading(true)

    try {
      const meta = await createMeta({
        titulo,
        plataforma,
        rede_sigla: '',
        contas_total: 0,
        modelo: 'salario_bau',
      })

      addToast({
        type: 'success',
        title: 'Operação criada!',
        message: `${titulo} · ${plataforma} · ${tipo}`,
      })
      notify('meta_criada', { titulo, rede: plataforma })

      setPlataforma('')
      setTitulo('')
      setTipo('Métodos')
      onCreated?.()
      onClose()
      router.push(`/admin/meta/${meta.id}?titulo=${encodeURIComponent(titulo)}&plataforma=${encodeURIComponent(plataforma)}`)
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erro ao criar operação',
        message: err.message || 'Tente novamente',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Nova operação" subtitle="Configure e inicie sua operação">
      <div className="space-y-5">
        {/* Platform */}
        <div>
          <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
            Plataforma *
          </label>
          <input
            type="text"
            value={plataforma}
            onChange={(e) => setPlataforma(e.target.value)}
            placeholder="Nome da plataforma"
            className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                       text-text-primary placeholder:text-text-muted
                       focus:outline-none focus:border-accent-green/50 transition-all duration-200"
          />
        </div>

        {/* Tipo */}
        <div>
          <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
            Tipo
          </label>
          <div className="grid grid-cols-4 gap-2">
            {['Métodos', 'Delay', 'CPA', 'Outros'].map(t => (
              <button
                key={t}
                type="button"
                onClick={() => setTipo(t)}
                className={`py-2.5 rounded-xl text-sm font-semibold border transition-all duration-200 ${
                  tipo === t
                    ? 'bg-cta text-white border-cta shadow-lg shadow-cta/20'
                    : 'bg-bg-surface-light border-border text-text-secondary hover:border-border-light'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <div>
          <label className="block text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
            Título *
          </label>
          <input
            type="text"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            placeholder="Ex: Meta Abril"
            className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm
                       text-text-primary placeholder:text-text-muted
                       focus:outline-none focus:border-accent-green/50 transition-all duration-200"
          />
        </div>

        {/* Submit */}
        <Button
          onClick={handleSubmit}
          size="lg"
          className="w-full"
          disabled={!plataforma || !titulo || loading}
        >
          <Zap size={16} />
          {loading ? 'Criando...' : 'Iniciar operação'}
        </Button>
      </div>
    </Modal>
  )
}
