'use client'

import { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { Edit } from 'lucide-react'
import { updateMeta } from '@/lib/supabase-service'
import { useToast } from '@/components/ui/Toast'

interface EditMetaModalProps {
  isOpen: boolean
  onClose: () => void
  meta: {
    id: string
    titulo: string
    plataforma: string
    rede_sigla: string
    contas_total: number
    notas?: string | null
    tipo?: string | null
  }
  onSaved: (updated: { titulo: string; plataforma: string; rede_sigla: string; contas_total: number }) => void
}

const TIPOS = ['Métodos', 'Delay', 'CPA', 'Outros']

export function EditMetaModal({ isOpen, onClose, meta, onSaved }: EditMetaModalProps) {
  const { addToast } = useToast()
  const [titulo, setTitulo] = useState(meta.titulo)
  const [plataforma, setPlataforma] = useState(meta.plataforma)
  const [contas, setContas] = useState(String(meta.contas_total || 0))
  const [notas, setNotas] = useState(meta.notas || '')
  const [tipo, setTipo] = useState(meta.tipo || 'Métodos')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setTitulo(meta.titulo)
      setPlataforma(meta.plataforma)
      setContas(String(meta.contas_total || 0))
      setNotas(meta.notas || '')
      setTipo(meta.tipo || 'Métodos')
    }
  }, [isOpen, meta])

  const handleSave = async () => {
    if (!titulo || !plataforma) return
    setLoading(true)
    try {
      await updateMeta(meta.id, {
        titulo,
        plataforma,
        rede_sigla: meta.rede_sigla,
        contas_total: parseInt(contas) || 0,
        notas: notas || undefined,
      })
      addToast({ type: 'success', title: 'Operação atualizada!', message: `${titulo} · ${plataforma}` })
      onSaved({ titulo, plataforma, rede_sigla: meta.rede_sigla, contas_total: parseInt(contas) || 0 })
      onClose()
    } catch (err: any) {
      addToast({ type: 'error', title: 'Erro ao salvar', message: err.message })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cta/15 flex items-center justify-center shrink-0">
            <Edit size={18} className="text-cta" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Editar operação</h2>
            <p className="text-xs text-text-muted">Alterações aparecem em todos os cálculos e no histórico</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-1.5">Título *</label>
            <input
              type="text"
              value={titulo}
              onChange={e => setTitulo(e.target.value)}
              placeholder="Ex: 30 DEP A8"
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-cta/50 transition-all"
            />
          </div>

          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-1.5">Tipo</label>
            <div className="grid grid-cols-4 gap-2">
              {TIPOS.map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTipo(t)}
                  className={`py-2.5 rounded-xl text-sm font-semibold border transition-all duration-200 ${
                    tipo === t
                      ? 'bg-cta text-white border-cta shadow-lg shadow-cta/20'
                      : 'bg-bg-surface-light border-border text-text-secondary hover:border-border-light'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-1.5">Plataforma *</label>
            <input
              type="text"
              value={plataforma}
              onChange={e => setPlataforma(e.target.value)}
              placeholder="Ex: Betano, ESC Online"
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-cta/50 transition-all"
            />
          </div>

          <div>
            <label className="block text-xs text-text-muted uppercase font-semibold mb-1.5">Observações</label>
            <input
              type="text"
              value={notas}
              onChange={e => setNotas(e.target.value)}
              placeholder="Opcional..."
              className="w-full px-4 py-3 bg-bg-surface-light border border-border rounded-xl text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-cta/50 transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 pt-1">
          <Button variant="secondary" size="lg" className="flex-1" onClick={onClose} disabled={loading}>
            Cancelar
          </Button>
          <Button
            size="lg"
            className="flex-1"
            onClick={handleSave}
            disabled={!titulo || !plataforma || loading}
          >
            {loading ? 'Salvando...' : 'Salvar alterações'}
          </Button>
        </div>
      </div>
    </Modal>
  )
}
