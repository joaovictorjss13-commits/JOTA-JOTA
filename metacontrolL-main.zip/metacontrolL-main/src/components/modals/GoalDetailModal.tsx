'use client'

import { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { StatusBadge } from '@/components/ui/Badge'
import { MoneyDisplay } from '@/components/ui/MoneyDisplay'
import { useToast } from '@/components/ui/Toast'
import { cn, formatBRL } from '@/lib/utils'
import { getRemessas } from '@/lib/supabase-service'
import {
  Edit2, Trash2, X, CheckCircle2,
  Lock, Clock, Loader2, DollarSign
} from 'lucide-react'

interface GoalDetailModalProps {
  isOpen: boolean
  onClose: () => void
  meta?: any
  onEdit?: (meta: any) => void
  onDelete?: (meta: any) => void
}

interface Remessa {
  id: string
  titulo: string
  contas: number
  deposito: number
  saque: number
  resultado: number
  status: string
  created_at: string
}

interface TimelineEvent {
  type: 'created' | 'remessa' | 'fechada' | 'finalizada' | 'reativada' | 'bloqueado'
  label: string
  sub?: string
  date: string
}

function buildTimeline(meta: any, remessas: Remessa[]): TimelineEvent[] {
  const events: TimelineEvent[] = []

  if (meta.created_at) {
    events.push({ type: 'created', label: `Meta criada: ${meta.titulo}`, sub: 'Operador', date: meta.created_at })
  }
  remessas.slice().reverse().forEach(r => {
    const st = r.status.toLowerCase()
    if (st === 'bloqueado') {
      events.push({ type: 'bloqueado', label: `Remessa bloqueada: ${r.titulo || 'Remessa'}`, sub: `Dep: ${formatBRL(r.deposito)} perdido`, date: r.created_at })
    } else {
      events.push({ type: 'remessa', label: `Remessa registrada: ${r.titulo || 'Remessa'}`, sub: `Resultado: ${formatBRL(r.resultado)}`, date: r.created_at })
    }
  })
  if (meta.fechada_at) {
    events.push({ type: 'fechada', label: `Meta fechada: ${meta.titulo} — Lucro final: ${formatBRL(meta.lucro_final || 0)}`, sub: 'Operador', date: meta.fechada_at })
  }
  if (meta.finalizada_at) {
    events.push({ type: 'finalizada', label: `Meta finalizada: ${meta.titulo}`, sub: 'Operador', date: meta.finalizada_at })
  }

  return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

function TimelineDot({ type }: { type: TimelineEvent['type'] }) {
  if (type === 'created') return <span className="w-4 h-4 rounded-full bg-accent-green/20 border border-accent-green flex items-center justify-center text-accent-green text-[9px] font-bold">+</span>
  if (type === 'fechada' || type === 'finalizada') return <span className="w-4 h-4 rounded-full bg-accent-green/20 border border-accent-green flex items-center justify-center"><CheckCircle2 size={9} className="text-accent-green" /></span>
  if (type === 'bloqueado') return <span className="w-4 h-4 rounded-full bg-accent-red/20 border border-accent-red flex items-center justify-center"><Lock size={9} className="text-accent-red" /></span>
  if (type === 'reativada') return <span className="w-4 h-4 rounded-full bg-accent-yellow/20 border border-accent-yellow flex items-center justify-center text-[9px] text-accent-yellow font-bold">↺</span>
  return <span className="w-4 h-4 rounded-full bg-accent-blue/20 border border-accent-blue flex items-center justify-center"><DollarSign size={9} className="text-accent-blue" /></span>
}

export function GoalDetailModal({ isOpen, onClose, meta, onEdit, onDelete }: GoalDetailModalProps) {
  const { addToast } = useToast()
  const [remessas, setRemessas] = useState<Remessa[]>([])
  const [loadingRemessas, setLoadingRemessas] = useState(false)

  useEffect(() => {
    if (!isOpen || !meta) return
    setLoadingRemessas(true)
    getRemessas(meta.id)
      .then(data => setRemessas(data.map((r: any) => ({
        id: r.id,
        titulo: r.titulo || 'Remessa',
        contas: r.contas,
        deposito: Number(r.deposito),
        saque: Number(r.saque),
        resultado: Number(r.saque) - Number(r.deposito),
        status: r.status,
        created_at: r.created_at,
      }))))
      .catch(err => addToast({ type: 'error', title: 'Erro', message: err.message }))
      .finally(() => setLoadingRemessas(false))
  }, [isOpen, meta?.id])

  if (!meta) return null

  const normalRemessas = remessas.filter(r => r.status.toLowerCase() === 'normal')
  const bloqueadoRemessas = remessas.filter(r => r.status.toLowerCase() === 'bloqueado')
  const depositoTotal = normalRemessas.reduce((a, r) => a + r.deposito, 0)
  const depositoTotalGeral = remessas.reduce((a, r) => a + r.deposito, 0)
  const saqueTotal = normalRemessas.reduce((a, r) => a + r.saque, 0)
  const bloqueadoPerdas = bloqueadoRemessas.reduce((a, r) => a + r.deposito, 0)
  const lucro = saqueTotal - depositoTotal
  const prejuizo = normalRemessas.reduce((a, r) => a + (r.resultado < 0 ? Math.abs(r.resultado) : 0), 0) + bloqueadoPerdas
  const taxaAcerto = normalRemessas.length > 0
    ? Math.round((normalRemessas.filter(r => r.resultado > 0).length / normalRemessas.length) * 100)
    : 0
  const liquido = lucro - bloqueadoPerdas

  const timeline = buildTimeline(meta, remessas)
  const progressPct = Math.min(100, Math.round(((meta.contas_atingidas || 0) / (meta.contas_total || 1)) * 100))

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="max-w-3xl">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl font-bold">{meta.titulo}</h2>
            <StatusBadge status={meta.status} />
            {meta.status === 'ativa' && (
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-accent-green animate-pulse-glow" />
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {onEdit && (
              <button onClick={() => onEdit(meta)} className="p-1.5 rounded-lg hover:bg-bg-surface-light text-text-muted hover:text-text-primary transition-colors">
                <Edit2 size={15} />
              </button>
            )}
            {onDelete && (
              <button onClick={() => onDelete(meta)} className="p-1.5 rounded-lg hover:bg-accent-red/10 text-text-muted hover:text-accent-red transition-colors">
                <Trash2 size={15} />
              </button>
            )}
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-bg-surface-light text-text-muted hover:text-text-primary transition-colors">
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Row 1: meta info */}
        <div className="bg-bg-surface-light rounded-xl p-3 border border-border">
          <p className="text-[9px] text-text-muted uppercase tracking-wider mb-1">PLATAFORMA</p>
          <p className="text-sm font-bold text-text-primary">{meta.plataforma || '—'}</p>
        </div>

        {/* Row 2: financial stats */}
        <div className="grid grid-cols-5 gap-2">
          {[
            { label: 'REMESSAS', value: remessas.length, isNum: true },
            { label: 'DEP. TOTAL', value: depositoTotalGeral, isMoney: true },
            { label: 'SAQUE TOTAL', value: saqueTotal, isMoney: true },
            { label: 'LUCRO', value: lucro, isMoney: true },
            { label: 'PREJUÍZO', value: prejuizo, isMoney: true, forceRed: true },
          ].map(item => (
            <div key={item.label} className="bg-bg-surface-light rounded-xl p-3 border border-border min-w-0 overflow-hidden">
              <p className="text-[9px] text-text-muted uppercase tracking-wider mb-1 truncate">{item.label}</p>
              {item.isMoney
                ? <p className={cn('text-sm font-bold mono-value truncate', item.forceRed ? 'text-accent-red' : item.value > 0 ? 'text-accent-green' : item.value < 0 ? 'text-accent-red' : 'text-text-muted')}>
                    {formatBRL(item.value as number)}
                  </p>
                : <p className="text-sm font-bold text-accent-blue">{item.value}</p>
              }
            </div>
          ))}
        </div>

        {/* Row 3: acerto + liquido */}
        <div className="grid grid-cols-5 gap-2">
          <div className="bg-bg-surface-light rounded-xl p-3 border border-border">
            <p className="text-[9px] text-text-muted uppercase tracking-wider mb-1">ACERTO</p>
            <p className={cn('text-sm font-bold', taxaAcerto >= 70 ? 'text-accent-yellow' : 'text-accent-yellow')}>{taxaAcerto}%</p>
          </div>
          <div className="col-span-4 rounded-xl p-3 border" style={{ background: 'rgba(16,185,129,0.08)', borderColor: 'rgba(16,185,129,0.30)' }}>
            <p className="text-[9px] text-text-muted uppercase tracking-wider mb-1">LÍQUIDO</p>
            <MoneyDisplay value={liquido} size="md" />
          </div>
        </div>

        {/* Progress */}
        <div className="bg-bg-surface-light rounded-xl p-3 border border-border">
          <div className="flex items-center justify-between mb-2 text-xs text-text-muted">
            <span>Progresso</span>
            <span>{meta.contas_atingidas || 0}/{meta.contas_total || 0}</span>
          </div>
          <div className="h-2 bg-bg-surface rounded-full overflow-hidden">
            <div
              className={cn('h-full rounded-full transition-all duration-700', progressPct >= 70 ? 'bg-accent-green' : progressPct >= 30 ? 'bg-accent-yellow' : 'bg-accent-red')}
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Remessas + Timeline */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Remessas */}
          <div className="bg-bg-surface-light rounded-xl border border-border p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold flex items-center gap-2">
                Remessas ({remessas.length})
                {meta.status === 'ativa' && <span className="w-2 h-2 rounded-full bg-accent-green animate-pulse-glow" />}
              </h3>
            </div>
            {loadingRemessas ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 size={20} className="animate-spin text-accent-green" />
              </div>
            ) : remessas.length === 0 ? (
              <p className="text-sm text-text-muted text-center py-8">Nenhuma remessa registrada.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {remessas.map(r => {
                  const st = r.status.toLowerCase()
                  const isBloqueado = st === 'bloqueado'
                  const isPendente = st === 'pendente' || st === 'analise'
                  const disp = isBloqueado ? -r.deposito : isPendente ? 0 : r.resultado
                  return (
                    <div key={r.id} className={cn('flex items-center justify-between px-3 py-2 rounded-lg border',
                      isBloqueado ? 'border-accent-red/30 bg-accent-red/5'
                      : disp > 0 ? 'border-accent-green/30 bg-accent-green/5'
                      : disp < 0 ? 'border-accent-red/30 bg-accent-red/5'
                      : 'border-border bg-bg-surface'
                    )}>
                      <div>
                        <p className="text-xs font-semibold">{r.titulo}</p>
                        <p className="text-[10px] text-text-muted">{r.contas} contas · {new Date(r.created_at).toLocaleDateString('pt-BR')}</p>
                      </div>
                      <span className={cn('text-xs font-bold mono-value', isBloqueado || disp < 0 ? 'text-accent-red' : disp > 0 ? 'text-accent-green' : 'text-text-muted')}>
                        {isBloqueado ? `−${formatBRL(r.deposito)}` : `${disp >= 0 ? '+' : ''}${formatBRL(disp)}`}
                      </span>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Timeline */}
          <div className="bg-bg-surface-light rounded-xl border border-border p-4">
            <h3 className="text-sm font-bold mb-3">Timeline</h3>
            {timeline.length === 0 ? (
              <p className="text-sm text-text-muted text-center py-8">Nenhum evento ainda.</p>
            ) : (
              <div className="space-y-3 max-h-48 overflow-y-auto">
                {timeline.map((ev, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <TimelineDot type={ev.type} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold leading-snug">{ev.label}</p>
                      {ev.sub && <p className="text-[10px] text-text-muted">{ev.sub}</p>}
                      <p className="text-[10px] text-text-muted flex items-center gap-1 mt-0.5">
                        <Clock size={8} />
                        {new Date(ev.date).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <p className="text-[11px] text-text-muted text-center">
          Criada em {meta.created_at ? new Date(meta.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—'}
        </p>
      </div>
    </Modal>
  )
}
