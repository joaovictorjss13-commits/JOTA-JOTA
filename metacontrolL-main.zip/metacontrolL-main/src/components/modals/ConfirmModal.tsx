'use client'

import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { AlertTriangle } from 'lucide-react'

interface ConfirmModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  title: string
  message: string
  confirmLabel?: string
  loading?: boolean
}

export function ConfirmModal({ isOpen, onClose, onConfirm, title, message, confirmLabel = 'Confirmar', loading }: ConfirmModalProps) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="text-center">
        <div className="w-14 h-14 rounded-full bg-accent-red/15 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle size={28} className="text-accent-red" />
        </div>
        <h2 className="text-lg font-bold text-text-primary mb-2">{title}</h2>
        <p className="text-sm text-text-muted mb-6">{message}</p>
        <div className="flex items-center gap-3">
          <Button variant="secondary" size="lg" className="flex-1" onClick={onClose} disabled={loading}>
            Cancelar
          </Button>
          <Button variant="danger" size="lg" className="flex-1" onClick={onConfirm} disabled={loading}>
            {loading ? 'Apagando...' : confirmLabel}
          </Button>
        </div>
      </div>
    </Modal>
  )
}
