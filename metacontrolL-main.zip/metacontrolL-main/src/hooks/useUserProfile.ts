'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

export interface UserProfile {
  nome: string
  email: string
  plano: 'solo' | 'trial' | 'pro' | 'infinit'
  trialEndsAt: string | null
  trialEndsAtFormatted: string | null
  daysRemaining: number | null
  isTrialActive: boolean
  isPro: boolean
}

export function useUserProfile() {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false

    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { setLoading(false); return }

      const [{ data: admin }, { data: assinatura }] = await Promise.all([
        supabase.from('admins').select('nome, email, plano').eq('id', user.id).single(),
        supabase.from('assinaturas').select('status, trial_ends_at, vencimento').eq('admin_id', user.id).single(),
      ])

      if (!admin || cancelled) { setLoading(false); return }

      let daysRemaining: number | null = null
      let isTrialActive = false
      let trialEndsAtFormatted: string | null = null

      // For active paid subscriptions, use vencimento; for trial, use trial_ends_at
      const dateSource = assinatura?.status === 'ativa' && assinatura?.vencimento
        ? assinatura.vencimento
        : assinatura?.trial_ends_at ?? null

      if (dateSource) {
        const endsAt = new Date(dateSource)
        const diff = endsAt.getTime() - Date.now()
        daysRemaining = Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)))
        isTrialActive = admin.plano === 'trial' && daysRemaining > 0

        trialEndsAtFormatted = endsAt.toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        })

        // Auto-expire: if trial_ends_at passed but status is still 'trial', downgrade
        if (assinatura?.status === 'trial' && assinatura?.trial_ends_at) {
          const trialDiff = new Date(assinatura.trial_ends_at).getTime() - Date.now()
          if (trialDiff <= 0) {
            await supabase.rpc('expire_my_trial')
            if (!cancelled) load()
            return
          }
        }
      }

      if (cancelled) return

      setProfile({
        nome: admin.nome,
        email: admin.email,
        plano: admin.plano,
        trialEndsAt: assinatura?.trial_ends_at ?? null,
        trialEndsAtFormatted,
        daysRemaining,
        isTrialActive,
        isPro: admin.plano === 'pro' || admin.plano === 'infinit' || (admin.plano === 'trial' && (daysRemaining ?? 0) > 0),
      })
      setLoading(false)
    }

    load()
    return () => { cancelled = true }
  }, [])

  return { profile, loading }
}
