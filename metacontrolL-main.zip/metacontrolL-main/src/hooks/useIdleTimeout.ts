'use client'

import { useEffect, useRef, useCallback } from 'react'

const IDLE_MS = 48 * 60 * 60 * 1000                // 48 horas
const WARN_MS = IDLE_MS - (1 * 60 * 1000)          // avisa 1 min antes

interface Options {
  onWarn:   () => void
  onLogout: () => Promise<void> | void
}

export function useIdleTimeout({ onWarn, onLogout }: Options) {
  const logoutRef  = useRef<ReturnType<typeof setTimeout> | null>(null)
  const warnRef    = useRef<ReturnType<typeof setTimeout> | null>(null)
  const warnedRef  = useRef(false)

  // Stable refs so callbacks never cause reset() to change identity
  const onWarnRef   = useRef(onWarn)
  const onLogoutRef = useRef(onLogout)
  useEffect(() => { onWarnRef.current   = onWarn   }, [onWarn])
  useEffect(() => { onLogoutRef.current = onLogout }, [onLogout])

  const reset = useCallback(() => {
    if (logoutRef.current) clearTimeout(logoutRef.current)
    if (warnRef.current)   clearTimeout(warnRef.current)
    warnedRef.current = false

    warnRef.current = setTimeout(() => {
      if (!warnedRef.current) {
        warnedRef.current = true
        onWarnRef.current()
      }
    }, WARN_MS)

    logoutRef.current = setTimeout(() => {
      void onLogoutRef.current()
    }, IDLE_MS)
  }, [])

  useEffect(() => {
    const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click']
    events.forEach(e => window.addEventListener(e, reset, { passive: true }))
    reset()

    return () => {
      events.forEach(e => window.removeEventListener(e, reset))
      if (logoutRef.current) clearTimeout(logoutRef.current)
      if (warnRef.current)   clearTimeout(warnRef.current)
    }
  }, [reset])
}
