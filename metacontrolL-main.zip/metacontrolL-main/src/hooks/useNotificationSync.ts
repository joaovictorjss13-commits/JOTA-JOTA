'use client'

import { useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { notify, notifyFromPush, setNotifyBroadcast, setNotifyPush } from '@/lib/notifications'

// Unique ID per browser tab — prevents echoing our own DB inserts
const SESSION_ID = `${Date.now()}-${Math.random().toString(36).slice(2)}`

type NotifRow = {
  session_id: string
  event: string
  data: Record<string, unknown>
}

function urlB64ToUint8Array(base64: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4)
  const b64 = (base64 + padding).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(b64)
  const buffer = new ArrayBuffer(raw.length)
  const arr = new Uint8Array(buffer)
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i)
  return arr
}

async function registerPushSubscription(token: string): Promise<void> {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return
  const vapidKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
  if (!vapidKey) return
  try {
    const reg = await navigator.serviceWorker.ready
    let sub = await reg.pushManager.getSubscription()
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlB64ToUint8Array(vapidKey),
      })
    }
    const json = sub.toJSON()
    await fetch('/api/push/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }),
    })
  } catch {
    // non-fatal — push subscription not supported or blocked
  }
}

export function useNotificationSync() {
  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null

    // Fallback: push chegou com app visível — notifyFromPush gerencia dedup internamente
    const onSwMessage = (evt: MessageEvent) => {
      if (evt.data?.type !== 'PUSH_RELAY') return
      notifyFromPush(evt.data.title ?? '', evt.data.body ?? '', evt.data.tag ?? 'notify')
    }

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', onSwMessage)
    }

    async function setup() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // ── Supabase Realtime Postgres Changes (sessões abertas) ───────
      channel = supabase.channel(`notif-db:${user.id}`)

      channel.on(
        'postgres_changes' as any,
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `admin_id=eq.${user.id}`,
        },
        (payload: { new: NotifRow }) => {
          const row = payload.new
          if (row.session_id === SESSION_ID) return
          notify(row.event as any, row.data as any, true)  // dedup gerenciado em notify()
        }
      )

      // ── Web Push VAPID — configurar ANTES de aguardar Realtime ───
      // Push é independente do Realtime; definir cedo garante que notificações
      // funcionem mesmo se o canal Supabase demorar ou falhar.
      const { data: { session } } = await supabase.auth.getSession()
      if (session?.access_token) {
        const token = session.access_token

        setNotifyPush((title, body, tag) => {
          fetch('/api/push/send', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ title, body, tag }),
          }).catch(() => null)
        })

        // Auto-inscrever push se permissão já concedida (mantém subscrição fresca)
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          registerPushSubscription(token)
        }
      }

      // Aguarda subscrição Realtime — resolve em qualquer status para não bloquear
      await new Promise<void>((resolve) => {
        channel!.subscribe((status) => {
          if (
            status === 'SUBSCRIBED' ||
            status === 'CHANNEL_ERROR' ||
            status === 'TIMED_OUT' ||
            status === 'CLOSED'
          ) resolve()
        })
      })

      // Broadcast via DB (Realtime) — só ativa após canal confirmado
      setNotifyBroadcast((event, data) => {
        supabase
          .from('notifications')
          .insert({
            admin_id: user.id,
            session_id: SESSION_ID,
            event,
            data: data as Record<string, unknown>,
          })
          .then(({ error }) => {
            if (error) console.error('[NotifSync] insert failed:', error.message)
          })
      })
    }

    setup()

    return () => {
      setNotifyBroadcast(null)
      setNotifyPush(null)
      if (channel) {
        supabase.removeChannel(channel)
        channel = null
      }
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', onSwMessage)
      }
    }
  }, [])
}
