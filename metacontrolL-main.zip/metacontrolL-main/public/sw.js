const CACHE = 'mc-v2'
const PRECACHE = ['/logo.png', '/manifest.json']

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', e => {
  const { request } = e
  const url = new URL(request.url)

  // API e autenticação: sempre rede
  if (url.pathname.startsWith('/api/') || url.pathname.includes('supabase')) {
    return
  }

  // Assets estáticos: cache-first
  if (
    request.destination === 'image' ||
    request.destination === 'font' ||
    url.pathname.startsWith('/_next/static/')
  ) {
    e.respondWith(
      caches.match(request).then(cached => {
        if (cached) return cached
        return fetch(request).then(res => {
          const clone = res.clone()
          caches.open(CACHE).then(c => c.put(request, clone))
          return res
        })
      })
    )
    return
  }

  // HTML: network-first, fallback para cache
  if (request.mode === 'navigate') {
    e.respondWith(
      fetch(request).catch(() => caches.match(request))
    )
  }
})

// Recebe push do servidor
// - App aberto: envia postMessage para o app exibir toast (fallback para Realtime lento)
// - App fechado/background: exibe notificação do sistema
self.addEventListener('push', e => {
  const data = e.data?.json() ?? {}
  const title = data.title || 'MetaControll'
  const options = {
    body:  data.body  || '',
    icon:  data.icon  || '/logo.png',
    badge: data.badge || '/logo.png',
    tag:   data.tag   || 'notify',
    data:  { url: data.url || '/admin' },
  }

  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      const visible = list.filter(c => c.visibilityState === 'visible')
      if (visible.length > 0) {
        // App visível — relay para handler in-app (fallback caso Realtime demore)
        visible.forEach(c => c.postMessage({
          type: 'PUSH_RELAY',
          title: data.title,
          body:  data.body,
          tag:   data.tag ?? 'notify',
        }))
        return
      }
      return self.registration.showNotification(title, options)
    })
  )
})

// Abre ou foca o app ao clicar na notificação
self.addEventListener('notificationclick', e => {
  e.notification.close()
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      const existing = list.find(c => c.url.includes('/admin') || c.url.includes('/'))
      if (existing) return existing.focus()
      return clients.openWindow('/admin')
    })
  )
})
