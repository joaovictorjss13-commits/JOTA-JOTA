# MetaControll — Backend

Stack: Next.js 14 (App Router) + Supabase

## Estrutura de arquivos

```
supabase/migrations/
  001_schema.sql          → Todas as tabelas e tipos
  002_triggers.sql        → Lógica de negócio no banco (recálculos automáticos)
  003_rls.sql             → Segurança: cada usuário vê só seus dados
  004_realtime_functions.sql → Realtime, índices, função evolução mensal

src/
  lib/supabase.ts         → Clientes Supabase (browser + server)
  types/database.ts       → Tipos TypeScript

  app/api/
    auth/register/        → POST cadastro de admin
    dashboard/            → GET dados do painel principal
    metas/                → GET listar | POST criar
    metas/[id]/           → GET detalhe | PATCH atualizar/fechar | DELETE lixeira
    remessas/             → POST registrar remessa
    remessas/[id]/        → PATCH editar | DELETE deletar
    faturamento/          → GET visão financeira consolidada
    operadores/           → GET listar | POST convidar
    operadores/convite/[token]/ → POST aceitar convite
    assinatura/           → GET dados | PATCH ajustar operadores
```

## Setup

### 1. Criar projeto no Supabase
```
https://supabase.com → New project
```

### 2. Executar migrations (nesta ordem)
```
Supabase Dashboard → SQL Editor → New query
Cole e execute cada arquivo de /supabase/migrations em ordem (001, 002, 003, 004)
```

### 3. Instalar dependências
```bash
npx create-next-app@latest metacontroll --typescript --app
cd metacontroll
npm install @supabase/supabase-js @supabase/auth-helpers-nextjs
```

### 4. Configurar variáveis de ambiente
```bash
cp .env.example .env.local
# Preencha com suas chaves do Supabase
```

### 5. Copiar arquivos de API
Copie a pasta src/ para dentro do seu projeto Next.js

### 6. Rodar
```bash
npm run dev
```

## Rotas da API

| Método | Rota                              | Descrição                    |
|--------|-----------------------------------|------------------------------|
| POST   | /api/auth/register                | Cadastro de admin            |
| GET    | /api/dashboard?filtro=tudo        | Painel principal             |
| GET    | /api/metas?status=ativa           | Listar metas                 |
| POST   | /api/metas                        | Criar meta                   |
| GET    | /api/metas/:id                    | Detalhe da meta + remessas   |
| PATCH  | /api/metas/:id {action: "fechar"} | Fechar meta com custos       |
| DELETE | /api/metas/:id                    | Mover para lixeira           |
| POST   | /api/remessas                     | Registrar remessa            |
| PATCH  | /api/remessas/:id                 | Editar remessa               |
| DELETE | /api/remessas/:id                 | Deletar remessa              |
| GET    | /api/faturamento?de=&ate=         | Faturamento consolidado      |
| GET    | /api/custos                       | Listar custos                |
| POST   | /api/custos                       | Adicionar custo              |
| GET    | /api/operadores                   | Listar operadores            |
| POST   | /api/operadores                   | Convidar operador            |
| POST   | /api/operadores/convite/:token    | Aceitar convite              |
| GET    | /api/assinatura                   | Dados da assinatura          |

## Realtime (frontend)

```typescript
// Escutar atualizações da meta em tempo real
const channel = supabase
  .channel('meta-updates')
  .on('postgres_changes', {
    event: 'UPDATE',
    schema: 'public',
    table: 'metas',
    filter: `admin_id=eq.${adminId}`
  }, (payload) => {
    // Atualizar estado local com os novos dados
    console.log('Meta atualizada:', payload.new)
  })
  .subscribe()
```

## Lógica de negócio (automática no banco)

- Ao inserir/editar/deletar uma remessa → trigger recalcula lucro, taxa de acerto e score da meta
- Ao criar um admin → trigger cria assinatura trial (3 dias) + checklist de onboarding
- Ao fechar uma meta → trigger calcula lucro_final descontando salário + custos
- Slots premium → RLS bloqueia automaticamente para usuários sem plano PRO
