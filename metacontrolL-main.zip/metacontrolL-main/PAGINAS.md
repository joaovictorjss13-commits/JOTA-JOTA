# Mapa de Páginas — MetaControll

## Menu lateral (Sidebar)
> Arquivo: `src/components/layout/Sidebar.tsx` — linha 23
> Para renomear um item do menu, altere o campo `label` no array `navItems`.

| Label atual | Rota | Arquivo da página |
|---|---|---|
| Admin | `/admin` | `src/app/admin/page.tsx` |
| Faturamento | `/faturamento` | `src/app/faturamento/page.tsx` |
| Custos | `/custos` | `src/app/custos/page.tsx` |
| Assinatura | `/assinatura` | `src/app/assinatura/page.tsx` |
| Tutorial | `/tutorial` | `src/app/tutorial/page.tsx` |

---

## Todas as páginas do projeto

| Página | Rota | Arquivo |
|---|---|---|
| Landing (home) | `/` | `src/app/page.tsx` |
| Login | `/login` | `src/app/login/page.tsx` |
| Cadastro | `/register` | `src/app/register/page.tsx` |
| Admin / Central de operações | `/admin` | `src/app/admin/page.tsx` |
| Detalhe de operação | `/admin/meta/[id]` | `src/app/admin/meta/[id]/page.tsx` |
| Faturamento | `/faturamento` | `src/app/faturamento/page.tsx` |
| Custos | `/custos` | `src/app/custos/page.tsx` |
| Assinatura | `/assinatura` | `src/app/assinatura/page.tsx` |
| Tutorial | `/tutorial` | `src/app/tutorial/page.tsx` |
| Slots Premium | `/slots-premium` | `src/app/slots-premium/page.tsx` |
| Teste Supabase | `/test-supabase` | `src/app/test-supabase/page.tsx` |

---

## Como renomear um item do menu

Abra `src/components/layout/Sidebar.tsx` e edite o `label` desejado no array `navItems` (linha 23):

```ts
const navItems = [
  { href: '/admin',       label: 'Admin',        icon: LayoutDashboard },
  { href: '/faturamento', label: 'Faturamento',   icon: DollarSign },
  { href: '/custos',      label: 'Custos',        icon: Receipt },
  { href: '/assinatura',  label: 'Assinatura',    icon: CreditCard },
  { href: '/tutorial',    label: 'Tutorial',      icon: GraduationCap },
]
```
