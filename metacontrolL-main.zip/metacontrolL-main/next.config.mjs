/** @type {import('next').NextConfig} */

const securityHeaders = [
  // Força HTTPS por 2 anos, incluindo subdomínios
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  // Impede MIME sniffing pelo navegador
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff',
  },
  // Bloqueia framing (clickjacking)
  {
    key: 'X-Frame-Options',
    value: 'DENY',
  },
  // Limita informação de referer enviada para terceiros
  {
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin',
  },
  // Remove cabeçalho de versão do servidor Next.js
  {
    key: 'X-Powered-By',
    value: '',
  },
  // Limita acesso a APIs do navegador
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()',
  },
  // Isolamento de origem cruzada
  {
    key: 'Cross-Origin-Opener-Policy',
    value: 'same-origin',
  },
  {
    key: 'Cross-Origin-Resource-Policy',
    value: 'same-origin',
  },
  // Content Security Policy
  // 'unsafe-inline' em style-src é necessário para Tailwind/CSS-in-JS
  // connect-src permite Supabase Realtime (WSS) e APIs
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https://*.supabase.co",
      "font-src 'self'",
      "connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.asaas.com https://sandbox.asaas.com",
      "frame-src 'none'",
      "frame-ancestors 'none'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; '),
  },
]

const nextConfig = {
  // Remove X-Powered-By do Next.js
  poweredByHeader: false,

  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.supabase.co',
      },
    ],
  },

  async headers() {
    return [
      {
        // Aplica headers em todas as rotas
        source: '/(.*)',
        headers: securityHeaders.filter(h => h.value !== ''),
      },
    ]
  },
}

export default nextConfig
